#!/bin/bash
rm -rf configs/config.yaml
mkdir -p configs
echo "$configstag" >> configs/config.yaml
