package utils

import (
	"backend/pkg/constants"
	"errors"
	"github.com/google/uuid"
	"reflect"
)

func GenerateUniqueKey() string {
	uUid := uuid.NewString()
	return NormalizeToken(uUid)
}

// MapChangesGeneric maps fields from input to entity, only if they are non-zero or non-nil.
func MapChangesGeneric[E any, I any](entity *E, input I) error {
	// Kiểm tra và lấy giá trị của entity
	entityValue := reflect.ValueOf(entity)

	// Kiểm tra xem entity có phải là con trỏ không
	if entityValue.Kind() != reflect.Ptr {
		return errors.New("entity must be a pointer to a struct")
	}

	// Lấy giá trị của con trỏ entity
	entityValue = entityValue.Elem()

	// Kiểm tra nếu entity là struct
	if entityValue.Kind() != reflect.Struct {
		return errors.New("entity must be a pointer to a struct")
	}

	// Lấy giá trị của input
	inputValue := reflect.ValueOf(input)

	// Kiểm tra nếu input là struct
	if inputValue.Kind() != reflect.Struct {
		return errors.New("input must be a struct")
	}

	for i := 0; i < inputValue.NumField(); i++ {
		inputField := inputValue.Field(i)
		fieldName := inputValue.Type().Field(i).Name
		entityField := entityValue.FieldByName(fieldName)

		if entityField.IsValid() && entityField.CanSet() && !inputField.IsZero() {
			// Kiểm tra kiểu dữ liệu và chuyển đổi nếu cần
			if entityField.Kind() == inputField.Kind() {
				entityField.Set(inputField)
			} else if entityField.Kind() == reflect.Ptr && inputField.Kind() != reflect.Ptr {
				// Nếu entity là con trỏ và input không phải là con trỏ, ta cần chuyển input thành con trỏ
				inputFieldPtr := reflect.New(inputField.Type())
				inputFieldPtr.Elem().Set(inputField)
				entityField.Set(inputFieldPtr)
			} else if entityField.Kind() != reflect.Ptr && inputField.Kind() == reflect.Ptr {
				// Nếu entity không phải là con trỏ nhưng input là con trỏ, ta cần lấy giá trị từ con trỏ
				if !inputField.IsNil() {
					entityField.Set(inputField.Elem())
				}
			}
		}
	}

	return nil
}

// GetDefaultPagination returns the validated page and limit for pagination.
func GetDefaultPagination(page, limit int) (int, int) {
	// Use default values if inputs are invalid
	if page <= 0 {
		page = constants.PaginationDefaultPage
	}

	if limit == 0 {
		limit = constants.PaginationDefaultLimit
	}
	if limit == constants.Unlimited {
		limit = 0
	}

	return page, limit
}

type CodePrefix string
