package utils

import (
	"github.com/google/uuid"
	"time"
)

func GetStringValue(s *string) string {
	if s != nil {
		return *s
	}
	return ""
}

func GetUUIDValue(id *uuid.UUID) uuid.UUID {
	if id != nil {
		return *id
	}
	return uuid.Nil
}

func GetIntValue(i *int) int {
	if i != nil {
		return *i
	}
	return 0
}

func GetFloat64Value(f *float64) float64 {
	if f != nil {
		return *f
	}
	return 0.0
}

func GetTimeValue(t *time.Time) time.Time {
	if t != nil {
		return *t
	}
	return time.Time{}
}
