package utils

func ConvertInterfaceToStringArray(input []interface{}) []string {
	result := make([]string, 0)
	for _, i := range input {
		result = append(result, i.(string))
	}
	return result
}
