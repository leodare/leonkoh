package utils

import (
	"fmt"
	"github.com/gertd/go-pluralize"
	"regexp"
	"strings"
)

func NormalizeToken(token string) string {
	return strings.ReplaceAll(token, "-", "")
}

func BuildILikeContainQuery(value string) string {
	return fmt.Sprintf("%%%s%%", strings.ToLower(value))
}

func CamelCase(input string) string {
	if input == "" {
		return ""
	}
	return strings.ToLower(string(input[0])) + input[1:]
}

func GetPointerString(s string) *string {
	if s == "" {
		return nil
	}
	return &s
}

func GetStringFromTypeString(s interface{}) string {
	if s == nil {
		return ""
	}
	// check type can covert to string
	if _, ok := s.(string); !ok {
		return ""
	}
	return s.(string)
}

// Hàm chuyển đổi tên sang dạng `TitleCase` (cho Interface)
func TitleCase(input string) string {
	return strings.Title(input)
}

// Hàm chuyển đổi tên sang dạng `lowerCase`
// e.g: `HelloWorld` -> `helloWorld`
func Lower(input string) string {
	return strings.ToLower(input)
}
func ToSnakeCase(input string) string {
	// Tách từ viết hoa thành từ riêng
	regex := regexp.MustCompile("([a-z0-9])([A-Z])")
	snake := regex.ReplaceAllString(input, "${1}_${2}")
	// Chuyển thành chữ thường
	return strings.ToLower(snake)
}

// convert from text as supper-case to supperCase
func ConvertToCamelCase(input string) string {
	parts := strings.Split(input, "-")
	if len(parts) == 0 {
		return ""
	}

	output := strings.ToLower(parts[0])
	for _, part := range parts[1:] {
		output += strings.Title(strings.ToLower(part))
	}

	return output
}

func ToKebabCase(input string) string {
	regex := regexp.MustCompile("([a-z0-9])([A-Z])")
	kebab := regex.ReplaceAllString(input, "${1}-${2}")
	return strings.ToLower(kebab)
}
func ToKebabPlural(word string) string {
	// Tạo một thể hiện của pluralize
	pluralize := pluralize.NewClient()

	// Chuyển sang dạng số nhiều
	pluralWord := pluralize.Plural(word)

	// Chuyển sang kebab-case
	return ToKebabCase(pluralWord)
}
func IndexOfString(str, substr string) int {
	return strings.Index(str, substr)
}

func NormalizePhoneNumber(phone *string) *string {
	if phone == nil {
		return nil
	}
	normalized := *phone
	normalized = strings.ReplaceAll(normalized, " ", "")
	normalized = strings.ReplaceAll(normalized, "(", "")
	normalized = strings.ReplaceAll(normalized, ")", "")
	normalized = strings.ReplaceAll(normalized, "-", "")
	normalized = strings.ReplaceAll(normalized, ".", "")

	// Loại bỏ các ký tự không phải số
	result := ""
	for _, r := range normalized {
		if (r >= '0' && r <= '9') || r == '+' {
			result += string(r)
		}
	}

	return &result
}

func NormalizeEmail(email *string) *string {
	if email == nil {
		return nil
	}
	normalized := *email
	// Loại bỏ khoảng trắng thừa
	normalized = strings.TrimSpace(normalized)
	// Chuẩn hóa về chữ thường
	normalized = strings.ToLower(normalized)
	return &normalized
}
