package utils

func NewBoolPtr(value bool) *bool {
	return &value
}

func NewInt64Ptr(value int64) *int64 {
	return &value
}

func NewIntPtr(value int) *int {
	return &value
}

func NewStringPtr(value string) *string {
	return &value
}

func NewString(value string) *string {
	return &value
}
