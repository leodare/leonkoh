package utils

func StringSliceContains(s []string, e string) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}

func Int64SliceContains(s []int64, e int64) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}

func Int32SliceContains(s []int32, e int32) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}

func IntSliceContains(s []int, e int) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}

// thay vì dùng interface thì dùng reneric type
func DiffSlice[T comparable](a, b []T) (diff1, diff2 []T) {
	m := make(map[T]struct{})
	for _, item := range a {
		m[item] = struct{}{}
	}
	for _, item := range b {
		if _, ok := m[item]; ok {
			delete(m, item)
		} else {
			diff2 = append(diff2, item)
		}
	}
	for item := range m {
		diff1 = append(diff1, item)
	}
	return
}
