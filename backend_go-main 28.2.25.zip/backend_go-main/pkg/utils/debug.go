package utils

import (
	"github.com/spf13/viper"
	"sync"
)

var isDebug *bool
var lock sync.Mutex

func IsDebug() bool {
	if isDebug == nil {
		lock.Lock()
		defer lock.Unlock()
		debugConfig := viper.GetBool("is_debug")
		if isDebug == nil {
			isDebug = NewBoolPtr(debugConfig)
		}
	}
	return *isDebug
}
