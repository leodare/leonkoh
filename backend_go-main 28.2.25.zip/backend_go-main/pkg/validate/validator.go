package validate

import (
	"errors"
	"regexp"
	"sync"

	_validator "github.com/go-playground/validator/v10"
	"github.com/spf13/viper"
)

type Validator interface {
	Validate(input interface{}) error
}

type validator struct {
	validate *_validator.Validate
}

var instance *validator
var once sync.Once

func GetValidatorInstance() Validator {
	once.Do(func() {
		validate := _validator.New(_validator.WithRequiredStructEnabled())
		instance = &validator{
			validate: validate,
		}
		_ = instance.RegisterRegexValidation("x_username", RegexUsername)
		_ = instance.RegisterRegexValidation("x_email", RegexEmail)
		_ = instance.RegisterRegexValidation("x_url", RegexURL)
		_ = instance.RegisterRegexValidation("x_phone_number", RegexPhoneNumber)
		_ = instance.RegisterRegexValidation("x_date", RegexDate)
		_ = instance.RegisterRegexValidation("x_time", RegexTime)
		_ = instance.RegisterRegexValidation("x_date_time", RegexDateTime)
		_ = instance.registerPasswordValidation()
	})
	return instance
}

func (v *validator) RegisterRegexValidation(tag string, regexStr string) error {
	fn := func(fl _validator.FieldLevel) bool {
		if fl.Field().String() == "" {
			return true
		}
		regex := regexp.MustCompile(regexStr)
		return regex.MatchString(fl.Field().String())
	}
	err := v.validate.RegisterValidation(tag, fn)
	if err != nil {
		return err
	}
	return nil
}

func (v *validator) registerPasswordValidation() error {
	minLengthRegex := regexp.MustCompile(`^.{8,50}$`)
	upperCaseRegex := regexp.MustCompile(`[A-Z]`)
	lowerCaseRegex := regexp.MustCompile(`[a-z]`)
	numberRegex := regexp.MustCompile(`\d`)
	specialCharRegex := regexp.MustCompile(`[@$!%*?&]`)
	fn := func(fl _validator.FieldLevel) bool {
		password := fl.Field().String()
		if !minLengthRegex.MatchString(password) {
			return false
		}
		if !upperCaseRegex.MatchString(password) {
			return false
		}
		if !lowerCaseRegex.MatchString(password) {
			return false
		}
		if !numberRegex.MatchString(password) {
			return false
		}
		if !specialCharRegex.MatchString(password) {
			return false
		}
		return true
	}
	err := v.validate.RegisterValidation("x_password", fn)
	if err != nil {
		return err
	}
	return nil
}

func (v *validator) Validate(input interface{}) error {
	ignoreValidate := viper.GetBool("is_debug")
	if ignoreValidate {
		return nil
	}
	err := v.validate.Struct(input)
	validateErrors := &Error{
		Errors: make([]*FieldError, 0),
	}
	if err == nil {
		return nil
	}
	var vErr _validator.ValidationErrors
	errors.As(err, &vErr)
	for _, e := range vErr {
		field := e.Field()
		tag := e.Tag()
		fieldError := NewFieldError(field, tag)
		validateErrors.Errors = append(validateErrors.Errors, fieldError)
	}
	return validateErrors
}
