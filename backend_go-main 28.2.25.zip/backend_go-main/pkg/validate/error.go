package validate

import "fmt"

type FieldError struct {
	Field     string `json:"field"`
	ErrorCode string `json:"error"`
}

type Error struct {
	Errors []*FieldError `json:"errors"`
}

func NewFieldError(field, error string) *FieldError {
	return &FieldError{
		Field:     field,
		ErrorCode: error,
	}
}

func (e *Error) Error() string {
	message := ""
	for _, fieldError := range e.Errors {
		message += fmt.Sprintf("Field: %s, Error: %s\n", fieldError.Field, fieldError.Error)
	}
	return message
}

func (e *FieldError) Error() string {
	return fmt.Sprintf("Field: %s, Error: %s", e.Field, e.ErrorCode)
}
