package http

import (
	"backend/pkg/constants"
	"backend/pkg/utils"
	"backend/pkg/validate"
	xerror "backend/pkg/x-error"
	"errors"
	"github.com/dotrongnhan/sharing-package/pkg/logger"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"net/http"
)

// ErrorResponseFactory to create error responses
type ErrorResponseFactory struct{}

// CreateErrorResponse generates a structured error response
func (f *ErrorResponseFactory) CreateErrorResponse(success bool, errCode string, data interface{}) BaseResponse {
	return BaseResponse{
		Success:   success,
		ErrorCode: utils.NewStringPtr(errCode),
		Data:      data,
	}
}

// GetHTTPStatusFromErrorCode maps error codes to HTTP status
func GetHTTPStatusFromErrorCode(errCode string) int {
	switch errCode {
	// Internal Server Error (500)
	case xerror.InternalServer,
		xerror.CanNotReadFileContent:
		return http.StatusInternalServerError

	// Bad Request (400)
	case xerror.DataInvalid,
		xerror.CodeInvalidUsernameOrPassword,
		xerror.CodeUsernameRequired,
		xerror.CodeCreatedByRequired,
		xerror.CodeRoleIdsRequired,
		xerror.CodePasswordRequired,
		xerror.MeiliSearchCreateCollectionFailed,
		xerror.MeiliSearchCreateDocumentsFailed,
		xerror.MeiliSearchDeleteDocumentsFailed,
		xerror.MeiliSearchSearchFailed,
		xerror.CodeDataMissing,
		xerror.CategoryExisted:
		return http.StatusBadRequest

	// Not Found (404)
	case xerror.CodeDataNotFound,
		xerror.CodeUserNotFound,
		xerror.CodeCreatedByNotExists,
		xerror.CodeRoleIdsNotExists,
		xerror.CodeProfileNotFound:
		return http.StatusNotFound

	// Conflict (409)
	case xerror.CodeUserAlreadyExists,
		xerror.CodeUsernameExists,
		xerror.ReviewExisted,
		xerror.CodeProfileAlreadyExists,
		xerror.DataExisted:
		return http.StatusConflict

	// Unauthorized (401)
	case xerror.CodeInvalidToken,
		xerror.CodeUnauthorized,
		xerror.OTPNotMatch,
		xerror.CodeUnexpectedSigningMethod,
		xerror.RefreshTokenNotFound,
		xerror.RefreshTokenInvalid,
		xerror.RefreshTokenExpired,
		xerror.AccountNeedToVerify:
		return http.StatusUnauthorized

	// Forbidden (403)
	case xerror.CodeUserHasNoRole,
		xerror.CodeDoNotPermissionCreateUploadFolder,
		xerror.DoNotPermissionCreateNewFile,
		xerror.DoNotPermissionToUploadFile,
		xerror.Forbidden:
		return http.StatusForbidden

	// Custom status for token expiration (469)
	case xerror.CodeAccessTokenExpired:
		return 469

	// Default to Internal Server Error (500)
	default:
		return http.StatusInternalServerError
	}
}

// HandleValidateError handles validation errors
func HandleValidateError(c *gin.Context, validateErr *validate.Error) {
	factory := ErrorResponseFactory{}
	traceId := c.GetString(constants.ContextKeyUserId)
	c.Header(constants.HeaderKeyTraceID, traceId)
	c.AbortWithStatusJSON(http.StatusBadRequest, factory.CreateErrorResponse(false, xerror.DataInvalid, validateErr.Errors))
}

// HandleXError handles custom errors based on xerror package
func HandleXError(c *gin.Context, xErr *xerror.Error) {
	factory := ErrorResponseFactory{}
	sttCode := GetHTTPStatusFromErrorCode(xErr.ErrCode())
	setTraceIdHeader(c)
	c.AbortWithStatusJSON(sttCode, factory.CreateErrorResponse(false, xErr.ErrCode(), nil))
}

// HandleError is the main error handler for all errors
func HandleError(c *gin.Context, err error) {
	// Logging and debug configuration
	isDebug := viper.GetBool("is_debug")
	// Handle validation errors
	var validateErr *validate.Error
	if errors.As(err, &validateErr) {
		HandleValidateError(c, validateErr)
		return
	}

	// Handle custom xerror errors
	var xErr *xerror.Error
	if errors.As(err, &xErr) {
		HandleXError(c, xErr)
		return
	}

	setTraceIdHeader(c)

	// Handle unknown errors
	factory := ErrorResponseFactory{}
	if isDebug {
		c.AbortWithStatusJSON(http.StatusInternalServerError, factory.CreateErrorResponse(false, xerror.InternalServer, err.Error()))
	} else {
		c.AbortWithStatusJSON(http.StatusInternalServerError, factory.CreateErrorResponse(false, xerror.InternalServer, nil))
	}
}

func setTraceIdHeader(c *gin.Context) {
	traceId := c.GetString(logger.TraceKey)
	c.Header(constants.HeaderKeyTraceID, traceId)
}
