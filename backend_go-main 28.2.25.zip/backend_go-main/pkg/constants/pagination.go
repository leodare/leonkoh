package constants

type PaginationInput struct {
	Page  int `form:"page" json:"page"`
	Limit int `form:"limit" json:"limit"`
}

type PaginationMeta struct {
	ItemsPerPage int   `json:"items_per_page"`
	TotalItems   int64 `json:"total_items"`
	CurrentPage  int   `json:"current_page"`
	TotalPages   int   `json:"total_pages"`
}
