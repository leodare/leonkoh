package constants

const (
	TokenTypeAccessToken  = "AccessToken"
	TokenTypeRefreshToken = "RefreshToken"
)

const (
	HeaderKeyAuthorization = "Authorization"
	HeaderKeyRefreshToken  = "RefreshToken"
	HeaderKeyUserID        = "UserID"
)

const (
	AuthHeaderPrefix = "Bearer "
)
