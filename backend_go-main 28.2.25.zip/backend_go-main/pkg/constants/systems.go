package constants

import "time"

type DateTimeFormat string

const (
	DatetimeFormat    DateTimeFormat = "2006-01-02 15:04:05"
	DateFormat        DateTimeFormat = "2006-01-02"
	TimeFormat        DateTimeFormat = "15:04:05"
	DateTimeISOFormat DateTimeFormat = "2006-01-02T15:04:05Z"
)

const (
	ConfigTypeFile   = "file"
	ConfigTypeRemote = "remote"
)

const (
	HeaderKeyDeviceID    = "Device-ID"
	HeaderKeyDeviceModel = "Device-Model"
	HeaderKeyAppVersion  = "App-Version"
	HeaderKeyOsVersion   = "Os-Version"
	HeaderKeyOs          = "Os"
)

const (
	AuthenticationScheme = "Bearer "
)

const (
	ContextKeyDBTransaction = "context_db_transaction"
	ContextKeyUserId        = "user_id"
	ContextKeyEmail         = "email"
	ContextKeyOs            = "os"
	ContextKeyDeviceID      = "device_id"
	ContextKeyOsVersion     = "os_version"
	ContextKeyAppVersion    = "app_version"
	ContextKeyDeviceModel   = "device_model"
)

const (
	PaginationDefaultPage  = 1
	PaginationDefaultLimit = 20
	PaginationMaxLimit     = 500
	Unlimited              = -1
)

const (
	HeaderKeyTraceID = "X-Trace-ID"
)

var VietnamLocation *time.Location

func init() {
	var err error
	VietnamLocation, err = time.LoadLocation("Asia/Ho_Chi_Minh")
	if err != nil {
		panic(err)
	}
}
