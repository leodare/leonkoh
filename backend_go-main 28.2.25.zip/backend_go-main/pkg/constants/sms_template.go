package constants

type SMSTemplateCode string

const (
	OTPTemplate SMSTemplateCode = "otp"
)
