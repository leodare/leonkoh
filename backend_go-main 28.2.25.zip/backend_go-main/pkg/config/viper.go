package config

import (
	"backend/pkg/constants"
	"errors"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/hashicorp/consul/api"
	"github.com/spf13/viper"
	"gopkg.in/yaml.v2"
	"strings"
)

type ConfigFile struct {
	Path string
	Name string
}

type Viper struct {
	ConfigType    string
	RemoteSchema  string
	RemoteAddress string
	RemoteKeys    string
	ConfigFiles   []ConfigFile
}

func (v *Viper) InitConfig() error {
	if v.ConfigType == constants.ConfigTypeFile {
		return v.LoadConfigFromFile()
	} else {
		return v.LoadConfigFromConsul()
	}
}

func (v *Viper) LoadConfigFromFile() error {
	vip := viper.New() // Tạo một instance Viper mới để tránh xung đột
	//vip.AddConfigPath(v.FilePath)
	vip.SetConfigType("yaml")
	vip.AutomaticEnv()

	for _, configFile := range v.ConfigFiles {
		vip.AddConfigPath(configFile.Path)
		vip.SetConfigName(configFile.Name)
		if err := vip.MergeInConfig(); err != nil {
			var configFileNotFoundError viper.ConfigFileNotFoundError
			if errors.As(err, &configFileNotFoundError) {
				log.Warnf("Cannot find config file %s.yaml", configFile)
				continue
			}
		}
		log.Infof("Config loaded from file %s.yaml", configFile)
	}

	// Hợp nhất cấu hình vào instance viper toàn cục
	if err := viper.MergeConfigMap(vip.AllSettings()); err != nil {
		log.Errorf("Failed to merge config file, err: %v", err)
		return err
	}

	return nil
}

func (v *Viper) loadConsulConfigMap(configRemoteKeys []string) map[string]interface{} {
	result := make(map[string]interface{})
	client, err := api.NewClient(&api.Config{
		Address:    v.RemoteAddress,
		Scheme:     v.RemoteSchema,
		Datacenter: "dc1",
	})
	if err != nil {
		panic(err)
	}

	kv := client.KV()

	for _, remoteConfigKey := range configRemoteKeys {
		pairs, _, err := kv.List(remoteConfigKey, nil)
		if err != nil {
			panic(err)
		}
		if len(pairs) == 0 {
			continue
		}
		for _, kvPair := range pairs {
			mapValue := make(map[string]interface{})
			err = yaml.Unmarshal(kvPair.Value, &mapValue)
			if err != nil {
				panic(err)
			}
			for key, value := range mapValue {
				result[key] = value
			}
		}
	}
	return result
}

func (v *Viper) LoadConfigFromConsul() error {
	viper.SetEnvPrefix("app")
	viper.AllowEmptyEnv(true)
	viper.AutomaticEnv()
	configRemoteKeys := strings.Split(v.RemoteKeys, ",")
	err := viper.MergeConfigMap(v.loadConsulConfigMap(configRemoteKeys))
	if err != nil {
		log.Errorf("Failed while read remote config, err: %v", err)
		return err
	}
	log.Infof("Config loaded from remote")
	return nil
}
