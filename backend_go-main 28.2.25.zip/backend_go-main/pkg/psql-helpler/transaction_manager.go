package psqlhelper

import (
	"backend/pkg/constants"
	"context"
	"errors"
	"gorm.io/gorm"
)

type transactionManager struct {
	db *gorm.DB
}

type TransactionManager interface {
	BeginTransaction(ctx context.Context) (context.Context, error)
	CommitTransaction(ctx context.Context) error
	RollbackTransaction(ctx context.Context) error
	GetTransaction(ctx context.Context) interface{}
}

func NewTransactionManager(db *gorm.DB) TransactionManager {
	return &transactionManager{db: db}
}

func (tm *transactionManager) BeginTransaction(ctx context.Context) (context.Context, error) {
	tx := GetContextTransaction(ctx)
	if tx != nil {
		return ctx, nil
	}

	db := tm.db.Begin()
	if db.Error != nil {
		return ctx, db.Error
	}

	ctx = context.WithValue(ctx, constants.ContextKeyDBTransaction, db)
	return ctx, nil
}

func (tm *transactionManager) CommitTransaction(ctx context.Context) error {
	tx := GetContextTransaction(ctx)
	if tx == nil {
		return errors.New("no transaction found in context")
	}
	return tx.Commit().Error
}

func (tm *transactionManager) RollbackTransaction(ctx context.Context) error {
	tx := GetContextTransaction(ctx)
	if tx == nil {
		return errors.New("no transaction found in context")
	}
	return tx.Rollback().Error
}

func (tm *transactionManager) GetTransaction(ctx context.Context) interface{} {
	return ctx.Value(constants.ContextKeyDBTransaction)
}
