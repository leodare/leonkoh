package psqlhelper

import (
	"backend/pkg/constants"
	"backend/pkg/x-error"
	"context"
	"errors"
	"github.com/go-sql-driver/mysql"
	"gorm.io/gorm"
	"reflect"
)

type StringID interface {
	GetID() string
}

func GetContextTransaction(ctx context.Context) *gorm.DB {
	if tx, ok := ctx.Value(constants.ContextKeyDBTransaction).(*gorm.DB); ok {
		return tx
	}
	return nil
}

func GetTransactionDB(ctx context.Context, db *gorm.DB) *gorm.DB {
	tx := GetContextTransaction(ctx)
	if tx != nil {
		return tx
	}
	return db.WithContext(ctx)
}

func Insert(ctx context.Context, db *gorm.DB, value interface{}) (*string, error) {
	err := db.Create(value).Error
	if err != nil {
		var mErr *mysql.MySQLError
		if errors.As(err, &mErr) {
			return nil, x_error.NewError(x_error.DataInvalid)
		}
		return nil, err
	}

	if v, ok := value.(StringID); ok {
		id := v.GetID()
		return &id, nil
	}

	return nil, errors.New("failed to retrieve ID")
}

func InsertMultiple(ctx context.Context, db *gorm.DB, values interface{}) ([]string, error) {
	valueSlice := reflect.ValueOf(values)
	if valueSlice.Kind() != reflect.Slice {
		return nil, errors.New("values must be a slice")
	}
	err := db.Create(values).Error
	if err != nil {
		var mErr *mysql.MySQLError
		if errors.As(err, &mErr) {
			return nil, x_error.NewError(x_error.DataInvalid)
		}
		return nil, err
	}

	var ids []string
	for i := 0; i < valueSlice.Len(); i++ {
		if id, ok := valueSlice.Index(i).Interface().(StringID); ok {
			ids = append(ids, id.GetID())
		}
	}

	return ids, nil
}
