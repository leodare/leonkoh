package main

import (
	queue "backend/internal/infrastructure/queue/interface"
	"backend/pkg/logger"
	"context"
	"fmt"
)

type Consumer interface {
	Handle(ctx context.Context, message *queue.Message) (queue.Response, error)
}

type consumer struct {
}

func (c *consumer) Handle(ctx context.Context, message *queue.Message) (queue.Response, error) {
	ctxLogger := logger.NewLogger(ctx)
	ctxLogger.Infof("handle message: %s", []byte(fmt.Sprintf("%s", message.Meta)))
	return queue.Retry, nil
}

func NewConsumer() Consumer {
	return &consumer{}
}
