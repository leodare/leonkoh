package main

import (
	configType "backend/internal/config"
	"backend/internal/infrastructure/queue"
	queueInterface "backend/internal/infrastructure/queue/interface"
	"backend/pkg/config"
	"backend/pkg/constants"
	"backend/pkg/logger"
	"flag"
	"github.com/spf13/viper"
	"sync"
	"time"
)

type App struct {
	Name               string
	Version            string
	ConfigFilePath     string
	ConfigFile         string
	ConsumerConfigPath string
	ConsumeConfigFile  string
	consumerConfig     configType.ConsumerConfig
	queue              queueInterface.Queue
	consumer           Consumer
}

func (a *App) initFlag() {
	flag.StringVar(&a.Name, "name", "service-name", "")
	flag.StringVar(&a.Version, "version", "1.0.0", "")
	flag.StringVar(&a.ConfigFilePath, "config-file-path", "./configs", "Config file path: path to config dir")
	flag.StringVar(&a.ConfigFile, "config-file", "config", "Config file path: path to config dir")
	flag.StringVar(&a.ConsumerConfigPath, "consumer-config-path", "./cmd/consumer/demo-kafka", "Consumer config file path: path to config dir")
	flag.StringVar(&a.ConsumeConfigFile, "consumer-config-file", "consumer", "Consumer config file path: path to config dir")
	flag.Parse()
}

func (a *App) initConfig() {
	configFiles := []config.ConfigFile{
		{
			Path: a.ConfigFilePath,
			Name: a.ConfigFile,
		},
		{
			Path: a.ConsumerConfigPath,
			Name: a.ConsumeConfigFile,
		},
	}
	configSource := &config.Viper{
		ConfigType:  constants.ConfigTypeFile,
		ConfigFiles: configFiles,
	}
	err := configSource.InitConfig()
	if err != nil {
		panic(err)
	}
}

func (a *App) Run() error {
	ctx := logger.NewBackgroundContextWithTraceID("consumer-demo-kafka")
	ctxLogger := logger.NewLogger(ctx)
	wg := sync.WaitGroup{}
	wg.Add(1)
	go func() {
		err := a.queue.Consume(
			ctx,
			a.consumerConfig.Topic,
			a.consumer.Handle,
		)
		if err != nil {
			panic(err)
		}
		if a.consumerConfig.RetryTopic != nil {
			err := a.queue.Consume(
				ctx,
				*a.consumerConfig.RetryTopic,
				a.consumer.Handle,
			)
			if err != nil {
				panic(err)
			}
		}
	}()
	err := a.queue.Publish(ctx, "demo.test", &queueInterface.Message{
		Key:  map[string]string{"key": "value"},
		Data: map[string]string{"data": "value"},
		Meta: nil,
	})
	if err != nil {
		ctxLogger.Errorf("Error publish message: %v", err)
		return err
	}
	wg.Wait()
	return nil
}

func inject(
	app *App,
	consumer Consumer,
) error {
	retryDelay, err := time.ParseDuration(app.consumerConfig.RetryDelay)
	if err != nil {
		retryDelay = 3 * time.Second
	}
	commitInterval, err := time.ParseDuration(app.consumerConfig.CommitInterval)
	if err != nil {
		commitInterval = 0
	}
	queueInstance, err := queue.New(&queue.Config{
		Type: queue.Kafka,
		KafkaConfig: &queueInterface.KafkaConfig{
			Brokers:         app.consumerConfig.Brokers,
			GroupID:         app.consumerConfig.GroupID,
			MaxRetry:        app.consumerConfig.MaxRetry,
			RetryDelay:      &retryDelay,
			DeadLetterTopic: app.consumerConfig.DeadLetterTopic,
			CommitInterval:  commitInterval,
			RetryTopic:      app.consumerConfig.RetryTopic,
		},
	})
	app.queue = queueInstance
	app.consumer = consumer
	return nil
}

func main() {
	app := &App{}
	app.initFlag()
	app.initConfig()
	consumerConfig := configType.ConsumerConfig{}
	httpConfig := configType.HttpConfig{}
	err := viper.UnmarshalKey("demoKafka", &consumerConfig)
	if err != nil {
		panic(err)
	}
	err = viper.UnmarshalKey("http", &httpConfig)
	if err != nil {
		panic(err)
	}
	app.consumerConfig = consumerConfig
	err = wireApp(app)
	if err != nil {
		panic(err)
	}

	if err := app.Run(); err != nil {
		panic(err)
	}

}
