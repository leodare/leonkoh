package main

import (
	"backend/cmd/cli/gen/cmd"
	"fmt"
)

func main() {
	err := GenerateCode("configs/repo.yaml")
	if err != nil {
		fmt.Println("Error generating code:", err)
	} else {
		fmt.Println("Code generated successfully!")
	}
}

func GenerateCode(configPath string) error {
	config, err := cmd.ParseYAMLConfig(configPath)
	if err != nil {
		return err
	}

	err = cmd.GenerateUseCases(config)
	if err != nil {
		return err
	}
	err = cmd.GenerateControllersAndRouters(config)
	if err != nil {
		return err
	}

	err = cmd.GenerateRepositories(config)
	if err != nil {
		return err
	}
	return nil
}
