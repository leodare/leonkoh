package cmd

import (
	"backend/pkg/utils"
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"text/template"
)

// GenerateRequestResponseTypes tạo các cấu trúc Request và Response trong một file nhất định
func GenerateRequestResponseTypes(templatePath, outputPath string, data map[string]interface{}) error {
	methodName := data["MethodName"].(string)
	requestType := methodName + "Request"
	responseType := methodName + "Response"
	packageName := data["PackageName"].(string)

	// Kiểm tra nếu Request và Response đã tồn tại trong file
	if StructTypeExistsInFile(outputPath, requestType) && StructTypeExistsInFile(outputPath, responseType) {
		fmt.Printf("Types %s and %s already exist in %s\n", requestType, responseType, outputPath)
		return nil
	}

	// Đọc template để sinh mã cho Request và Response
	funcMap := template.FuncMap{
		"titleCase": utils.TitleCase,
		"camelCase": utils.CamelCase,
		"lower":     utils.Lower,
	}

	tmpl, err := template.New(filepath.Base(templatePath)).Funcs(funcMap).ParseFiles(templatePath)
	if err != nil {
		return err
	}
	// Đảm bảo thư mục đích tồn tại
	if err := os.MkdirAll(filepath.Dir(outputPath), os.ModePerm); err != nil {
		return err
	}
	// Mở file requests.go để ghi thêm hoặc tạo file nếu chưa có
	fileExists := fileExists(outputPath)
	outputFile, err := os.OpenFile(outputPath, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0644)
	if err != nil {
		return err
	}
	defer outputFile.Close()

	writer := bufio.NewWriter(outputFile)

	// Nếu file mới được tạo, thêm khai báo package ở đầu file
	if !fileExists {
		_, err := writer.WriteString("package " + packageName + "\n\n")
		if err != nil {
			return err
		}
	}

	// Ghi struct Request vào file nếu chưa tồn tại
	if !StructTypeExistsInFile(outputPath, requestType) {
		data["TypeName"] = requestType
		if err := tmpl.Execute(writer, data); err != nil {
			return err
		}
	}

	// Ghi struct Response vào file nếu chưa tồn tại và không bị bỏ qua
	if !StructTypeExistsInFile(outputPath, responseType) {
		data["TypeName"] = responseType
		if err := tmpl.Execute(writer, data); err != nil {
			return err
		}
	}

	writer.Flush()
	fmt.Printf("Appended types %s and %s to %s\n", requestType, responseType, outputPath)
	return nil
}
