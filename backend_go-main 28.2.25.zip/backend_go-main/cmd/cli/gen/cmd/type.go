package cmd

import (
	"gopkg.in/yaml.v2"
	"io/ioutil"
)

type Config struct {
	ModulePath string            `yaml:"modulePath"`
	Domains    map[string]Domain `yaml:"domains"`
}

type Domain struct {
	Cases []Case `yaml:"cases"`
}

type Case struct {
	OnlyController bool   `yaml:"onlyController"`
	OnlyUseCase    bool   `yaml:"onlyUseCase"`
	Name           string `yaml:"name"`
	UseMiddleware  bool   `yaml:"useMiddleware"`
	SkipResponse   bool   `yaml:"skipResponse"`
	Path           string `yaml:"path"`
	Method         string `yaml:"method"`
}

func ParseYAMLConfig(path string) (*Config, error) {
	data, err := ioutil.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var config Config
	err = yaml.Unmarshal(data, &config)
	if err != nil {
		return nil, err
	}
	return &config, nil
}
