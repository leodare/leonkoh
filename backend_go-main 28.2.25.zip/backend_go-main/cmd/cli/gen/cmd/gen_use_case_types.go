package cmd

import (
	"backend/pkg/utils"
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"text/template"
)

// Hàm bổ sung các cấu trúc Input và Output vào file types.go nếu chúng chưa tồn tại
func AppendTypeIfMissing(templatePath, outputPath string, data map[string]interface{}) error {
	usecaseName := data["UseCaseName"].(string)
	inputType := usecaseName + "Input"
	packageName := data["PackageName"].(string)

	// Kiểm tra xem có cần bỏ qua việc tạo Output (response) hay không
	skipResponse, _ := data["SkipResponse"].(bool)
	outputType := ""
	if !skipResponse {
		outputType = usecaseName + "Output"
	}

	// Kiểm tra nếu InputType đã tồn tại và (OutputType cũng tồn tại hoặc bị bỏ qua), không cần bổ sung
	if StructTypeExistsInFile(outputPath, inputType) && (skipResponse || StructTypeExistsInFile(outputPath, outputType)) {
		fmt.Printf("Types %s and %s already exist or skipped in %s\n", inputType, outputType, outputPath)
		return nil
	}

	// Đọc template types.go.tpl để sinh mã cho các cấu trúc Input và Output
	funcMap := template.FuncMap{
		"titleCase": utils.TitleCase,
		"camelCase": utils.CamelCase,
		"lower":     utils.Lower,
	}

	tmpl, err := template.New(filepath.Base(templatePath)).Funcs(funcMap).ParseFiles(templatePath)
	if err != nil {
		return err
	}

	// Mở file types.go để ghi thêm hoặc tạo file nếu chưa có
	fileExists := fileExists(outputPath)
	outputFile, err := os.OpenFile(outputPath, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0644)
	if err != nil {
		return err
	}
	defer outputFile.Close()

	writer := bufio.NewWriter(outputFile)

	// Nếu file mới được tạo, thêm khai báo package ở đầu file
	if !fileExists {
		_, err := writer.WriteString("package " + packageName + "\n")
		if err != nil {
			return err
		}
	}

	// Thêm struct Input từ template vào types.go nếu chưa tồn tại
	if !StructTypeExistsInFile(outputPath, inputType) {

		_, err = writer.WriteString("\n")
		if err != nil {
			return err
		}
		// Thực thi template với dữ liệu cho Input struct
		data["TypeName"] = inputType
		if err := tmpl.Execute(writer, data); err != nil {
			return err
		}
	}

	writer.Flush()
	fmt.Printf("Appended types %s and %s to %s\n", inputType, outputType, outputPath)
	return nil
}
