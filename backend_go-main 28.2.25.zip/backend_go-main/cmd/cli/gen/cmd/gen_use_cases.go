package cmd

import (
	"backend/pkg/utils"
	"fmt"
	"path/filepath"
)

// Hàm sinh mã cho từng use case trong mỗi domain và cập nhật `AutoGenCodeUseCasesProvider`
func GenerateUseCases(config *Config) error {
	// Chuẩn bị các danh sách cho wire_autogen.go
	imports := make(map[string]string)
	autoGenProviders := []string{}

	for domainName, domain := range config.Domains {
		if len(domain.Cases) == 0 {
			continue
		}
		packageName := utils.ToSnakeCase(domainName)

		for _, useCase := range domain.Cases {
			if useCase.OnlyController {
				continue
			}
			// Tạo `Input` và `Output` dựa trên `name`
			inputType := utils.TitleCase(useCase.Name) + "Input"
			outputType := utils.TitleCase(useCase.Name) + "Output"

			// Chuẩn bị dữ liệu cho template
			useCaseData := map[string]interface{}{
				"ModulePath":       config.ModulePath,
				"PackageName":      packageName,
				"UseCaseName":      utils.TitleCase(useCase.Name),
				"UseCaseInterface": utils.TitleCase(useCase.Name) + "UseCase",
				"UseCaseStruct":    utils.CamelCase(useCase.Name) + "UseCase",
				"InputType":        inputType,
				"OutputType":       outputType,
				"SkipResponse":     useCase.SkipResponse,
			}

			// Chọn template dựa trên cài đặt `UseMiddleware`
			var templatePath string
			if useCase.UseMiddleware {
				templatePath = "cmd/cli/gen/templates/usecase.use_middleware.go.tpl"
			} else {
				templatePath = "cmd/cli/gen/templates/usecase.normal.go.tpl"
			}

			// Đường dẫn mặc định cho các use case trong thư mục domain trong `internal/usecases`
			basePath := filepath.Join("internal", "usecases", utils.ToKebabCase(domainName))

			// Tạo tên file theo quy tắc snake_case
			fileName := utils.ToSnakeCase(useCase.Name) + ".go"
			outputPath := filepath.Join(basePath, fileName)

			// Sinh mã file use case chính
			err := GenerateFileFromTemplate(templatePath, outputPath, useCaseData)
			if err != nil {
				return err
			}

			// Bổ sung các cấu trúc Input và Output vào types.go nếu cần
			typesFilePath := filepath.Join(basePath, "types.go")
			err = AppendTypeIfMissing("cmd/cli/gen/templates/usecases.types.go.tpl", typesFilePath, useCaseData)
			if err != nil {
				return err
			}

			// Cập nhật danh sách providers và imports
			providerName := fmt.Sprintf("%s.New%sUseCase", packageName, utils.TitleCase(useCase.Name))
			autoGenProviders = append(autoGenProviders, providerName)

			// Chỉ thêm import nếu chưa có cho domain này
			if _, exists := imports[packageName]; !exists {
				importPath := fmt.Sprintf("%s/internal/usecases/%s", config.ModulePath, utils.ToKebabCase(domainName))
				imports[packageName] = importPath
			}
		}
	}

	// Sau khi tất cả các use case đã được sinh mã, tạo file wire_autogen.go
	outputPath := "internal/usecases/provider.go" // Đường dẫn đến file wire_autogen.go
	err := GenUseCaseProviderFile(imports, autoGenProviders, outputPath)
	if err != nil {
		return err
	}

	fmt.Println("Generated wire_autogen.go successfully.")
	return nil
}
