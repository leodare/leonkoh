package cmd

import (
	"backend/pkg/utils"
	"fmt"
	"path/filepath"
)

// GenerateControllersAndRouters sinh mã cho controller, router, và mapper từ cấu hình
func GenerateControllersAndRouters(config *Config) error {
	var (
		routerImports   = make([]string, 0, len(config.Domains))
		routerFunctions = make([]string, 0, len(config.Domains))
		sources         = make([]string, 0, len(config.Domains))
	)

	for domainName, domain := range config.Domains {
		if len(domain.Cases) == 0 {
			continue
		}
		packageName := utils.ToSnakeCase(domainName)
		controllerName := utils.TitleCase(domainName) + "Controller"
		folderName := utils.ToKebabCase(domainName)

		routerImports = append(routerImports, fmt.Sprintf("\"%s/cmd/api/controllers/%s\"", config.ModulePath, folderName))
		routerFunctions = append(routerFunctions, fmt.Sprintf("%s.NewController", packageName))

		controllerData := buildControllerData(config, domainName, packageName, controllerName, folderName)
		routerData := buildRouterData(config, domainName, packageName, controllerName)

		totalOnlyUseCase := 0
		for _, c := range domain.Cases {
			if c.OnlyUseCase {
				totalOnlyUseCase++
				if len(routerImports) > 0 {
					routerImports = routerImports[:len(routerImports)-1]
					routerFunctions = routerFunctions[:len(routerFunctions)-1]
				}
				continue
			}
			if err := processUseCase(config, domainName, folderName, packageName, &controllerData, &routerData, c); err != nil {
				return err
			}
		}
		if totalOnlyUseCase != len(domain.Cases) {
			sources = append(sources, domainName)
		}

		if err := generateControllerFiles(folderName, controllerData, routerData); err != nil {
			return err
		}
	}

	return generateRouterProvider(sources, routerImports, routerFunctions)
}

// Helper function to build controller data
func buildControllerData(config *Config, domainName, packageName, controllerName, folderName string) map[string]interface{} {
	return map[string]interface{}{
		"ModulePath":     config.ModulePath,
		"PackageName":    packageName,
		"ControllerName": controllerName,
		"DomainName":     domainName,
		"FolderName":     folderName,
		"UseCases":       []map[string]string{},
		"Endpoints":      []map[string]string{},
	}
}

// Helper function to build router data
func buildRouterData(config *Config, domainName, packageName, controllerName string) map[string]interface{} {
	return map[string]interface{}{
		"ModulePath":     config.ModulePath,
		"PackageName":    packageName,
		"ControllerName": controllerName,
		"Routes":         []map[string]string{},
		"Source":         utils.ToKebabPlural(domainName),
	}
}

// Process individual use cases and generate required types and mapper
func processUseCase(config *Config, source, folderName, packageName string, controllerData, routerData *map[string]interface{}, useCase Case) error {
	useCaseTypeName := ""
	useCaseVarName := ""
	useCaseInputType := ""
	useCaseOutputType := ""
	useUsecaseMiddleware := ""

	if useCase.UseMiddleware {
		useUsecaseMiddleware = "true"
	}

	if !useCase.OnlyController {
		useCaseTypeName = utils.TitleCase(useCase.Name) + "UseCase"
		useCaseVarName = utils.CamelCase(useCase.Name) + "UseCase"
		useCaseInputType = utils.TitleCase(useCase.Name) + "Input"
		useCaseOutputType = utils.TitleCase(useCase.Name) + "Output"
		(*controllerData)["UseCases"] = append((*controllerData)["UseCases"].([]map[string]string), map[string]string{
			"TypeName": useCaseTypeName,
			"VarName":  useCaseVarName,
			"Name":     useCase.Name,
		})
	}
	// convert bool to string

	(*routerData)["Routes"] = append((*routerData)["Routes"].([]map[string]string), map[string]string{
		"Method":  useCase.Method,
		"Path":    useCase.Path,
		"Handler": utils.TitleCase(useCase.Name),
	})

	(*controllerData)["Endpoints"] = append((*controllerData)["Endpoints"].([]map[string]string), map[string]string{
		"MethodName":           utils.TitleCase(useCase.Name),
		"Path":                 useCase.Path,
		"Method":               useCase.Method,
		"VarName":              useCaseVarName,
		"Source":               utils.ToKebabPlural(source),
		"UseUsecaseMiddleware": useUsecaseMiddleware,
	})

	return generateMapperAndTypes(config, folderName, packageName, useCase, useCaseInputType, useCaseOutputType)
}

// Generate Mapper and Request/Response Types
func generateMapperAndTypes(config *Config, folderName, packageName string, useCase Case, inputType, outputType string) error {
	if useCase.OnlyController {
		return nil
	}
	if err := GenerateRequestResponseTypes(
		"cmd/cli/gen/templates/types_request_response.go.tpl",
		filepath.Join("cmd", "api", "controllers", folderName, "dto.go"),
		map[string]interface{}{
			"MethodName":  utils.TitleCase(useCase.Name),
			"PackageName": packageName,
		},
	); err != nil {
		return err
	}

	return GenerateMapper(
		useCase.SkipResponse,
		"cmd/cli/gen/templates/mapper.go.tpl",
		filepath.Join("cmd", "api", "controllers", folderName, "mapper.go"),
		map[string]interface{}{
			"PackageName":       packageName,
			"RequestType":       utils.TitleCase(useCase.Name) + "Request",
			"ResponseType":      utils.TitleCase(useCase.Name) + "Response",
			"UseCaseInputType":  inputType,
			"UseCaseOutputType": outputType,
			"FolderName":        folderName,
			"ModulePath":        config.ModulePath,
			"UseCaseName":       utils.TitleCase(useCase.Name),
		},
	)
}

func genControllerFile(folderName string, controllerData map[string]interface{}) error {
	controllerPath := filepath.Join("cmd", "api", "controllers", folderName, "v1.go")
	if exists := fileExists(controllerPath); exists {
		existingControllers, err := detectExistingControllersInControllersFile(controllerPath)
		if err != nil {
			return err
		}

		newControllers := filterNewControllers(existingControllers, controllerData["Endpoints"].([]map[string]string))
		if len(newControllers) == 0 {
			return nil
		}
		newRouter := filterNewControllersInV1File(existingControllers, controllerData["UseCases"].([]map[string]string))
		if len(newRouter) == 0 {
			return nil
		}
		if len(newControllers) > 0 {
			temporaryController := controllerData
			temporaryController["Endpoints"] = newControllers
			temporaryController["UseCases"] = newRouter

			// Thêm uscase mới vào `interface Controller`
			if err := appendToFileFromTemplate("cmd/cli/gen/templates/controller_add_usecase_to_interface.go.tpl", controllerPath, temporaryController, "type controller struct {"); err != nil {
				return err
			}

			// thêm usecase vào new controller args
			if err := appendToFileFromTemplate("cmd/cli/gen/templates/controller_add_agrs_to_func_new.go.tpl", controllerPath, temporaryController, "func NewController("); err != nil {
				return err
			}
			// thêm usecase vào new controller return
			if err := appendToFileFromTemplate("cmd/cli/gen/templates/controller_add_usecase_to_func_return.go.tpl", controllerPath, temporaryController, "return &controller{"); err != nil {
				return err
			}
			// thêm controller func
			if err := appendToFileFromTemplate("cmd/cli/gen/templates/controller_add_item.go.tpl", controllerPath, temporaryController, "implement bottom"); err != nil {
				return err
			}
			fmt.Println("New controllers to be added:", newControllers)
			return nil
		}
	}

	if err := GenerateFileFromTemplate("cmd/cli/gen/templates/controller.go.tpl",
		filepath.Join("cmd", "api", "controllers", folderName, "v1.go"), controllerData); err != nil {
		return err
	}

	return nil
}

// Generate Controller and Router Files
func generateControllerFiles(folderName string, controllerData, routerData map[string]interface{}) error {
	if len(controllerData["Endpoints"].([]map[string]string)) == 0 {
		return nil
	}
	err := genControllerFile(folderName, controllerData)
	if err != nil {
		return err
	}

	routeFilePath := filepath.Join("cmd", "api", "controllers", folderName, "controller.go")
	// Kiểm tra xem file controller đã tồn tại chưa
	if fileExists(routeFilePath) {
		existingControllers, err := detectExistingControllers(routeFilePath)
		if err != nil {
			return err
		}

		newControllers := filterNewControllers(existingControllers, controllerData["Endpoints"].([]map[string]string))
		if len(newControllers) == 0 {
			return nil
		}
		if len(newControllers) > 0 {
			controllerData["Endpoints"] = newControllers
			routerData["Routes"] = newControllers

			// Thêm controller mới vào `interface Controller`
			if err := appendToFileFromTemplate("cmd/cli/gen/templates/controller_add.go.tpl", routeFilePath, routerData, "type Controller interface {"); err != nil {
				return err
			}

			// Thêm route mới vào `RegisterRouterV1`
			if err := appendToFileFromTemplate("cmd/cli/gen/templates/routes_add.go.tpl", routeFilePath, routerData, "// implement controller to here"); err != nil {
				return err
			}
			fmt.Println("New controllers to be added:", newControllers)
			return nil
		}
	}

	return GenerateFileFromTemplate("cmd/cli/gen/templates/routes.go.tpl",
		filepath.Join("cmd", "api", "controllers", folderName, "controller.go"), routerData)
}

// Generate Router Provider File
func generateRouterProvider(source, imports, routers []string) error {
	if routers == nil || len(routers) == 0 {
		return nil
	}
	mainPath := filepath.Join("cmd", "api", "main.go")
	currentImportInMain, err := checkControllerImportsInMain(mainPath)
	if err != nil {
		return err
	}
	missingImportInMain := findMissingImportsInMain(source, currentImportInMain)
	if len(missingImportInMain) > 0 {
		err = addMissingImportsForMain(mainPath, missingImportInMain)
		if err != nil {
			return err
		}
		err = addMissingControllersToStructForMain(mainPath, source)
		if err != nil {
			return err
		}
		err = addRoutesToRegisterRouteForMain(mainPath, source)
		if err != nil {
			return err
		}
		err = addControllersToInjectFuncDependencies(mainPath, source)
		if err != nil {
			return err
		}

		err = addControllersToInjectFuncParams(mainPath, source)
		if err != nil {
			return err
		}
	}

	//mainPath := filepath.Join("cmd", "api", "main.go")

	outputPath := filepath.Join("cmd", "api", "controllers", "provider.go")
	if exists := fileExists(outputPath); exists {
		missingImports, missingRouters, err := filterNewControllersInProviderFile(outputPath, imports, routers)
		if err != nil {
			return err
		}

		fmt.Println("Missing imports: ", missingImports)
		fmt.Println("Missing routers: ", missingRouters)
		if len(missingImports) > 0 {
			err = appendToFileFromTemplate("cmd/cli/gen/templates/router_provider_add_import.go.tpl", outputPath, map[string]interface{}{
				"Imports": missingImports,
			}, "import (")
			if err != nil {
				return err
			}
		}
		if len(missingRouters) > 0 {
			err = appendToFileFromTemplate("cmd/cli/gen/templates/router_provider_add_new_controller.go.tpl", outputPath, map[string]interface{}{
				"Routers": missingRouters,
			}, "var ControllerProviders = wire.NewSet(")
			if err != nil {
				return err
			}
		}
		return nil
	}

	return GenerateFileFromTemplate("cmd/cli/gen/templates/router_provider_add_new_controller.go.tpl",
		"cmd/api/controllers/provider.go",
		map[string]interface{}{
			"Routers": routers,
		},
	)
}
