package cmd

import (
	"bytes"
	"os"
	"strings"
	"text/template"
)

func appendToFileFromTemplate(templatePath, filePath string, data map[string]interface{}, section string) error {
	// check file exists
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return os.ErrNotExist
	}
	content, err := GenerateFileContentFromTemplate(templatePath, data)
	if err != nil {
		return err
	}
	content = strings.TrimRight(content, " \n\t")
	fileContent, err := os.ReadFile(filePath)
	if err != nil && !os.IsNotExist(err) {
		return err
	}

	contentStr := string(fileContent)

	position := findInsertPosition(contentStr, section)

	// Chèn nội dung mới vào vị trí tìm được
	updatedContent := contentStr[:position] + content + contentStr[position:]

	return os.WriteFile(filePath, []byte(updatedContent), 0644)
}

// GenerateFileContentFromTemplate tạo nội dung từ template với dữ liệu truyền vào
func GenerateFileContentFromTemplate(templatePath string, data map[string]interface{}) (string, error) {
	tmpl, err := template.ParseFiles(templatePath)
	if err != nil {
		return "", err
	}

	var buf bytes.Buffer
	if err := tmpl.Execute(&buf, data); err != nil {
		return "", err
	}

	return buf.String(), nil
}
