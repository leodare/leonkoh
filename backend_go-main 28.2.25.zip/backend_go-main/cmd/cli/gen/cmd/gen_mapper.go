package cmd

import (
	"backend/pkg/utils"
	"bufio"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"strings"
	"text/template"
)

// GenerateMapper tạo hoặc bổ sung các hàm mapper nếu chúng chưa tồn tại hoặc chưa hoàn chỉnh
func GenerateMapper(skipRes bool, templatePath, outputPath string, data map[string]interface{}) error {
	funcMap := template.FuncMap{
		"titleCase": utils.TitleCase,
		"camelCase": utils.CamelCase,
		"lower":     utils.Lower,
	}

	tmpl, err := template.New(filepath.Base(templatePath)).Funcs(funcMap).ParseFiles(templatePath)
	if err != nil {
		return err
	}

	// Tạo thư mục nếu chưa tồn tại
	err = os.MkdirAll(filepath.Dir(outputPath), os.ModePerm)
	if err != nil {
		return err
	}

	// Mở hoặc tạo file mapper.go
	fileExists := fileExists(outputPath)
	outputFile, err := os.OpenFile(outputPath, os.O_RDWR|os.O_CREATE, 0644)
	if err != nil {
		return err
	}
	defer outputFile.Close()

	// Đọc toàn bộ nội dung của file để kiểm tra sự tồn tại của các hàm và import
	content, err := ioutil.ReadAll(outputFile)
	if err != nil {
		return err
	}
	outputContent := string(content)

	writer := bufio.NewWriter(outputFile)

	// Kiểm tra và thêm phần import nếu cần
	importStatement := fmt.Sprintf("\"%s/internal/usecases/%s\"", data["ModulePath"], data["FolderName"])
	needsImport := !strings.Contains(outputContent, importStatement)
	data["NeedsImport"] = needsImport

	// Thêm package và import nếu file mới được tạo hoặc nếu cần
	if !fileExists || needsImport {
		header := fmt.Sprintf("package %s\n\n", data["PackageName"])
		if needsImport {
			header += fmt.Sprintf("import (\n\t%s\n)\n\n", importStatement)
		}
		writer.WriteString(header)
	}

	// Kiểm tra và chỉ bổ sung `TODO` nếu chưa có trong hàm MapToUseCaseInput
	useCaseInputFuncName := "MapTo" + data["UseCaseInputType"].(string)
	if !strings.Contains(outputContent, useCaseInputFuncName) {
		// Sinh mã hàm nếu hàm chưa tồn tại
		if err := tmpl.ExecuteTemplate(writer, "MapToUseCaseInput", data); err != nil {
			return err
		}
	} else if !strings.Contains(outputContent, "// TODO: Gán các trường từ req sang UseCase input") {
		// Chỉ thêm `TODO` nếu hàm đã có nhưng thiếu `TODO`
		outputContent = strings.Replace(outputContent, "{\n", "{\n\t// TODO: Gán các trường từ req sang UseCase input\n", 1)
		writer.WriteString(outputContent)
	}
	if !skipRes {
		responseFuncName := "MapTo" + data["ResponseType"].(string)
		if !strings.Contains(outputContent, responseFuncName) {
			// Sinh mã hàm nếu hàm chưa tồn tại
			if err := tmpl.ExecuteTemplate(writer, "MapToResponse", data); err != nil {
				return err
			}
		} else if !strings.Contains(outputContent, "// TODO: Gán các trường từ output sang response") {
			// Chỉ thêm `TODO` nếu hàm đã có nhưng thiếu `TODO`
			outputContent = strings.Replace(outputContent, "{\n", "{\n\t// TODO: Gán các trường từ output sang response\n", 1)
			writer.WriteString(outputContent)
		}
	}

	writer.Flush()
	fmt.Printf("Updated mapper functions for %s in %s\n", data["UseCaseName"], outputPath)
	return nil
}
