package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"text/template"
)

// Hàm tạo file `wire_autogen.go` cho các use case tự động sinh
func GenUseCaseProviderFile(imports map[string]string, autoGenProviders []string, outputPath string) error {
	// check if the output file exists
	if _, err := os.Stat(outputPath); err == nil {
		existingUsecases, err := detectExistingUsecases(outputPath)
		if err != nil {
			return err
		}

		newUsecases := filterNewUseCases(existingUsecases, autoGenProviders)

		if len(newUsecases) == 0 {
			return nil
		}

		missingImport, err := getMissingImports(outputPath, imports)
		if err != nil {
			return err
		}

		if len(missingImport) > 0 {
			err = addMissingImports(outputPath, missingImport)
			if err != nil {
				return err
			}
		}

		err = appendToFileFromTemplate("cmd/cli/gen/templates/usecase_add.go.tpl", outputPath, map[string]interface{}{
			"Providers": newUsecases,
		}, "var UseCaseProviders = wire.NewSet(")
		return err
	}

	// Định nghĩa đường dẫn đến file template
	templatePath := "cmd/cli/gen/templates/usecase_provider_autogen.go.tpl"

	// Kiểm tra xem file template có tồn tại không
	if _, err := os.Stat(templatePath); os.IsNotExist(err) {
		return fmt.Errorf("template file %s does not exist", templatePath)
	}

	// Mở template file
	tmpl, err := template.ParseFiles(templatePath)
	if err != nil {
		return fmt.Errorf("failed to parse template file: %v", err)
	}

	// Tạo thư mục đầu ra nếu chưa có
	outputDir := filepath.Dir(outputPath)
	err = os.MkdirAll(outputDir, os.ModePerm)
	if err != nil {
		return fmt.Errorf("failed to create directories: %v", err)
	}

	outputFile, err := os.Create(outputPath)
	if err != nil {
		return fmt.Errorf("failed to create output file: %v", err)
	}
	defer outputFile.Close()

	// Chuẩn bị dữ liệu cho template
	data := map[string]interface{}{
		"Imports":   imports,
		"Providers": autoGenProviders,
	}

	// Ghi dữ liệu vào file wire_autogen.go
	if err := tmpl.Execute(outputFile, data); err != nil {
		return fmt.Errorf("failed to execute template: %v", err)
	}

	return nil
}
