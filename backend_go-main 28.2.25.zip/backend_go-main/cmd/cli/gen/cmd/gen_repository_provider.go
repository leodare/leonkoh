package cmd

import (
	"path/filepath"
)

func GenerateRepositoryProvider(providers []string, modulePath string) error {
	// Dữ liệu cho template provider
	data := map[string]interface{}{
		"ModulePath": modulePath,
		"Providers":  providers,
	}
	repositoryProviderPath := filepath.Join("internal", "infrastructure", "provider.go")
	if fileExists(repositoryProviderPath) {
		//err := detectAndInsertImport(repositoryProviderPath)
		//if err != nil {
		//	return err
		//}
		existingRepos, err := detectExistingRepositories(repositoryProviderPath)
		if err != nil {
			return err
		}

		newRepositories := filterNewRepositories(existingRepos, data["Providers"].([]string))
		if len(newRepositories) == 0 {
			return nil
		}
		if err := appendToFileFromTemplate("cmd/cli/gen/templates/repository_add_provider.go.tpl", repositoryProviderPath, data, "var DBProvider = wire.NewSet("); err != nil {
			return err
		}
		return nil
	}

	// Đường dẫn file provider

	// Đường dẫn tới template provider
	providerTemplatePath := "cmd/cli/gen/templates/repository_provider.go.tpl"
	return GenerateFileFromTemplate(providerTemplatePath, repositoryProviderPath, data)
}
