package cmd

import (
	"backend/pkg/utils"
	"fmt"
	"os"
	"path/filepath"
	"text/template"
)

func GenerateFileFromTemplate(templatePath, outputPath string, data interface{}) error {
	funcMap := template.FuncMap{
		"titleCase":   utils.TitleCase,
		"toCamelCase": utils.CamelCase,
		"lower":       utils.Lower,
	}

	tmpl, err := template.New(filepath.Base(templatePath)).Funcs(funcMap).ParseFiles(templatePath)
	if err != nil {
		return err
	}

	outputDir := filepath.Dir(outputPath)
	err = os.MkdirAll(outputDir, os.ModePerm)
	if err != nil {
		return fmt.Errorf("failed to create directories: %v", err)
	}

	outputFile, err := os.Create(outputPath)
	if err != nil {
		return err
	}
	defer outputFile.Close()

	return tmpl.Execute(outputFile, data)
}
