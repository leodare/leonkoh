package cmd

import (
	"backend/pkg/utils"
	"fmt"
	"path/filepath"
)

// GenerateRepositories sinh mã cho các entities, repository interface, và implementation từ cấu hình
func GenerateRepositories(config *Config) error {
	repositoryProviders := []string{} // Danh sách các repository provider

	for domainName, c := range config.Domains {
		sumCaseHaveNoRepository := 0
		for _, ca := range c.Cases {
			if ca.OnlyUseCase {
				sumCaseHaveNoRepository++
			}
		}
		if sumCaseHaveNoRepository == len(c.Cases) && sumCaseHaveNoRepository != 0 {
			continue
		}

		entityName := utils.TitleCase(domainName) // Tên entity từ domain
		repositoryInterfaceName := entityName + "Repository"
		repositoryVarName := utils.CamelCase(domainName)
		tableName := utils.ToSnakeCase(domainName) + "s" // Đặt tên bảng dạng số nhiều

		// Dữ liệu cho entity
		entityData := map[string]interface{}{
			"EntityName":        entityName,
			"DatabaseTableName": tableName,
		}
		// Dữ liệu cho repository interface
		repositoryInterfaceData := map[string]interface{}{
			"ModulePath":              config.ModulePath,
			"EntityName":              entityName,
			"RepositoryInterfaceName": repositoryInterfaceName,
		}
		// Dữ liệu cho repository implementation
		repositoryPostgresData := map[string]interface{}{
			"ModulePath":              config.ModulePath,
			"EntityName":              entityName,
			"RepositoryInterfaceName": repositoryInterfaceName,
			"RepositoryVarName":       repositoryVarName,
			"DatabaseTableName":       tableName,
		}

		// Tạo file entity nếu chưa tồn tại
		entityTemplatePath := "cmd/cli/gen/templates/entity.go.tpl"
		entityOutputPath := filepath.Join("internal", "entities", utils.ToSnakeCase(domainName)+".go")
		if !fileExists(entityOutputPath) {
			if err := GenerateFileFromTemplate(entityTemplatePath, entityOutputPath, entityData); err != nil {
				return err
			}
		}

		// Tạo file repository interface nếu chưa tồn tại
		repositoryInterfaceTemplatePath := "cmd/cli/gen/templates/repository_interface.go.tpl"
		repositoryInterfaceOutputPath := filepath.Join("internal", "repositories", utils.ToSnakeCase(domainName)+".go")
		if !fileExists(repositoryInterfaceOutputPath) {
			if err := GenerateFileFromTemplate(repositoryInterfaceTemplatePath, repositoryInterfaceOutputPath, repositoryInterfaceData); err != nil {
				return err
			}
		}

		// Tạo file repository implementation cho Postgres nếu chưa tồn tại
		repositoryPostgresTemplatePath := "cmd/cli/gen/templates/repository_postgres.go.tpl"
		repositoryPostgresOutputPath := filepath.Join("internal", "infrastructure", "persistence", "postgres", utils.ToSnakeCase(domainName)+".go")
		if !fileExists(repositoryPostgresOutputPath) {
			if err := GenerateFileFromTemplate(repositoryPostgresTemplatePath, repositoryPostgresOutputPath, repositoryPostgresData); err != nil {
				return err
			}
		}
		repositoryProviders = append(repositoryProviders, fmt.Sprintf("postgres.New%s", repositoryInterfaceName))

	}
	// Sinh mã cho file repository provider
	if err := GenerateRepositoryProvider(repositoryProviders, config.ModulePath); err != nil {
		return err
	}
	fmt.Println("Entities, repositories, and repository implementations generated successfully.")
	return nil
}
