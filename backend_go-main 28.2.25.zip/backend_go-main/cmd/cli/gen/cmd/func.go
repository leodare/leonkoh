package cmd

import (
	"backend/pkg/utils"
	"bufio"
	"bytes"
	"fmt"
	"io/ioutil"
	"os"
	"regexp"
	"strings"
)

// Hàm kiểm tra xem một struct với tên cụ thể đã tồn tại trong file hay chưa
func StructTypeExistsInFile(filePath, structName string) bool {
	file, err := os.Open(filePath)
	if err != nil {
		return false
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		if strings.Contains(scanner.Text(), "type "+structName+" struct") {
			return true // Struct đã tồn tại
		}
	}
	return false // Struct chưa tồn tại
}

// Hàm kiểm tra sự tồn tại của file
func fileExists(filePath string) bool {
	_, err := os.Stat(filePath)
	return !os.IsNotExist(err)
}

func detectExistingControllers(filePath string) (map[string]bool, error) {
	existingFuncs := make(map[string]bool)
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	// regex to match with controler.

	re := regexp.MustCompile(`(\w+)\(ctx\s+\*gin.Context\)`) // Regex to match function names
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		matches := re.FindStringSubmatch(line)
		if len(matches) > 1 {
			funcName := matches[1]
			existingFuncs[funcName] = true
		}
	}

	return existingFuncs, scanner.Err()
}

func detectExistingRepositories(filePath string) (map[string]bool, error) {
	existingRepos := make(map[string]bool)
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	// Regex để tìm các hàm repository đầy đủ như `postgres.NewGenCaseRepository`
	re := regexp.MustCompile(`(postgres\.New\w+Repository)`)
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		matches := re.FindStringSubmatch(line)
		if len(matches) > 1 {
			fullRepoName := matches[1]
			existingRepos[fullRepoName] = true
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return existingRepos, nil
}
func detectExistingUsecases(filePath string) (map[string]bool, error) {
	useCases := make(map[string]bool)
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	// Regex để tìm các tên use case với định dạng "source.UseCase,"
	re := regexp.MustCompile(`\b([\w\.]+UseCase)\b,`)

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		matches := re.FindAllStringSubmatch(line, -1)

		for _, match := range matches {
			if len(match) > 1 {
				useCaseWithSource := match[1]
				useCases[useCaseWithSource] = true
			}
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return useCases, nil
}

func detectExistingControllersInControllersFile(filePath string) (map[string]bool, error) {
	existingFuncs := make(map[string]bool)
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	// regex to detect func (ctl *controller)
	re := regexp.MustCompile(`func\s+\(\w+\s+\*controller\)\s+(\w+)\(ctx\s+\*gin.Context\)`)

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		matches := re.FindStringSubmatch(line)
		if len(matches) > 1 {
			funcName := matches[1]
			existingFuncs[funcName] = true
		}
	}

	return existingFuncs, scanner.Err()
}

func filterNewRepositories(existingRepos map[string]bool, configuredRepos []string) []string {
	var newRepos []string

	for _, repo := range configuredRepos {
		if !existingRepos[repo] {
			newRepos = append(newRepos, repo)
		}
	}

	return newRepos
}
func findInsertPosition(content, marker string) int {
	position := strings.Index(content, marker)
	if position == -1 {
		return len(content)
	}
	return position + len(marker)
}

// filterNewControllers lọc các controller mới chưa có trong danh sách các controller đã tồn tại
func filterNewControllers(existingControllers map[string]bool, configuredControllers []map[string]string) []map[string]string {
	var newControllers []map[string]string

	for _, ctrl := range configuredControllers {
		if !existingControllers[ctrl["MethodName"]] {
			newControllers = append(newControllers, ctrl)
		}
	}

	return newControllers
}

func filterNewControllersInV1File(existingControllers map[string]bool, configuredControllers []map[string]string) []map[string]string {
	var newControllers []map[string]string

	for _, ctrl := range configuredControllers {
		if !existingControllers[ctrl["Name"]] {
			newControllers = append(newControllers, ctrl)
		}
	}

	return newControllers
}

func detectExistingControllersInV1File(filePath string) ([]string, error) {
	var existingControllers []string

	// Mở file để đọc nội dung
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	// Regex để tìm các method của struct controller, ví dụ: func (ctl *controller) CreateSuper(ctx *gin.Context)
	re := regexp.MustCompile(`func\s+\(\w+\s+\*controller\)\s+(\w+)\(`)

	// Đọc từng dòng để tìm các phương thức đã tồn tại
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		matches := re.FindStringSubmatch(line)
		if len(matches) > 1 {
			// Thêm tên của controller method (ví dụ: CreateSuper, GetSuper, ...)
			existingControllers = append(existingControllers, matches[1])
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return existingControllers, nil
}

func filterNewUseCases(existingUseCases map[string]bool, UseCases []string) []string {
	var newUseCases []string

	for _, uc := range UseCases {
		if !existingUseCases[uc] {
			newUseCases = append(newUseCases, uc)
		}
	}

	return newUseCases
}
func detectAndInsertImport(filePath string) error {
	importPath := "backend/internal/infrastructure/database/postgres"

	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	var buffer bytes.Buffer
	importFound := false

	// Duyệt qua từng dòng để kiểm tra import và ghi tạm vào buffer
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()

		// Kiểm tra nếu import đã tồn tại
		if strings.Contains(line, fmt.Sprintf(`"%s"`, importPath)) {
			importFound = true
			return nil
		}

		buffer.WriteString(line + "\n")

		// Khi phát hiện khối import và import chưa tồn tại, thêm import vào
		if strings.HasPrefix(line, "import (") && !importFound {
			buffer.WriteString(fmt.Sprintf("\t\"%s\"\n", importPath))
			importFound = true
		}
	}

	if err := scanner.Err(); err != nil {
		return err
	}

	// Nếu import không nằm trong khối `import (...)`, thêm vào cuối file
	if !importFound {
		buffer.WriteString(fmt.Sprintf("\nimport \"%s\"\n", importPath))
	}

	// Ghi nội dung từ buffer vào file
	return ioutil.WriteFile(filePath, buffer.Bytes(), 0644)
}
func detectMissingImports(existingImports, requiredImports map[string]string) map[string]string {
	missingImports := make(map[string]string)

	for alias, path := range requiredImports {
		if existingPath, exists := existingImports[alias]; !exists || existingPath != path {
			// Nếu alias chưa có trong existingImports hoặc path khác nhau, thì thêm vào missingImports
			missingImports[alias] = path
		}
	}

	return missingImports
}

// getMissingImports xác định các import còn thiếu trong file Go
func getMissingImports(filePath string, requiredImports map[string]string) (map[string]string, error) {
	// existingImports lưu các import đã có trong file
	existingImports := make(map[string]string)

	// Mở file Go để đọc
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	// Regex để tìm các import có chứa "backend/internal/usecases"
	importRegex := regexp.MustCompile(`"backend/internal/usecases/[^"]+"`)

	// Đọc file từng dòng
	scanner := bufio.NewScanner(file)
	inImportBlock := false

	fmt.Println("Bắt đầu phân tích file để tìm import...")

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())

		// Debugging: In ra từng dòng để kiểm tra
		fmt.Println("Xử lý dòng:", line)

		// Kiểm tra bắt đầu và kết thúc khối import
		if line == "import (" {
			inImportBlock = true
			fmt.Println("Đã vào khối import")
			continue
		} else if line == ")" && inImportBlock {
			fmt.Println("Đã thoát khỏi khối import")
			break
		}

		// Nếu đang trong khối import, kiểm tra từng dòng
		if inImportBlock {
			matches := importRegex.FindAllString(line, -1)
			for _, match := range matches {
				// Loại bỏ dấu ngoặc kép quanh đường dẫn
				path := strings.Trim(match, `"`)
				existingImports[path] = path
				// Debugging: In ra import đã tìm thấy
				fmt.Println("Đã tìm thấy import:", path)
			}
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	// Xác định các import còn thiếu
	missingImports := make(map[string]string)
	for alias, path := range requiredImports {
		if _, exists := existingImports[path]; !exists {
			missingImports[alias] = "\"" + path + "\""
		}
	}

	return missingImports, nil
}

func addMissingImports(filePath string, missingImports map[string]string) error {
	// Mở file và đọc nội dung hiện tại
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	var buffer bytes.Buffer
	scanner := bufio.NewScanner(file)
	inImportBlock := false
	importAdded := false

	for scanner.Scan() {
		line := scanner.Text()

		// Kiểm tra bắt đầu của khối import
		if strings.TrimSpace(line) == "import (" {
			inImportBlock = true
			buffer.WriteString(line + "\n")

			// Thêm các import còn thiếu ngay sau dòng "import ("
			for _, path := range missingImports {
				buffer.WriteString(fmt.Sprintf("\t"+"%s\n", path))
			}
			importAdded = true
			continue
		}

		// Kiểm tra kết thúc của khối import
		if inImportBlock && strings.TrimSpace(line) == ")" {
			inImportBlock = false
		}

		buffer.WriteString(line + "\n")
	}

	if err := scanner.Err(); err != nil {
		return err
	}

	// Nếu không tìm thấy khối import, thêm khối mới vào đầu file
	if !importAdded {
		importBlock := "import (\n"
		for alias, path := range missingImports {
			importBlock += fmt.Sprintf("\t%s \"%s\"\n", alias, path)
		}
		importBlock += ")\n\n"

		// Thêm import block vào đầu nội dung file
		bufferStr := buffer.String()
		buffer.Reset()
		buffer.WriteString(importBlock + bufferStr)
	}

	// Ghi lại nội dung mới vào file
	err = os.WriteFile(filePath, buffer.Bytes(), 0644)
	if err != nil {
		return err
	}

	return nil
}
func filterNewControllersInProviderFile(filePath string, imports, routers []string) ([]string, []string, error) {
	// Mở file provider để đọc
	file, err := os.Open(filePath)
	if err != nil {
		return nil, nil, err
	}
	defer file.Close()

	existingImports := make(map[string]bool)
	existingRouters := make(map[string]bool)

	scanner := bufio.NewScanner(file)

	// Regex để tìm các imports và controllers trong file provider hiện tại
	importRegex := regexp.MustCompile(`"([^"]+)"`)
	routerRegex := regexp.MustCompile(`(\w+\.New\w+)`)

	// Duyệt qua file để phát hiện các imports và routers đã tồn tại
	inImports := false
	inRouters := false
	for scanner.Scan() {
		line := scanner.Text()

		// Kiểm tra xem đã đến phần imports chưa
		if strings.Contains(line, "import (") {
			inImports = true
			inRouters = false
			continue
		} else if strings.Contains(line, ")") && inImports {
			inImports = false
		}

		// Kiểm tra xem đã đến phần routers chưa
		if strings.Contains(line, "wire.NewSet(") {
			inRouters = true
			inImports = false
			continue
		} else if strings.Contains(line, ")") && inRouters {
			inRouters = false
		}

		// Lưu các imports đã tồn tại
		if inImports {
			matches := importRegex.FindStringSubmatch(line)
			if len(matches) > 1 {
				existingImports[matches[1]] = true
			}
		}

		// Lưu các routers đã tồn tại
		if inRouters {
			matches := routerRegex.FindStringSubmatch(line)
			if len(matches) > 1 {
				existingRouters[matches[1]] = true
			}
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, nil, err
	}

	// Tìm các imports và routers chưa có trong file provider
	var missingImports []string
	var missingRouters []string

	for _, imp := range imports {
		importPath := strings.Trim(imp, `"`) // Bỏ dấu ngoặc kép để kiểm tra chính xác
		if !existingImports[importPath] {
			missingImports = append(missingImports, imp)
		}
	}

	for _, router := range routers {
		if !existingRouters[router] {
			missingRouters = append(missingRouters, router)
		}
	}

	return missingImports, missingRouters, nil
}
func checkControllerImportsInMain(filePath string) (map[string]bool, error) {
	// Define regex pattern to find imports for controllers
	controllerImportPattern := regexp.MustCompile(`controllers/[^"]+`)

	// Open the file
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("error opening file: %v", err)
	}
	defer file.Close()

	// Map to store found controllers
	foundControllers := make(map[string]bool)
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		matches := controllerImportPattern.FindAllString(line, -1)
		for _, match := range matches {
			foundControllers[match] = true
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("error reading file: %v", err)
	}

	return foundControllers, nil
}
func findMissingImportsInMain(sources []string, actualImports map[string]bool) []string {
	var missing []string
	for _, source := range sources {
		fmt.Println("controllers/" + utils.ToKebabCase(source))
		if !actualImports["controllers/"+utils.ToKebabCase(source)] {
			missing = append(missing, source)
		}
	}
	return missing
}
func addMissingImportsForMain(filePath string, missingImports []string) error {
	inputFile, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("error reading file: %v", err)
	}

	// Tạo buffer để xây dựng nội dung mới cho file
	var output bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(inputFile))

	importInserted := false
	importSectionPattern := regexp.MustCompile(`^import \(`)

	for scanner.Scan() {
		line := scanner.Text()
		output.WriteString(line + "\n")

		// Kiểm tra nếu là dòng bắt đầu của khối import
		if importSectionPattern.MatchString(line) && !importInserted {
			for _, imp := range missingImports {
				output.WriteString(fmt.Sprintf("\t\"backend/cmd/api/controllers/%s\"\n", utils.ToKebabCase(imp)))
			}
			importInserted = true
		}
	}

	if err := scanner.Err(); err != nil {
		return fmt.Errorf("error reading file line by line: %v", err)
	}

	// Ghi nội dung mới vào file main.go
	err = os.WriteFile(filePath, output.Bytes(), 0644)
	if err != nil {
		return fmt.Errorf("error writing to file: %v", err)
	}

	return nil
}
func addMissingControllersToStructForMain(filePath string, controllers []string) error {
	inputFile, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("error reading file: %v", err)
	}

	var output bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(inputFile))
	structPattern := regexp.MustCompile(`type App struct {`)
	inStruct := false

	for scanner.Scan() {
		line := scanner.Text()

		if structPattern.MatchString(line) {
			inStruct = true
		}

		if inStruct && strings.TrimSpace(line) == "}" {
			for _, controller := range controllers {
				controllerLine := fmt.Sprintf("\t%sController %s.Controller\n", utils.CamelCase(controller), utils.ToSnakeCase(controller))
				output.WriteString(controllerLine)
			}
			inStruct = false
		}

		output.WriteString(line + "\n")
	}

	if err := scanner.Err(); err != nil {
		return fmt.Errorf("error reading file line by line: %v", err)
	}

	err = os.WriteFile(filePath, output.Bytes(), 0644)
	if err != nil {
		return fmt.Errorf("error writing to file: %v", err)
	}

	return nil
}

// Thêm routes vào hàm registerRoute
func addRoutesToRegisterRouteForMain(filePath string, routers []string) error {
	inputFile, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("error reading file: %v", err)
	}

	var output bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(inputFile))
	registerRoutePattern := regexp.MustCompile(`func \(a \*App\) registerRoute\(\) {`)
	inRegisterRoute := false

	for scanner.Scan() {
		line := scanner.Text()

		if registerRoutePattern.MatchString(line) {
			inRegisterRoute = true
		}

		if inRegisterRoute && line == "}" {
			for _, route := range routers {
				routeLine := fmt.Sprintf("\t%s.RegisterRoutesV1(a.router, a.%sController)", utils.ToSnakeCase(route), utils.CamelCase(route))
				output.WriteString(routeLine + "\n")
			}
			inRegisterRoute = false
		}

		output.WriteString(line + "\n")
	}

	if err := scanner.Err(); err != nil {
		return fmt.Errorf("error reading file line by line: %v", err)
	}

	err = os.WriteFile(filePath, output.Bytes(), 0644)
	if err != nil {
		return fmt.Errorf("error writing to file: %v", err)
	}

	return nil
}
func addControllersToInjectFuncParams(filePath string, controllers []string) error {
	inputFile, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("error reading file: %v", err)
	}

	var output bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(inputFile))
	injectFuncPattern := regexp.MustCompile(`func inject\(`)
	inInjectFunc := false
	paramsInserted := false

	for scanner.Scan() {
		line := scanner.Text()

		if injectFuncPattern.MatchString(line) {
			inInjectFunc = true
		}

		if inInjectFunc && !paramsInserted {
			output.WriteString(line + "\n")
			for _, controller := range controllers {
				controllerParam := fmt.Sprintf("\t%sController %s.Controller,", utils.CamelCase(controller), utils.ToSnakeCase(controller))
				output.WriteString(controllerParam + "\n")
			}
			paramsInserted = true
			continue
		}

		output.WriteString(line + "\n")

		if inInjectFunc && strings.TrimSpace(line) == "}" {
			inInjectFunc = false
		}
	}

	if err := scanner.Err(); err != nil {
		return fmt.Errorf("error reading file line by line: %v", err)
	}

	err = os.WriteFile(filePath, output.Bytes(), 0644)
	if err != nil {
		return fmt.Errorf("error writing to file: %v", err)
	}

	return nil
}
func addControllersToInjectFuncDependencies(filePath string, controllers []string) error {
	inputFile, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("error reading file: %v", err)
	}

	var output bytes.Buffer
	scanner := bufio.NewScanner(bytes.NewReader(inputFile))
	injectDependenciesPattern := regexp.MustCompile(`\s*// Inject dependencies`)
	injectDependenciesInserted := false

	for scanner.Scan() {
		line := scanner.Text()
		output.WriteString(line + "\n")

		if injectDependenciesPattern.MatchString(line) && !injectDependenciesInserted {
			for _, controller := range controllers {
				injectLine := fmt.Sprintf("\tapp.%sController = %sController", utils.CamelCase(controller), utils.CamelCase(controller))
				output.WriteString(injectLine + "\n")
			}
			injectDependenciesInserted = true
		}
	}

	if err := scanner.Err(); err != nil {
		return fmt.Errorf("error reading file line by line: %v", err)
	}

	err = os.WriteFile(filePath, output.Bytes(), 0644)
	if err != nil {
		return fmt.Errorf("error writing to file: %v", err)
	}

	return nil
}
