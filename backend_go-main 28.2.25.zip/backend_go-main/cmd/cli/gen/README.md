### Giới thiệu

Công cụ sinh mã tự động này giúp tạo nhanh các thành phần **repository**, **use case**, và **controller** cho dự án Go dựa trên cấu hình trong file `repo.yaml`. Bạn chỉ cần khai báo các domain, use case và endpoint trong file `repo.yaml` và công cụ sẽ tự động sinh mã, xây dựng cấu trúc API hoàn chỉnh, bao gồm các middleware và response phù hợp.

### Ví dụ file `repo.yaml`

Dưới đây là một ví dụ cấu hình `repo.yaml` cho module `"dormitory"` với hai domain `User` và `Document`.

```yaml
modulePath: "dormitory"
domains:
  User:
    cases:
      - name: CreateUser
        method: POST
        path: "/users"
        useMiddleware: true
        skipResponse: false
      - name: GetUser
        method: GET
        path: "/users/{id}"
        onlyUseCase: true
  Document:
    onlyRepository: true
```

### Giải thích cấu hình trong `repo.yaml`

- `modulePath`: Đường dẫn của module chính trong dự án, ví dụ `"dormitory"`.
- `domains`: Tập hợp các domain cần sinh mã.
   - `User`: Một domain có các case khác nhau được khai báo trong `cases`.
      - `cases`: Danh sách các thao tác API và các chức năng tương ứng.
         - `name`: Tên case để sinh mã cho **use case** và **controller** tương ứng.
         - `method`: Phương thức HTTP của endpoint như `POST`, `GET`, `PUT`, `DELETE`.
         - `path`: Đường dẫn cho endpoint API.
         - `useMiddleware`: Nếu `true`, middleware sẽ được áp dụng cho endpoint.
         - `skipResponse`: Nếu `true`, bỏ qua phần response cho endpoint.
         - `onlyController`: Nếu `true`, chỉ sinh mã cho **controller** mà không cần **use case**.
         - `onlyUseCase`: Nếu `true`, chỉ sinh mã cho **use case** mà không cần **controller**.

### Hướng dẫn sử dụng

1. **Chuẩn bị file cấu hình `repo.yaml`**  
   Tạo file `repo.yaml` ở thư mục gốc của dự án và cấu hình các domain cũng như các case cần sinh mã. Ví dụ, một cấu hình đơn giản có thể như sau:

   ```yaml
   modulePath: "dormitory"
   domains:
      GenCase:
         cases:
            - name: Get
              method: GET
              path: "/"

   ```

2. **Chạy lệnh sinh mã**  
   Để bắt đầu sinh mã tự động, sử dụng lệnh:

   ```bash
   go run cmd/cli/gen/main.go
   ```

   Khi lệnh chạy, công cụ sẽ đọc file `repo.yaml` và tự động sinh mã cho các thành phần cần thiết như **repository**, **use case**, và **controller** dựa trên cấu hình đã cung cấp.

3. **Kiểm tra kết quả sinh mã**  
### Kết quả sinh mã

Sau khi chạy lệnh sinh mã từ file `repo.yaml`, các tệp và thư mục cần thiết sẽ được tạo ra tự động trong dự án của bạn. Dưới đây là ví dụ về cấu trúc và nội dung các file được sinh ra từ cấu hình `repo.yaml`.

#### Cấu trúc thư mục và file sinh ra



Công cụ sẽ sinh mã và tạo các tệp sau:

```
cmd/
└── api/
    └── controllers/
        ├── gen-case/
        │   ├── controller.go            # Controller cho GenCase
        │   ├── dto.go                   # Định nghĩa các Request và Response structs
        │   ├── mapper.go                # Các hàm mapper cho GenCase
        │   └── v1.go                    # Đăng ký các route của GenCase với Gin
        └── router_provider.go           # Tổng hợp các router tự động sinh
internal/
├── entities/
│   └── gen_case.go                      # Định nghĩa entity cho GenCase
├── infrastructure/
│   ├── database/
│   │   └── postgres/
│   │       └── gen_case.go              # Repository implementation cho PostgreSQL
│   └── repository_provider.go           # Tổng hợp các repository tự động sinh
├── repositories/
│   └── gen_case.go                      # Định nghĩa repository interface cho GenCase
└── usecases/
    └── gen-case/
        ├── get.go                       # Use case Get cho GenCase
        ├── types.go                     # Định nghĩa input và output types cho use case
        └── provider_autogen.go          # Tổng hợp các use case tự động sinh
       # Tổng hợp các use case tự động sinh
```

#### Giải thích nội dung từng file

- **router_provider.go**: Tập hợp và đăng ký tất cả các router tự động sinh vào Gin router chính, dựa trên `repo.yaml`.
- **controller.go**: Chứa các handler cho `GenCase`, xử lý API request và gọi use case.
- **dto.go**: Định nghĩa các `Request` và `Response` structs cho `GenCase`.
- **mapper.go**: Chuyển đổi dữ liệu giữa `Request`, `Input`, `Output`, và `Response`.
- **v1.go**: Đăng ký các route của `GenCase` với Gin.
- **gen_case.go (entities)**: Định nghĩa entity cho `GenCase` dùng trong database.
- **gen_case.go (database/postgres)**: Triển khai repository cho PostgreSQL.
- **repository_provider.go**: Tổng hợp các repository để dễ quản lý với dependency injection.
- **gen_case.go (repositories)**: Định nghĩa interface repository cho `GenCase`.
- **get.go**: Use case `Get` cho `GenCase`, xử lý logic nghiệp vụ.
- **types.go**: Định nghĩa `Input` và `Output` cho use case của `GenCase`.
- **provider_autogen.go**: Tập hợp các use case tự động sinh, hỗ trợ dependency injection.