package main

import (
	"backend/internal/infrastructure/migration"
	"backend/pkg/config"
	"backend/pkg/constants"
	"flag"
	"fmt"
	"github.com/dotrongnhan/sharing-package/pkg/logger"
)

type App struct {
	Name               string
	Version            string
	ConfigFilePath     string
	ConfigFile         string
	MigrationDirection string
	migration          migration.Migration
}

func (a *App) initFlag() {
	flag.StringVar(&a.Name, "name", "service-name", "")
	flag.StringVar(&a.Version, "version", "1.0.0", "")
	flag.StringVar(&a.ConfigFilePath, "config-file-path", "./configs", "Config file path: path to config dir")
	flag.StringVar(&a.ConfigFile, "config-file", "config", "Config file path: path to config dir")
	flag.StringVar(&a.MigrationDirection, "migrate", "up", "Specify migration direction: up or down")
	flag.Parse()
}

func (a *App) initConfig() {
	configFiles := []config.ConfigFile{
		{
			Path: a.ConfigFilePath,
			Name: a.ConfigFile,
		},
	}
	configSource := &config.Viper{
		ConfigType:  constants.ConfigTypeFile,
		ConfigFiles: configFiles,
	}
	err := configSource.InitConfig()
	if err != nil {
		panic(err)
	}
}

func inject(
	app *App,
	migration migration.Migration,
) error {
	app.migration = migration
	return nil
}

func (a *App) Run() error {
	ctx := logger.NewBackgroundContextWithTraceID("migration")
	ctxLogger := logger.NewLogger(ctx)
	ctxLogger.Info("Migration start")

	switch a.MigrationDirection {
	case "up":
		a.migration.MigrateUp()
		ctxLogger.Info("Migration up success")
	case "down":
		a.migration.MigrateDown()
		ctxLogger.Info("Migration down success")
	default:
		ctxLogger.Errorf("Invalid migration direction: %s", a.MigrationDirection)
		return fmt.Errorf("invalid migration direction: %s", a.MigrationDirection)
	}

	return nil
}

func main() {
	app := &App{}
	app.initFlag()
	app.initConfig()
	err := wireApp(app)
	if err != nil {
		panic(err)
	}

	if err := app.Run(); err != nil {
		panic(err)
	}
}
