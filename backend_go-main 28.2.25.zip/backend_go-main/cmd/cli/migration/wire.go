//go:build wireinject
// +build wireinject

// The build tag makes sure the stub is not built in the final build.

package main

import (
	"backend/internal/infrastructure"
	"github.com/google/wire"
)

func wireApp(app *App) error {
	wire.Build(
		infrastructure.DBProvider,
		inject,
	)
	return nil
}
