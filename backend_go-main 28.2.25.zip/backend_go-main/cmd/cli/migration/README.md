Run migration
```shell
go run main.go -migrate up
```
```shell
go run main.go -migrate down
```