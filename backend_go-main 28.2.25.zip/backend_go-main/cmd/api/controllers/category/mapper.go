package category

import (
	"backend/internal/usecases/category"
)

func MapToCreateInput(req CreateRequest) category.CreateInput {
	return category.CreateInput{
		Name:        req.Name,
		Description: req.Description,
	}
}

func MapToCreateResponse(output category.CreateOutput) CreateResponse {
	return CreateResponse{
		ID: output.ID,
	}
}

func MapToUpdateInput(req UpdateRequest) category.UpdateInput {
	return category.UpdateInput{
		ID:          req.ID,
		Name:        req.Name,
		Description: req.Description,
	}
}

func MapToUpdateResponse(output category.UpdateOutput) UpdateResponse {
	return UpdateResponse{
		ID:          output.ID,
		Name:        output.Name,
		Description: output.Description,
	}
}

func MapToDeleteInput(req DeleteRequest) category.DeleteInput {
	return category.DeleteInput{
		CategoryID: req.CategoryID,
	}
}

func MapToGetListInput(req GetListRequest) category.GetListInput {
	return category.GetListInput{
		Paging: req.Input,
	}
}

func MapToGetListResponse(output *category.GetListOutput) GetListResponse {
	return GetListResponse{
		Categories: mapCategoryEntitiesToCategoriesOutput(output.Categories),
		Meta:       output.Meta,
	}
}

func mapCategoryEntitiesToCategoriesOutput(categories []category.Category) []Category {
	var result []Category

	for _, r := range categories {
		result = append(result, Category{
			ID:          r.ID,
			Name:        r.Name,
			Description: r.Description,
		})
	}

	return result
}
