package category

import "backend/internal/infrastructure/persistence/postgres/pagination"

type CreateRequest struct {
	Name        *string `json:"name"  binding:"required"`
	Description *string `json:"description"`
}
type CreateResponse struct {
	ID string `json:"id"`
}
type UpdateRequest struct {
	ID          string  `uri:"id"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
}
type UpdateResponse struct {
	ID          string  `json:"id"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
}

type DeleteRequest struct {
	CategoryID string `uri:"id"`
}
type DeleteResponse struct {
	// TODO: Thêm các trường
}

type GetListRequest struct {
	pagination.Input
}
type GetListResponse struct {
	Categories []Category `json:"categories"`
	Meta       pagination.Meta
}

type Category struct {
	ID          string  `json:"id"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
}
