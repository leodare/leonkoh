package category

import "github.com/gin-gonic/gin"

type Controller interface {
	Create(ctx *gin.Context)
	Update(ctx *gin.Context)
	Delete(ctx *gin.Context)
	GetList(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller, middlewares ...gin.HandlerFunc) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/categories")
	securedRouter.GET("/get-list", controller.GetList)
	securedRouter.Use(middlewares...)
	{

		securedRouter.POST("", controller.Create)
		securedRouter.PUT("/:id", controller.Update)
		securedRouter.DELETE("/:id", controller.Delete)
	}
}
