package category

import (
	"backend/internal/usecases/category"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
)

type controller struct {
	createUseCase  category.CreateUseCase
	updateUseCase  category.UpdateUseCase
	deleteUseCase  category.DeleteUseCase
	getListUseCase category.GetListUseCase
}

// NewCuisineTypeController initializes CuisineTypeController
func NewController(
	createUseCase category.CreateUseCase,
	updateUseCase category.UpdateUseCase,
	deleteUseCase category.DeleteUseCase,
	getListUseCase category.GetListUseCase,
) Controller {
	return &controller{
		createUseCase:  createUseCase,
		updateUseCase:  updateUseCase,
		deleteUseCase:  deleteUseCase,
		getListUseCase: getListUseCase,
	}
}

// Create handles requests to
// @Router /v1/categories [POST]
// @Summary Create handles requests to
// @Description This is the handler function for Create at endpoint
// @Tags Category
// @Accept json
// @Produce json
// @Param payload body CreateRequest true "Payload"
// @Success 200 {object} CreateResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) Create(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req CreateRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToCreateInput(req)
	output, err := ctl.createUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	o, ok := output.(category.CreateOutput)
	if !ok {
		ctxLogger.Errorf("Invalid output type")
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	res := MapToCreateResponse(o)
	http.SuccessResponse(ctx, res)
}

// Update handles requests to /{id}
// @Router /v1/categories/{id} [PUT]
// @Summary Update handles requests to /{id}
// @Description This is the handler function for Update at endpoint /{id}
// @Tags Category
// @Accept json
// @Produce json
// @Param payload body UpdateRequest true "Payload"
// @Success 200 {object} http.BaseResponse{Data=UpdateResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) Update(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req UpdateRequest

	if err := ctx.ShouldBindUri(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToUpdateInput(req)
	outputI, err := ctl.updateUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	if outputI == nil {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	output, ok := outputI.(category.UpdateOutput)
	if !ok {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	resData := MapToUpdateResponse(output)
	http.SuccessResponse(ctx, resData)
}

// Delete handles requests to
// @Router /v1/categories/{id} [DELETE]
// @Summary Delete handles requests to
// @Description This is the handler function for Delete at endpoint
// @Tags Category
// @Accept json
// @Produce json
// @Param id path string true "ID of the resource to delete"
// @Success 200 {object} DeleteResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Delete(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req DeleteRequest

	if err := ctx.ShouldBindUri(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToDeleteInput(req)
	output, err := ctl.deleteUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, output)
}

// GetList handles requests to
// @Router /v1/categories/get-list [GET]
// @Summary GetList handles requests to
// @Description This is the handler function for GetList at endpoint
// @Tags Category
// @Accept json
// @Produce json
// @Param query query GetListRequest true "Query Parameters"
// @Success 200 {object} GetListResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) GetList(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req GetListRequest

	if err := ctx.ShouldBindQuery(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToGetListInput(req)
	output, err := ctl.getListUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	resData := MapToGetListResponse(output)
	http.SuccessResponse(ctx, resData)
}
