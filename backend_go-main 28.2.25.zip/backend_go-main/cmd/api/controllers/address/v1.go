package address

import (
	"backend/internal/services/search"
	"backend/internal/usecases/address"
	"backend/pkg/http"
	"github.com/gin-gonic/gin"
)

type v1 struct {
	searchingService     search.Service
	searchAddressUseCase address.SearchAddressUseCase
}

// SearchAddress handles requests to /v1/address/search
// @Router /v1/address/search [GET]
// @Summary SearchAddress handles requests to /v1/address/search
// @Description This is the handler function for SearchAddress at endpoint /v1/address/search
// @Tags Address
// @Accept json
// @Produce json
// @Param keyword query string true "Keyword"
// @Param lat query string false "Latitude"
// @Param lng query string false "Longitude"
// @Param page query int false "Page" default(1)
// @Param limit query int false "Limit" default(10)
// @Success 200 {object} SearchAddressResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *v1) SearchAddress(c *gin.Context) {
	var requestPayload SearchAddressRequest
	if err := c.ShouldBindQuery(&requestPayload); err != nil {
		http.HandleError(c, err)
		return
	}
	input := MapToSearchAddressInput(requestPayload)
	output, err := ctl.searchAddressUseCase.Execute(c.Request.Context(), input)
	if err != nil {
		http.HandleError(c, err)
		return
	}
	res, err := MapToSearchAddressResponse(output)
	if err != nil {
		http.HandleError(c, err)
		return
	}

	http.SuccessResponse(c, res)
}

// ReIndexAddressSearching handles requests to /v1/address/reindex
// @Router /v1/address/index [POST]
// @Summary ReIndexAddressSearching handles requests to /v1/address/reindex
// @Description This is the handler function for ReIndexAddressSearching at endpoint /v1/address/reindex
// @Tags Address
// @Accept json
// @Produce json
// @Success 200 {object} http.BaseResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *v1) ReIndexAddressSearching(c *gin.Context) {
	err := ctl.searchingService.ReIndexCollection(c.Request.Context(), search.Address)
	if err != nil {
		http.HandleError(c, err)
		return
	}
	http.SimpleSuccessResponse(c)
}

func NewController(searchingService search.Service, searchAddressUseCase address.SearchAddressUseCase) Controller {
	return &v1{
		searchingService:     searchingService,
		searchAddressUseCase: searchAddressUseCase,
	}
}
