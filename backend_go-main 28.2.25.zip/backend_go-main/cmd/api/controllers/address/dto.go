package address

import (
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/usecases/common"
)

type SearchAddressRequest struct {
	Keyword string   `json:"keyword" form:"keyword"`
	Lat     *float64 `json:"lat" form:"lat"`
	Lng     *float64 `json:"lng" form:"lng"`
	Radius  *int64   `json:"radius" form:"radius"`
	pagination.Input
}

type SearchAddressResponse struct {
	Addresses  ListAddressResponse   `json:"addresses"`
	AdminUnits ListAdminUnitResponse `json:"admin_units"`
}

type ListAddressResponse struct {
	Addresses []common.Address `json:"addresses"`
	Meta      pagination.Meta
}

type ListAdminUnitResponse struct {
	AdminUnits []common.AdminUnit `json:"admin_units"`
	Meta       pagination.Meta
}
