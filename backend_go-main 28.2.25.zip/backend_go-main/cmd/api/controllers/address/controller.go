package address

import "github.com/gin-gonic/gin"

type Controller interface {
	SearchAddress(ctx *gin.Context)
	ReIndexAddressSearching(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller, middlewares ...gin.HandlerFunc) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/address")
	securedRouter.Use(middlewares...)

	{
		securedRouter.GET("/search", controller.SearchAddress)
		securedRouter.POST("/index", controller.ReIndexAddressSearching)
	}
}
