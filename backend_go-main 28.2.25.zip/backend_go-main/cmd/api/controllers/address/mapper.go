package address

import (
	"backend/internal/usecases/address"
	"backend/pkg/utils"
)

func MapToSearchAddressInput(req SearchAddressRequest) address.SearchAddressInput {
	return address.SearchAddressInput{
		Keyword: req.Keyword,
		Lat:     req.Lat,
		Lng:     req.Lng,
		Radius:  req.Radius,
		Paging:  req.Input,
	}
}

func MapToSearchAddressResponse(output *address.SearchAddressOutput) (*SearchAddressResponse, error) {
	var res *SearchAddressResponse
	err := utils.MappingInterface(output, &res)
	if err != nil {
		return nil, err
	}
	return res, nil
}
