package controllers

import (
	"backend/cmd/api/controllers/address"
	"backend/cmd/api/controllers/auth"
	"backend/cmd/api/controllers/category"
	"backend/cmd/api/controllers/cuisine-type"
	"backend/cmd/api/controllers/profile"
	"backend/cmd/api/controllers/restaurant"
	"backend/cmd/api/controllers/review"
	"backend/cmd/api/controllers/static"
	"backend/cmd/api/controllers/user"
	"github.com/google/wire"
)

var ControllerProviders = wire.NewSet(
	review.NewController,
	auth.NewController,
	restaurant.NewController,
	static.NewController,
	user.NewController,
	cuisine_type.NewController,
	address.NewController,
	profile.NewController,
	category.NewController,
)
