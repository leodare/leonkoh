package auth

import (
	"backend/internal/usecases/auth"
)

// Map LoginRequest to auth.LoginInput
func MapToLoginInput(req LoginRequest) auth.LoginInput {
	return auth.LoginInput{
		Username: req.Username,
		Password: req.Password,
	}
}

// Map auth.LoginOutput to LoginResponse
func MapToLoginResponse(output *auth.LoginOutput) LoginResponse {
	return LoginResponse{
		AccessToken:  output.AccessToken,
		RefreshToken: output.RefreshToken,
		Username:     output.Username,
		Email:        output.Email,
		Phone:        output.Phone,
		NeedVerify:   output.NeedVerify,
	}
}

// Map RegisterRequest to auth.RegisterInput
func MapToRegisterInput(req RegisterRequest) auth.RegisterInput {
	return auth.RegisterInput{
		Username: req.Username,
		Password: req.Password,
		Email:    req.Email,
		Phone:    req.Phone,
	}
}

// Map auth.RegisterOutput to RegisterResponse
func MapToRegisterResponse(output *auth.RegisterOutput) RegisterResponse {
	return RegisterResponse{
		ID:           output.ID,
		Username:     output.Username,
		Email:        output.Email,
		Phone:        output.Phone,
		NeedVerify:   output.NeedVerify,
		CreatedAt:    output.CreatedAt,
		UpdatedAt:    nil,
		AccessToken:  output.AccessToken,
		RefreshToken: output.RefreshToken,
	}
}

// Map LogoutRequest to auth.LogoutInput
func MapToLogoutInput(req LogoutRequest) auth.LogoutInput {
	return auth.LogoutInput{
		// TODO: Gán các trường từ req sang UseCase input
	}
}

// Map auth.LogoutOutput to LogoutResponse
func MapToLogoutResponse(output *auth.LogoutOutput) LogoutResponse {
	return LogoutResponse{
		// TODO: Gán các trường từ output sang response
	}
}
