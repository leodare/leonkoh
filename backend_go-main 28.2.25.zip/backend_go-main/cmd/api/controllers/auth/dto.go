package auth

type LoginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}
type LoginResponse struct {
	AccessToken  string  `json:"access_token"`
	RefreshToken string  `json:"refresh_token"`
	Username     string  `json:"username"`
	Email        *string `json:"email"`
	Phone        string  `json:"phone"`
	NeedVerify   bool    `json:"need_verify"`
}
type RegisterRequest struct {
	Username string  `json:"username"`
	Password string  `json:"password"`
	Email    *string `json:"email"`
	Phone    string  `json:"phone"`
}
type RegisterResponse struct {
	ID           string  `json:"id"`
	Username     string  `json:"username"`
	Email        *string `json:"email"`
	Phone        string  `json:"phone"`
	NeedVerify   bool    `json:"need_verify"`
	CreatedAt    string  `json:"created_at"`
	UpdatedAt    *string `json:"updated_at"`
	AccessToken  string  `json:"access_token"`
	RefreshToken string  `json:"refresh_token"`
}
type LogoutRequest struct {
	Name string `json:"name,required"`
}
type LogoutResponse struct {
	// TODO: Thêm các trường
}

type RefreshTokenRequest struct{}
type RefreshTokenResponse struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	NeedVerify   bool   `json:"need_verify"`
}
