package auth

import (
	"github.com/gin-gonic/gin"
)

type Controller interface {
	Register(ctx *gin.Context)
	Logout(ctx *gin.Context)
	Login(ctx *gin.Context)
	RefreshToken(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/auths")

	{
		// implement controller to here
		securedRouter.POST("/register", controller.Register)
		securedRouter.POST("/logout", controller.Logout)
		securedRouter.POST("/login", controller.Login)
		securedRouter.POST("/refresh-token", controller.RefreshToken)
	}
}
