package auth

import (
	"backend/internal/usecases/auth"
	"backend/pkg/constants"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
)

type controller struct {
	registerUseCase     auth.RegisterUseCase
	logoutUseCase       auth.LogoutUseCase
	loginUseCase        auth.LoginUseCase
	refreshTokenUseCase auth.RefreshTokenUseCase
}

// NewAuthController initializes AuthController
func NewController(
	registerUseCase auth.RegisterUseCase,
	logoutUseCase auth.LogoutUseCase,
	loginUseCase auth.LoginUseCase,
	refreshTokenUseCase auth.RefreshTokenUseCase,
) Controller {
	return &controller{
		registerUseCase:     registerUseCase,
		logoutUseCase:       logoutUseCase,
		loginUseCase:        loginUseCase,
		refreshTokenUseCase: refreshTokenUseCase,
	}
}

// Login handles requests to /login
// @Router /v1/auths/login [POST]
// @Summary Login handles requests to /login
// @Description This is the handler function for Login at endpoint /login
// @Tags Auth
// @Accept json
// @Produce json
// @Param payload body LoginRequest true "Payload"
// @Success 200 {object} LoginResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) Login(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req LoginRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	deviceId := ctx.GetHeader(constants.HeaderKeyDeviceID)

	input := MapToLoginInput(req)
	input.DeviceId = deviceId
	output, err := ctl.loginUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	response := MapToLoginResponse(output)
	http.SuccessResponse(ctx, response)
}

// Register handles requests to /register
// @Router /v1/auths/register [POST]
// @Summary Register handles requests to /register
// @Description This is the handler function for Register at endpoint /register
// @Tags Auth
// @Accept json
// @Produce json
// @Param payload body RegisterRequest true "Payload"
// @Success 200 {object} RegisterResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) Register(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req RegisterRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	deviceId := ctx.GetHeader(constants.HeaderKeyDeviceID)

	input := MapToRegisterInput(req)
	input.DeviceId = deviceId
	output, err := ctl.registerUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	response := MapToRegisterResponse(output)
	http.SuccessResponse(ctx, response)
}

// Logout handles requests to /logout
// @Router /v1/auths/logout [POST]
// @Summary Logout handles requests to /logout
// @Description This is the handler function for Logout at endpoint /logout
// @Tags Auth
// @Accept json
// @Produce json
// @Param payload body LogoutRequest true "Payload"
// @Success 200 {object} LogoutResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) Logout(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req LogoutRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToLogoutInput(req)
	output, err := ctl.logoutUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, output)
}

// RefreshToken handles requests to /refresh-token
// @Router /v1/auths/refresh-token [POST]
// @Summary RefreshToken handles requests to /refresh-token
// @Description This is the handler function for RefreshToken at endpoint /refresh-token
// @Tags Auth
// @Accept json
// @Produce json
// @Success 200 {object} RefreshTokenResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security RefreshToken
func (ctl *controller) RefreshToken(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)
	refreshToken := ctx.GetHeader(constants.HeaderKeyRefreshToken)
	if refreshToken == "" {
		http.HandleError(ctx, xerror.NewError(xerror.RefreshTokenNotFound))
		return
	}
	deviceId := ctx.GetHeader(constants.HeaderKeyDeviceID)

	input := auth.RefreshTokenInput{
		RefreshToken: refreshToken,
		DeviceId:     deviceId,
	}
	output, err := ctl.refreshTokenUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	response := MapToLoginResponse(output)
	http.SuccessResponse(ctx, response)
}
