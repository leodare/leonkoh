package static

import "mime/multipart"

type UploadImagesRequest struct {
	ImagesData  []*multipart.FileHeader `form:"images"`
	ContentType string
}

type GetImageRequest struct {
	ID string `uri:"id" `
}

type GetFileRequest struct {
	ID string `uri:"id" binding:"uuid"`
}
type UploadVideoRequest struct {
	// TODO: Thêm các trường
}
type UploadVideoResponse struct {
	// TODO: Thêm các trường
}
type GetVideoRequest struct {
	ID string `uri:"id"`
}
type GetVideoResponse struct {
	// TODO: Thêm các trường
}
