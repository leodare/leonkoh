package static

import (
	"backend/internal/usecases/static"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
)

func mapUploadImagesRequestToInput(req UploadImagesRequest) static.UploadImagesInput {
	images := make([]static.Image, 0, len(req.ImagesData))
	for _, fileHeader := range req.ImagesData {
		base64Encoded, contentType, err := utils.EncodeFileToBase64(fileHeader)
		if err != nil {
			return static.UploadImagesInput{}
		}
		images = append(images, static.Image{
			ContentType: contentType,
			Base64:      base64Encoded,
		})
	}
	return static.UploadImagesInput{
		ImagesData: images,
	}
}

func mapUploadFilesRequestToInput(c *gin.Context) (*static.UploadFilesInput, error) {
	// Retrieve all files from the form
	form, err := c.MultipartForm()
	if err != nil {
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	// Get the list of files from the form
	files := form.File["files"]
	if len(files) == 0 {

		return nil, xerror.NewError(xerror.NoFileUploaded)
	}
	uploadFilesInput := make([]static.File, 0)
	for _, file := range files {
		contentType := file.Header.Get("Content-Type")
		uploadFilesInput = append(uploadFilesInput, static.File{
			File:        file,
			ContentType: contentType,
		})
	}
	return &static.UploadFilesInput{
		Files: uploadFilesInput,
	}, nil
}
