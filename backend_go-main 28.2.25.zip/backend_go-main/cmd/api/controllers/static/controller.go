package static

import "github.com/gin-gonic/gin"

type Controller interface {
	GetVideo(ctx *gin.Context)
	UploadImages(ctx *gin.Context)
	GetImage(ctx *gin.Context)
	UploadFiles(ctx *gin.Context)
	GetFile(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller) {
	v1 := router.Group("/api/v1/statics")
	{
		// implement controller to here
		v1.GET("/videos/:id", controller.GetVideo)
		v1.POST("/images/upload", controller.UploadImages)
		v1.GET("/images/:id", controller.GetImage)
		v1.POST("/files/upload", controller.UploadFiles)
		v1.GET("/files/:id", controller.GetFile)
	}
}
