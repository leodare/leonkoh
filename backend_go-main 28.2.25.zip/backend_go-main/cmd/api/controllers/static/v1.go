package static

import (
	"backend/internal/usecases/static"
	"backend/pkg/http"
	"bytes"
	"github.com/dotrongnhan/sharing-package/pkg/logger"
	"github.com/gin-gonic/gin"
	"io"
	http3 "net/http"
	"time"
)

var _ Controller = (*controller)(nil)

type controller struct {
	uploadImagesUseCase static.UploadImagesUseCase
	getImageUseCase     static.GetImageUseCase
	uploadFileUseCase   static.UploadFilesUseCase
	getFileUseCase      static.GetFileUseCase
}

func NewController(
	uploadImagesUseCase static.UploadImagesUseCase,
	getImageUseCase static.GetImageUseCase,
	uploadFileUseCase static.UploadFilesUseCase,
	getFileUseCase static.GetFileUseCase,
) Controller {
	return &controller{
		uploadImagesUseCase: uploadImagesUseCase,
		getImageUseCase:     getImageUseCase,
		uploadFileUseCase:   uploadFileUseCase,
		getFileUseCase:      getFileUseCase,
	}
}

// UploadImages
//
//		@Router			/v1/statics/images/upload [post]
//		@Summary		Upload images
//		@Description	Upload images and receive ids for accessing them
//		@Tags			Static
//		@Accept			multipart/form-data
//		@Produce		application/json
//		@Param			images	formData	file	true	"Images to upload"
//	 @Param Device-ID header string true "Device ID of the device making the request" default(1234567890)
//	 @Param Device-Model header string true "Model of the device making the request" default(Pixel_4)
//	 @Param App-Version header string true "Application version" default(1.0.0)
//	 @Param Os-Version header string true "Operating system version" default(10.0.0)
//	 @Param Os header string true "Operating system type" default(Android)
func (ctl *controller) UploadImages(c *gin.Context) {
	ctxLogger := logger.NewLogger(c)

	var uploadImagesPayload UploadImagesRequest
	if err := c.ShouldBind(&uploadImagesPayload); err != nil {
		ctxLogger.Errorf("Failed to bind json: %v", err)
		http.HandleError(c, err)
		return
	}

	payload := mapUploadImagesRequestToInput(uploadImagesPayload)

	res, err := ctl.uploadImagesUseCase.Execute(c, payload)
	if err != nil {
		ctxLogger.Errorf("Failed to upload images: %v", err)
		http.HandleError(c, err)
		return
	}
	http.SuccessResponse(c, res)
}

// GetImage
//
//		@Router			/v1/statics/images/{id} [get]
//		@Summary		Get image by id
//		@Description	Get image by id
//		@Tags			Static
//		@Accept			json
//		@Produce		json
//		@Param			id	path	string	true	"ID"
//	 @Param Device-ID header string true "Device ID of the device making the request" default(1234567890)
//	 @Param Device-Model header string true "Model of the device making the request" default(Pixel_4)
//	 @Param App-Version header string true "Application version" default(1.0.0)
//	 @Param Os-Version header string true "Operating system version" default(10.0.0)
//	 @Param Os header string true "Operating system type" default(Android)
//		@Success		200	{file}	file	"Image file"
func (ctl *controller) GetImage(c *gin.Context) {
	ctxLogger := logger.NewLogger(c)

	var getImageReq GetImageRequest
	if err := c.ShouldBindUri(&getImageReq); err != nil {
		http.HandleError(c, err)
		return
	}

	output, err := ctl.getImageUseCase.Execute(c, static.GetImageInput{
		ID: getImageReq.ID,
	})
	defer func(Image io.ReadCloser) {
		err := Image.Close()
		if err != nil {
			ctxLogger.Errorf("Failed to close image: %v", err)
		}
	}(output.Image)

	if err != nil {
		http.HandleError(c, err)
		return
	}
	c.DataFromReader(200, -1, output.ContentType, output.Image, nil)
}

// UploadFiles
//
//		@Router			/v1/statics/files/upload [post]
//		@Summary		Upload files
//		@Description	Upload file and receive ids for accessing them
//		@Tags			Static
//		@Accept			multipart/form-data
//		@Produce		application/json
//		@Param			files	formData	file	true	"Images to upload"
//	 @Param Device-ID header string true "Device ID of the device making the request" default(1234567890)
//	 @Param Device-Model header string true "Model of the device making the request" default(Pixel_4)
//	 @Param App-Version header string true "Application version" default(1.0.0)
//	 @Param Os-Version header string true "Operating system version" default(10.0.0)
//	 @Param Os header string true "Operating system type" default(Android)
func (ctl *controller) UploadFiles(c *gin.Context) {
	ctxLogger := logger.NewLogger(c)

	uploadFilesInput, err := mapUploadFilesRequestToInput(c)
	if err != nil {
		ctxLogger.Errorf("Failed to map upload files request to input: %v", err)
		http.HandleError(c, err)
		return
	}

	res, err := ctl.uploadFileUseCase.Execute(c, uploadFilesInput)
	if err != nil {
		http.HandleError(c, err)
		return
	}

	http.SuccessResponse(c, res)
}

// GetFile
//
//		@Router			/v1/statics/files/{id} [get]
//		@Summary		Get file by id
//		@Description	Get file by id
//		@Tags			Static
//		@Accept			json
//		@Produce		json
//		@Param			id	path	string	true	"ID"
//	 @Param Device-ID header string true "Device ID of the device making the request" default(1234567890)
//	 @Param Device-Model header string true "Model of the device making the request" default(Pixel_4)
//	 @Param App-Version header string true "Application version" default(1.0.0)
//	 @Param Os-Version header string true "Operating system version" default(10.0.0)
//	 @Param Os header string true "Operating system type" default(Android)
//		@Success		200	{file}	file	"file"
func (ctl *controller) GetFile(c *gin.Context) {
	ctxLogger := logger.NewLogger(c)

	var getFileReq GetFileRequest
	if err := c.ShouldBindUri(&getFileReq); err != nil {
		ctxLogger.Errorf("Failed to bind json: %v", err)
		http.HandleError(c, err)
		return
	}

	getFileOutput, err := ctl.getFileUseCase.Execute(c, static.GetFileInput{ID: getFileReq.ID})
	if err != nil {
		ctxLogger.Errorf("Failed to get file: %v", err)
		http.HandleError(c, err)
		return
	}
	defer getFileOutput.File.Close() // Đảm bảo đóng file sau khi hoàn thành

	// Thiết lập các header để trả về file
	c.Header("Content-Disposition", "attachment; filename="+getFileOutput.FileName)
	c.Header("Content-Type", getFileOutput.Type)

	// Trả về file cho client
	io.Copy(c.Writer, getFileOutput.File)
	return
}

// GetVideo handles requests to /videos/{id}
// @Router /v1/statics/videos/{id} [GET]
// @Summary GetVideo handles requests to /videos/{id}
// @Description This is the handler function for GetVideo at endpoint /videos/{id}
// @Tags Static
// @Accept json
// @Produce json
// @Param query query GetVideoRequest true "Query Parameters"
// @Success 200 {object} GetVideoResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) GetVideo(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var getFileReq GetVideoRequest
	if err := ctx.ShouldBindUri(&getFileReq); err != nil {
		ctxLogger.Errorf("Failed to bind json: %v", err)
		http.HandleError(ctx, err)
		return
	}

	getFileOutput, err := ctl.getFileUseCase.Execute(ctx, static.GetFileInput{ID: getFileReq.ID})
	if err != nil {
		ctxLogger.Errorf("Failed to get file: %v", err)
		http.HandleError(ctx, err)
		return
	}
	defer getFileOutput.File.Close()

	// Thiết lập header nội dung cho video
	ctx.Writer.Header().Set("Content-Type", "video/mp4")
	ctx.Writer.Header().Set("Content-Disposition", "inline")

	// Ghi dữ liệu video vào response để phát trực tiếp
	// Đọc toàn bộ dữ liệu từ io.ReadCloser vào bộ nhớ
	buffer := new(bytes.Buffer)
	_, err = io.Copy(buffer, getFileOutput.File)
	if err != nil {
		ctxLogger.Errorf("Failed to read file into buffer: %v", err)
		http.HandleError(ctx, err)
		return
	}

	// Tạo một bytes.Reader từ dữ liệu trong bộ nhớ
	videoReader := bytes.NewReader(buffer.Bytes())

	// Sử dụng http.ServeContent để hỗ trợ Range Requests
	http3.ServeContent(ctx.Writer, ctx.Request, getFileReq.ID, time.Now(), videoReader)
}
