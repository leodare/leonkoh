package restaurant

import (
	"backend/internal/services/search"
	"backend/internal/usecases/restaurant"
	"backend/pkg/constants"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
)

type controller struct {
	createRestaurantUseCase  restaurant.CreateRestaurantUseCase
	getRestaurantByIDUseCase restaurant.GetRestaurantByIDUseCase
	updateRestaurantUseCase  restaurant.UpdateRestaurantUseCase
	deleteRestaurantUseCase  restaurant.DeleteRestaurantUseCase
	getListUseCase           restaurant.GetListUseCase
	searchingService         search.Service
}

// NewRestaurantController initializes RestaurantController
func NewController(
	createRestaurantUseCase restaurant.CreateRestaurantUseCase,
	getRestaurantByIDUseCase restaurant.GetRestaurantByIDUseCase,
	updateRestaurantUseCase restaurant.UpdateRestaurantUseCase,
	deleteRestaurantUseCase restaurant.DeleteRestaurantUseCase,
	getListUseCase restaurant.GetListUseCase,
	searchingService search.Service,
) Controller {
	return &controller{
		createRestaurantUseCase:  createRestaurantUseCase,
		getRestaurantByIDUseCase: getRestaurantByIDUseCase,
		updateRestaurantUseCase:  updateRestaurantUseCase,
		deleteRestaurantUseCase:  deleteRestaurantUseCase,
		getListUseCase:           getListUseCase,
		searchingService:         searchingService,
	}
}

// GetList handles requests to /
// @Router /v1/restaurants [GET]
// @Summary GetList handles requests to /
// @Description This is the handler function for GetList at endpoint /
// @Tags Restaurant
// @Accept json
// @Produce json
// @Param query query GetListRequest true "Query Parameters"
// @Success 200 {object} GetListResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) GetList(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req GetListRequest

	if err := ctx.ShouldBindQuery(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToGetListInput(req)
	output, err := ctl.getListUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	response := MapToGetListResponse(output)
	http.SuccessResponse(ctx, response)
}

// CreateRestaurant handles requests to /restaurants
// @Router /v1/restaurants/ [POST]
// @Summary CreateRestaurant handles requests to /restaurants
// @Description This is the handler function for CreateRestaurant at endpoint /restaurants
// @Tags Restaurant
// @Accept json
// @Produce json
// @Param payload body CreateRestaurantRequest true "Payload"
// @Success 200 {object} CreateRestaurantResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) CreateRestaurant(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req CreateRestaurantRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToCreateRestaurantInput(req)
	output, err := ctl.createRestaurantUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, output)
}

// GetRestaurantByID handles requests to /restaurants/{id}
// @Router /v1/restaurants/{id} [GET]
// @Summary GetRestaurantByID handles requests to /restaurants/{id}
// @Description This is the handler function for GetRestaurantByID at endpoint /restaurants/{id}
// @Tags Restaurant
// @Accept json
// @Produce json
// @Param id path string true "ID of the resource to get"
// @Success 200 {object} GetRestaurantByIDResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) GetRestaurantByID(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	id := ctx.Param("id")
	userId := ctx.GetString(constants.ContextKeyUserId)
	input := restaurant.GetRestaurantByIDInput{
		Id:     id,
		UserId: userId,
	}
	output, err := ctl.getRestaurantByIDUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, output)
}

// UpdateRestaurant handles requests to /restaurants/{id}
// @Router /v1/restaurants/{id} [PUT]
// @Summary UpdateRestaurant handles requests to /restaurants/{id}
// @Description This is the handler function for UpdateRestaurant at endpoint /restaurants/{id}
// @Tags Restaurant
// @Accept json
// @Produce json
// @Param payload body UpdateRestaurantRequest true "Payload"
// @Success 200 {object} UpdateRestaurantResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) UpdateRestaurant(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req UpdateRestaurantRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	id := ctx.Param("id")

	input := MapToUpdateRestaurantInput(req)
	input.Id = id
	output, err := ctl.updateRestaurantUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, output)
}

// DeleteRestaurant handles requests to /restaurants/{id}
// @Router /v1/restaurants/{id} [DELETE]
// @Summary DeleteRestaurant handles requests to /restaurants/{id}
// @Description This is the handler function for DeleteRestaurant at endpoint /restaurants/{id}
// @Tags Restaurant
// @Accept json
// @Produce json
// @Param id path int true "ID of the resource to delete"
// @Success 200 {object} interface{} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) DeleteRestaurant(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	id := ctx.Param("id")

	input := restaurant.DeleteRestaurantInput{
		Id: id,
	}
	err := ctl.deleteRestaurantUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SimpleSuccessResponse(ctx)
}

// ReIndexRestaurantSearching handles requests to /v1/restaurants/reindex
// @Router /v1/restaurants/reindex [POST]
// @Summary ReIndexRestaurantSearching handles requests to /v1/restaurants/reindex
// @Description This is the handler function for ReIndexRestaurantSearching at endpoint /v1/restaurants/reindex
// @Tags Restaurant
// @Accept json
// @Produce json
// @Success 200 {object} http.BaseResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) ReIndexRestaurantSearching(c *gin.Context) {
	err := ctl.searchingService.ReIndexCollection(c.Request.Context(), search.Restaurant)
	if err != nil {
		http.HandleError(c, err)
		return
	}
	http.SimpleSuccessResponse(c)
}
