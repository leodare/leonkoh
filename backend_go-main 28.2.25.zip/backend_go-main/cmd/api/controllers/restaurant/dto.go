package restaurant

import (
	"backend/cmd/api/controllers/common"
	"backend/internal/infrastructure/persistence/postgres/pagination"
)

type Category struct {
	ID          string  `json:"id"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
}

type CuisineType struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type Info struct {
	ID           string           `json:"id"`
	Name         string           `json:"name"`
	UnitNumber   *string          `json:"unit_number"`
	Area         *string          `json:"area"`
	Phone        *string          `json:"phone"`
	OpeningTime  *string          `json:"opening_time"`
	ClosingTime  *string          `json:"closing_time"`
	PriceFrom    *float64         `json:"price_from"`
	PriceTo      *float64         `json:"price_to"`
	Website      *string          `json:"website"`
	Email        *string          `json:"email"`
	CreatedAt    string           `json:"created_at"`
	UpdatedAt    *string          `json:"updated_at"`
	DeletedAt    *string          `json:"deleted_at"`
	Addresses    []common.Address `json:"addresses"`
	Statics      []common.Static  `json:"statics"`
	CuisineTypes []CuisineType    `json:"cuisine_types"`
	Categories   []Category       `json:"categories"`
}

type UpdateRequest struct {
	Name        *string  `json:"name" validate:"required"`
	Address     *string  `json:"address" validate:"required"`
	UnitNumber  *string  `json:"unit_number"`
	Area        *string  `json:"area"`
	Phone       *string  `json:"phone"`
	OpeningTime *string  `json:"opening_time"`
	ClosingTime *string  `json:"closing_time"`
	PriceFrom   *float64 `json:"price_from"`
	PriceTo     *float64 `json:"price_to"`
	Latitude    *float64 `json:"latitude"`
	Longitude   *float64 `json:"longitude"`
}
type UpdateResponse struct {
	Info
}
type GetListRequest struct {
	pagination.Input
	Name         *string  `json:"name" form:"name"`
	Lat          *float64 `json:"lat" form:"lat"`
	Lng          *float64 `json:"lng" form:"lng"`
	Radius       *int64   `json:"radius" form:"radius"`
	CuisineTypes []string `json:"cuisine_types" form:"cuisine_types"`
	Categories   []string `json:"categories" form:"categories"`
}
type GetListResponse struct {
	Restaurants []Info `json:"restaurants"`
	Meta        pagination.Meta
}

type AddressInput struct {
	AddressId  string `json:"address_id"`
	BranchName string `json:"branch_name"`
}

type CreateRestaurantRequest struct {
	Name        string         `json:"name"`
	Addresses   []AddressInput `json:"addresses"`
	CategoryIds []string       `json:"category_ids"`
	UnitNumber  *string        `json:"unit_number"`
	Area        *string        `json:"area"`
	Phone       *string        `json:"phone"`
	OpeningTime *string        `json:"opening_time"`
	ClosingTime *string        `json:"closing_time"`
	PriceFrom   *float64       `json:"price_from"`
	PriceTo     *float64       `json:"price_to"`
	IsEmployee  bool           `json:"is_employee"`
	IsOwner     bool           `json:"is_owner"`
}
type CreateRestaurantResponse struct {
	Info
}
type GetRestaurantByIDResponse struct {
	Info
}
type UpdateRestaurantRequest struct {
	Name        string         `json:"name" validate:"required"`
	Addresses   []AddressInput `json:"addresses"`
	CategoryIds []string       `json:"category_ids"`
	UnitNumber  *string        `json:"unit_number"`
	Area        *string        `json:"area"`
	Phone       *string        `json:"phone"`
	OpeningTime *string        `json:"opening_time"`
	ClosingTime *string        `json:"closing_time"`
	PriceFrom   *float64       `json:"price_from"`
	PriceTo     *float64       `json:"price_to"`
	Latitude    *float64       `json:"latitude"`
	Longitude   *float64       `json:"longitude"`
}
type UpdateRestaurantResponse struct {
	Info
}
