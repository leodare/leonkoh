package restaurant

import (
	"backend/cmd/api/controllers/common"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/usecases/restaurant"
)

// Map GetListRequest to restaurant.GetListInput
func MapToGetListInput(req GetListRequest) restaurant.GetListInput {
	return restaurant.GetListInput{
		Paging: pagination.Input{
			Page:  req.Page,
			Limit: req.Limit,
		},
		Name:         req.Name,
		Latitude:     req.Lat,
		Longitude:    req.Lng,
		Radius:       req.Radius,
		CuisineTypes: req.CuisineTypes,
		Categories:   req.Categories,
	}
}

// Map restaurant.GetListOutput to GetListResponse
func MapToGetListResponse(output *restaurant.GetListOutput) GetListResponse {
	restaurants := make([]Info, 0)
	for _, r := range output.Restaurants {
		addresses := make([]common.Address, 0)
		for _, address := range r.Addresses {
			addresses = append(addresses, common.MappingAddressEntityToAddress(address))
		}
		statics := make([]common.Static, 0)
		for _, static := range r.Statics {
			statics = append(statics, common.MappingStaticEntityToStatic(static))
		}
		categories := make([]Category, 0)
		for _, category := range r.Categories {
			categories = append(categories, Category{
				ID:          category.ID,
				Name:        category.Name,
				Description: category.Description,
			})
		}
		cuisineTypes := make([]CuisineType, 0)
		for _, cuisineType := range r.CuisineTypes {
			cuisineTypes = append(cuisineTypes, CuisineType{
				ID:   cuisineType.ID,
				Name: cuisineType.Name,
			})
		}
		restaurants = append(restaurants, Info{
			ID:           r.ID,
			Name:         r.Name,
			UnitNumber:   r.UnitNumber,
			Area:         r.Area,
			Phone:        r.Phone,
			OpeningTime:  r.OpeningTime,
			ClosingTime:  r.ClosingTime,
			PriceFrom:    r.PriceFrom,
			PriceTo:      r.PriceTo,
			Addresses:    addresses,
			Categories:   categories,
			Statics:      statics,
			CuisineTypes: cuisineTypes,
			CreatedAt:    r.CreatedAt,
			UpdatedAt:    r.UpdatedAt,
		})
	}
	return GetListResponse{
		Restaurants: restaurants,
		Meta:        output.Meta,
	}
}

// Map CreateRestaurantRequest to restaurant.CreateRestaurantInput
func MapToCreateRestaurantInput(req CreateRestaurantRequest) restaurant.CreateRestaurantInput {
	addressInputs := make([]restaurant.AddressInput, 0)
	for _, address := range req.Addresses {
		addressInputs = append(addressInputs, restaurant.AddressInput{
			AddressId:  address.AddressId,
			BranchName: address.BranchName,
		})
	}

	return restaurant.CreateRestaurantInput{
		Name:        req.Name,
		UnitNumber:  req.UnitNumber,
		Area:        req.Area,
		Phone:       req.Phone,
		OpeningTime: req.OpeningTime,
		ClosingTime: req.ClosingTime,
		PriceFrom:   req.PriceFrom,
		PriceTo:     req.PriceTo,
		CategoryIds: req.CategoryIds,
		Addresses:   addressInputs,
		IsEmployee:  req.IsEmployee,
		IsOwner:     req.IsOwner,
	}
}

// Map restaurant.CreateRestaurantOutput to CreateRestaurantResponse
func MapToCreateRestaurantResponse(output *restaurant.CreateRestaurantOutput) CreateRestaurantResponse {
	Addresses := make([]common.Address, 0)
	for _, address := range output.Addresses {
		Addresses = append(Addresses, common.MappingAddressEntityToAddress(address))
	}
	categories := make([]Category, 0)
	for _, category := range output.Categories {
		categories = append(categories, Category{
			ID:          category.ID,
			Name:        category.Name,
			Description: category.Description,
		})
	}
	return CreateRestaurantResponse{
		Info: Info{
			ID:          output.ID,
			Name:        output.Name,
			Addresses:   Addresses,
			Categories:  categories,
			UnitNumber:  output.UnitNumber,
			Area:        output.Area,
			Phone:       output.Phone,
			OpeningTime: output.OpeningTime,
			ClosingTime: output.ClosingTime,
			PriceFrom:   output.PriceFrom,
			PriceTo:     output.PriceTo,
			Website:     output.Website,
			Email:       output.Email,
			CreatedAt:   output.CreatedAt,
			UpdatedAt:   output.UpdatedAt,
			DeletedAt:   output.DeletedAt,
		},
	}
}

// Map restaurant.GetRestaurantByIDOutput to GetRestaurantByIDResponse
func MapToGetRestaurantByIDResponse(output *restaurant.GetRestaurantByIDOutput) GetRestaurantByIDResponse {
	Addresses := make([]common.Address, 0)
	for _, address := range output.Addresses {
		Addresses = append(Addresses, common.MappingAddressEntityToAddress(address))
	}
	categories := make([]Category, 0)
	for _, category := range output.Categories {
		categories = append(categories, Category{
			ID:          category.ID,
			Name:        category.Name,
			Description: category.Description,
		})
	}
	return GetRestaurantByIDResponse{
		Info: Info{
			ID:          output.ID,
			Name:        output.Name,
			Addresses:   Addresses,
			Categories:  categories,
			UnitNumber:  output.UnitNumber,
			Area:        output.Area,
			Phone:       output.Phone,
			OpeningTime: output.OpeningTime,
			ClosingTime: output.ClosingTime,
			PriceFrom:   output.PriceFrom,
			PriceTo:     output.PriceTo,
			Website:     output.Website,
			Email:       output.Email,
			CreatedAt:   output.CreatedAt,
			UpdatedAt:   output.UpdatedAt,
			DeletedAt:   output.DeletedAt,
		},
	}
}

// Map UpdateRestaurantRequest to restaurant.UpdateRestaurantInput
func MapToUpdateRestaurantInput(req UpdateRestaurantRequest) restaurant.UpdateRestaurantInput {
	addressInputs := make([]restaurant.AddressInput, 0)
	for _, address := range req.Addresses {
		addressInputs = append(addressInputs, restaurant.AddressInput{
			AddressId:  address.AddressId,
			BranchName: address.BranchName,
		})
	}

	return restaurant.UpdateRestaurantInput{
		Name:        req.Name,
		Addresses:   addressInputs,
		CategoryIds: req.CategoryIds,
		UnitNumber:  req.UnitNumber,
		Area:        req.Area,
		Phone:       req.Phone,
		OpeningTime: req.OpeningTime,
		ClosingTime: req.ClosingTime,
		PriceFrom:   req.PriceFrom,
		PriceTo:     req.PriceTo,
	}
}

// Map restaurant.UpdateRestaurantOutput to UpdateRestaurantResponse
func MapToUpdateRestaurantResponse(output *restaurant.UpdateRestaurantOutput) UpdateRestaurantResponse {
	Addresses := make([]common.Address, 0)
	for _, address := range output.Addresses {
		Addresses = append(Addresses, common.MappingAddressEntityToAddress(address))
	}
	categories := make([]Category, 0)
	for _, category := range output.Categories {
		categories = append(categories, Category{
			ID:          category.ID,
			Name:        category.Name,
			Description: category.Description,
		})
	}
	return UpdateRestaurantResponse{
		Info: Info{
			ID:          output.ID,
			Name:        output.Name,
			Addresses:   Addresses,
			Categories:  categories,
			UnitNumber:  output.UnitNumber,
			Area:        output.Area,
			Phone:       output.Phone,
			OpeningTime: output.OpeningTime,
			ClosingTime: output.ClosingTime,
			PriceFrom:   output.PriceFrom,
			PriceTo:     output.PriceTo,
			Website:     output.Website,
			Email:       output.Email,
			CreatedAt:   output.CreatedAt,
			UpdatedAt:   output.UpdatedAt,
			DeletedAt:   output.DeletedAt,
		},
	}
}
