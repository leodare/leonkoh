package restaurant

import (
	"github.com/gin-gonic/gin"
)

type Controller interface {
	CreateRestaurant(ctx *gin.Context)
	GetRestaurantByID(ctx *gin.Context)
	UpdateRestaurant(ctx *gin.Context)
	DeleteRestaurant(ctx *gin.Context)
	GetList(ctx *gin.Context)
	ReIndexRestaurantSearching(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller, middlewares ...gin.HandlerFunc) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/restaurants")
	publicRouter := v1.Group("/restaurants")
	{
		// implement controller to here
		publicRouter.GET("/", controller.GetList)
	}
	securedRouter.Use(middlewares...)

	{
		// implement controller to here
		securedRouter.POST("/", controller.CreateRestaurant)
		securedRouter.GET("/:id", controller.GetRestaurantByID)
		securedRouter.PUT("/:id", controller.UpdateRestaurant)
		securedRouter.DELETE("/:id", controller.DeleteRestaurant)
		securedRouter.POST("/index", controller.ReIndexRestaurantSearching)
	}
}
