package profile

import (
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"time"
)

type CreateRequest struct {
	AddressId   *string `json:"address_id"`
	FirstName   string  `json:"first_name"`
	LastName    string  `json:"last_name"`
	Avatar      *string `json:"avatar"`
	Bio         *string `json:"bio"`
	DateOfBirth *string `json:"date_of_birth"`
	Gender      string  `json:"gender"`
}
type CreateResponse struct {
	Id          string     `json:"id"`
	UserID      string     `json:"user_id" `
	AddressID   *string    `json:"address_id"`
	FirstName   string     `json:"first_name"`
	LastName    string     `json:"last_name"`
	Avatar      *string    `json:"avatar"`
	Bio         *string    `json:"bio"`
	DateOfBirth *string    `json:"date_of_birth"`
	Gender      string     `json:"gender"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   *time.Time `json:"updated_at"`
}
type UpdateRequest struct {
	AddressId   *string `json:"address_id"`
	FirstName   string  `json:"first_name"`
	LastName    string  `json:"last_name"`
	Avatar      *string `json:"avatar"`
	Bio         *string `json:"bio"`
	DateOfBirth *string `json:"date_of_birth"`
	Gender      string  `json:"gender"`
}
type UpdateResponse struct {
	Id          string     `json:"id"`
	UserID      string     `json:"user_id" `
	AddressID   *string    `json:"address_id"`
	FirstName   string     `json:"first_name"`
	LastName    string     `json:"last_name"`
	Avatar      *string    `json:"avatar"`
	Bio         *string    `json:"bio"`
	DateOfBirth *string    `json:"date_of_birth"`
	Gender      string     `json:"gender"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   *time.Time `json:"updated_at"`
}
type GetDetailResponse struct {
	Id          string     `json:"id"`
	UserID      string     `json:"user_id" `
	AddressID   *string    `json:"address_id"`
	FirstName   string     `json:"first_name"`
	LastName    string     `json:"last_name"`
	Avatar      *string    `json:"avatar"`
	Bio         *string    `json:"bio"`
	DateOfBirth *string    `json:"date_of_birth"`
	Gender      string     `json:"gender"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   *time.Time `json:"updated_at"`
}
type FollowRequest struct {
	FollowedId string `json:"followed_id"`
}
type UnfollowRequest struct {
	FollowedId string `json:"followed_id"`
}

type GetListFollowedResponse struct {
	ListFollowed []FollowedData `json:"list_followed"`
	Meta         pagination.Meta
}
type FollowedData struct {
	Id         string  `json:"id"`
	FollowerID string  `json:"follower_id"`
	FollowedID string  `json:"followed_id"`
	FirstName  string  `json:"first_name"`
	LastName   string  `json:"last_name"`
	Avatar     *string `json:"avatar"`
}
