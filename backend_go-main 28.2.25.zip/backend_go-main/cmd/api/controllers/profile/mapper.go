package profile

import (
	"backend/internal/usecases/profile"
)

// Map CreateRequest to profile.CreateInput
func MapToCreateInput(req CreateRequest) profile.CreateInput {
	return profile.CreateInput{
		AddressId:   req.AddressId,
		FirstName:   req.FirstName,
		LastName:    req.LastName,
		Avatar:      req.Avatar,
		Bio:         req.Bio,
		DateOfBirth: req.DateOfBirth,
		Gender:      req.Gender,
	}
}

// MapToCreateResponse Map profile.CreateOutput to CreateResponse
func MapToCreateResponse(output profile.CreateOutput) CreateResponse {
	return CreateResponse{
		Id:          output.Id,
		UserID:      output.UserID,
		AddressID:   output.AddressID,
		FirstName:   output.FirstName,
		LastName:    output.LastName,
		Avatar:      output.Avatar,
		Bio:         output.Bio,
		DateOfBirth: output.DateOfBirth,
		Gender:      output.Gender,
		CreatedAt:   output.CreatedAt,
		UpdatedAt:   output.UpdatedAt,
	}
}

// Map UpdateRequest to profile.UpdateInput
func MapToUpdateInput(req UpdateRequest) profile.UpdateInput {
	return profile.UpdateInput{
		AddressId:   req.AddressId,
		FirstName:   req.FirstName,
		LastName:    req.LastName,
		Avatar:      req.Avatar,
		Bio:         req.Bio,
		DateOfBirth: req.DateOfBirth,
		Gender:      req.Gender,
	}
}

// MapToCreateResponse Map profile.UpdateOutput to UpdateResponse
func MapToUpdateResponse(output profile.UpdateOutput) UpdateResponse {
	return UpdateResponse{
		Id:          output.Id,
		UserID:      output.UserID,
		AddressID:   output.AddressID,
		FirstName:   output.FirstName,
		LastName:    output.LastName,
		Avatar:      output.Avatar,
		Bio:         output.Bio,
		DateOfBirth: output.DateOfBirth,
		Gender:      output.Gender,
		CreatedAt:   output.CreatedAt,
		UpdatedAt:   output.UpdatedAt,
	}
}

// MapToGetDetailResponse Map profile.GetDetailOutput to GetDetailResponse
func MapToGetDetailResponse(output profile.GetDetailOutput) GetDetailResponse {
	return GetDetailResponse{
		Id:          output.Id,
		UserID:      output.UserID,
		AddressID:   output.AddressID,
		FirstName:   output.FirstName,
		LastName:    output.LastName,
		Avatar:      output.Avatar,
		Bio:         output.Bio,
		DateOfBirth: output.DateOfBirth,
		Gender:      output.Gender,
		CreatedAt:   output.CreatedAt,
		UpdatedAt:   output.UpdatedAt,
	}
}

// Map FollowRequest to profile.CreateInput
func MapToFollowInput(req FollowRequest) profile.FollowInput {
	return profile.FollowInput{
		FollowedID: req.FollowedId,
	}
}

// Map FollowRequest to profile.CreateInput
func MapToUnfollowInput(req UnfollowRequest) profile.UnfollowInput {
	return profile.UnfollowInput{
		FollowedID: req.FollowedId,
	}
}

// MapToGetListFollowedResponse Map profile.GetListFollowedOutput to GetListFollowedResponse
func MapToGetListFollowedResponse(output profile.GetListFollowedOutput) GetListFollowedResponse {
	result := GetListFollowedResponse{
		Meta: output.Meta,
	}
	for _, data := range output.ListFollowed {
		result.ListFollowed = append(result.ListFollowed, FollowedData{
			Id:         data.Id,
			FollowerID: data.FollowerID,
			FollowedID: data.FollowedID,
			FirstName:  data.FirstName,
			LastName:   data.LastName,
			Avatar:     data.Avatar,
		})
	}
	return result
}
