package profile

import (
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/usecases/profile"
	"backend/pkg/constants"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
	"strconv"
)

type controller struct {
	createUseCase          profile.CreateUseCase
	updateUseCase          profile.UpdateUseCase
	getDetailUseCase       profile.GetDetailUseCase
	followUseCase          profile.FollowUseCase
	unFollowUseCase        profile.UnfollowUseCase
	getListFollowedUseCase profile.GetListFollowedUseCase
}

// NewProfileController
func NewController(
	createUseCase profile.CreateUseCase,
	updateUseCase profile.UpdateUseCase,
	getDetailUseCase profile.GetDetailUseCase,
	followUseCase profile.FollowUseCase,
	unFollowUseCase profile.UnfollowUseCase,
	getListFollowedUseCase profile.GetListFollowedUseCase,
) Controller {
	return &controller{
		createUseCase:          createUseCase,
		updateUseCase:          updateUseCase,
		getDetailUseCase:       getDetailUseCase,
		followUseCase:          followUseCase,
		unFollowUseCase:        unFollowUseCase,
		getListFollowedUseCase: getListFollowedUseCase,
	}
}

// Create handles requests to /v1/profiles method POST
// @Router /v1/profiles [POST]
// @Summary Create handles requests to /v1/profiles method POST
// @Description This is the handler function for Create at endpoint /v1/profiles method POST
// @Tags Profile
// @Accept json
// @Produce json
// @Param payload body CreateRequest true "Payload"
// @Success 200 {object} http.BaseResponse{Data=CreateResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Create(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req CreateRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	input := MapToCreateInput(req)
	input.UserID = userId
	outputI, err := ctl.createUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	if outputI == nil {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	output, ok := outputI.(profile.CreateOutput)
	if !ok {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	resData := MapToCreateResponse(output)
	http.SuccessResponse(ctx, resData)
}

// Update handles requests to /v1/profiles method PUT
// @Router /v1/profiles [PUT]
// @Summary Update handles requests to /v1/profiles method PUT
// @Description This is the handler function for Update at endpoint /v1/profiles method PUT
// @Tags Profile
// @Accept json
// @Produce json
// @Param payload body UpdateRequest true "Payload"
// @Success 200 {object} http.BaseResponse{Data=UpdateResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Update(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req UpdateRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	input := MapToUpdateInput(req)
	input.UserID = userId
	outputI, err := ctl.updateUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	if outputI == nil {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	output, ok := outputI.(profile.UpdateOutput)
	if !ok {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	resData := MapToUpdateResponse(output)
	http.SuccessResponse(ctx, resData)
}

// GetDetail handles requests to /v1/profiles/detail method GET
// @Router /v1/profiles/detail [GET]
// @Summary GetDetail handles requests to /v1/profiles/detail method GET
// @Description This is the handler function for GetDetail at endpoint /v1/profiles/detail method GET
// @Tags Profile
// @Accept json
// @Produce json
// @Success 200 {object} http.BaseResponse{Data=GetDetailResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) GetDetail(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	input := profile.GetDetailInput{
		UserId: userId,
	}
	outputI, err := ctl.getDetailUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	if outputI == nil {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	output, ok := outputI.(profile.GetDetailOutput)
	if !ok {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	resData := MapToGetDetailResponse(output)
	http.SuccessResponse(ctx, resData)
}

// Follow handles requests to /v1/profiles/follow method POST
// @Router /v1/profiles/follow [POST]
// @Summary  Follow handles requests to /v1/profiles/follow method POST
// @Description This is the handler function for Follow at endpoint /v1/profiles/follow method POST
// @Tags Profile
// @Accept json
// @Produce json
// @Param payload body FollowRequest true "Payload"
// @Success 200 {object} http.BaseResponse{} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Follow(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req FollowRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	input := MapToFollowInput(req)
	input.UserID = userId
	_, err := ctl.followUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	http.SuccessResponse(ctx, nil)
}

// Unfollow handles requests to /v1/profiles/unfollow method POST
// @Router /v1/profiles/unfollow [POST]
// @Summary UnFollow handles requests to /v1/profiles/unfollow method POST
// @Description This is the handler function for UnFollow at endpoint /v1/profiles/unfollow method POST
// @Tags Profile
// @Accept json
// @Produce json
// @Param payload body UnfollowRequest true "Payload"
// @Success 200 {object} http.BaseResponse{} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Unfollow(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req UnfollowRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	input := MapToUnfollowInput(req)
	input.UserID = userId
	_, err := ctl.unFollowUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	http.SuccessResponse(ctx, nil)
}

// GetListFollowed handles requests to /v1/profiles/list-followed method GET
// @Router /v1/profiles/list-followed [GET]
// @Summary GetListFollowed handles requests to /v1/profiles/list-followed method GET
// @Description This is the handler function for GetListFollowed at endpoint /v1/profiles/list-followed method GET
// @Tags Profile
// @Accept json
// @Produce json
// @Param isLatest query bool false "Is Latest" default(true)
// @Param page query int false "Page"
// @Param limit query int false "Limit"
// @Success 200 {object} http.BaseResponse{Data=GetListFollowedResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) GetListFollowed(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}

	pageStr := ctx.Query("page")
	limitStr := ctx.Query("limit")
	page, err := strconv.Atoi(pageStr)
	if err != nil {
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	limit, err := strconv.Atoi(limitStr)
	if err != nil {
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	isLatestStr := ctx.Query("isLatest")
	isLatest, err := strconv.ParseBool(isLatestStr)
	if err != nil {
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	input := profile.GetListFollowedInput{
		UserID: userId,
		Paging: pagination.Input{
			Page:  page,
			Limit: limit,
		},
		IsLatest: isLatest,
	}
	output, err := ctl.getListFollowedUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	if output == nil {
		ctxLogger.Error(xerror.NewError(xerror.InternalServer))
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}

	resData := MapToGetListFollowedResponse(*output)
	http.SuccessResponse(ctx, resData)
}
