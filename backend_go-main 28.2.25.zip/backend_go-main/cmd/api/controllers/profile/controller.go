package profile

import (
	"github.com/gin-gonic/gin"
)

type Controller interface {
	GetDetail(ctx *gin.Context)
	Update(ctx *gin.Context)
	Create(ctx *gin.Context)
	Follow(ctx *gin.Context)
	Unfollow(ctx *gin.Context)
	GetListFollowed(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller, middlewares ...gin.HandlerFunc) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/profiles")
	securedRouter.Use(middlewares...)
	{
		securedRouter.POST("/", controller.Create)
		securedRouter.PUT("/", controller.Update)
		securedRouter.GET("/detail", controller.GetDetail)
		securedRouter.POST("/follow", controller.Follow)
		securedRouter.POST("/unfollow", controller.Unfollow)
		securedRouter.GET("/list-followed", controller.GetListFollowed)
	}
}
