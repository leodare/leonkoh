package review

import (
	"backend/internal/usecases/review"
	"backend/pkg/constants"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
)

type controller struct {
	deleteUseCase                review.DeleteUseCase
	approveUseCase               review.ApproveUseCase
	getListUseCase               review.GetListUseCase
	getListByRestaurantIdUseCase review.GetListByRestaurantIdUseCase
	updateUseCase                review.UpdateUseCase
	createUseCase                review.CreateUseCase
}

// NewReviewController initializes ReviewController
func NewController(
	deleteUseCase review.DeleteUseCase,
	getListUseCase review.GetListUseCase,
	updateUseCase review.UpdateUseCase,
	createUseCase review.CreateUseCase,
	getListByRestaurantIdUseCase review.GetListByRestaurantIdUseCase,
	approveUseCase review.ApproveUseCase,
) Controller {
	return &controller{
		deleteUseCase:                deleteUseCase,
		getListUseCase:               getListUseCase,
		updateUseCase:                updateUseCase,
		createUseCase:                createUseCase,
		getListByRestaurantIdUseCase: getListByRestaurantIdUseCase,
		approveUseCase:               approveUseCase,
	}
}

// Create handles requests to
// @Router /v1/reviews [POST]
// @Summary Create handles requests to
// @Description This is the handler function for Create at endpoint
// @Tags Review
// @Accept json
// @Produce json
// @Param payload body CreateRequest true "Payload"
// @Success 200 {object} http.BaseResponse{Data=CreateResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Create(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req CreateRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	input := MapToCreateInput(req)
	input.ExecutorId = userId
	outputI, err := ctl.createUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}
	output := outputI.(review.CreateOutput)
	resData := MapToCreateResponse(output)
	http.SuccessResponse(ctx, resData)
}

// Update handles requests to /{id}
// @Router /v1/reviews/{id} [PUT]
// @Summary Update handles requests to /{id}
// @Description This is the handler function for Update at endpoint /{id}
// @Tags Review
// @Accept json
// @Produce json
// @Param payload body UpdateRequest true "Payload"
// @Success 200 {object} http.BaseResponse{Data=UpdateResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Update(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req UpdateRequest
	if err := ctx.ShouldBindUri(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	userId := ctx.GetString(constants.ContextKeyUserId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	input := MapToUpdateInput(req)
	input.ExecutorId = userId
	output, err := ctl.updateUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, output)
}

// GetList handles requests to
// @Router /v1/reviews [GET]
// @Summary GetList handles requests to
// @Description This is the handler function for GetList at endpoint
// @Tags Review
// @Accept json
// @Produce json
// @Param query query GetListRequest true "Query Parameters"
// @Success 200 {object} GetListResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) GetList(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req GetListRequest

	if err := ctx.ShouldBindQuery(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToGetListInput(req)
	output, err := ctl.getListUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	response := MapToGetListResponse(output)
	http.SuccessResponse(ctx, response)
}

// GetListByRestaurantId handles requests to
// @Router /v1/reviews/{restaurant_id} [GET]
// @Summary  api for get list review by restaurant id
// @Description  api for get list review by restaurant id
// @Tags Review
// @Accept json
// @Produce json
// @Param restaurant_id path string true "ID of the restaurant"s
// @Param query query GetListByRestaurantIdRequest true "Query Parameters"
// @Success 200 {object}  http.BaseResponse{Data=GetListByRestaurantIdResponse} "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) GetListByRestaurantId(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)
	restaurantId := ctx.Param("restaurant_id")
	var req GetListByRestaurantIdRequest

	if err := ctx.ShouldBindQuery(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToGetListByRestaurantIdInput(restaurantId, req)
	output, err := ctl.getListByRestaurantIdUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	response := MapToGetListByRestaurantIdResponse(output)
	http.SuccessResponse(ctx, response)
}

// Delete handles requests to
// @Router /v1/reviews/{id} [DELETE]
// @Summary Delete handles requests to
// @Description This is the handler function for Delete at endpoint
// @Tags Review
// @Accept json
// @Produce json
// @Param id path string true "ID of the resource to delete"
// @Success 200 {object} DeleteResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) Delete(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req DeleteRequest

	if err := ctx.ShouldBindUri(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToDeleteInput(req)
	output, err := ctl.deleteUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, output)
}

// ApproveReview handles requests to /{id}
// @Router /v1/reviews/approve/{id} [PUT]
// @Summary api for approve review
// @Description  api for approve reviews
// @Tags Review
// @Accept json
// @Produce json
// @Param id path string true "ID of the resource to approve"
// @Success 200 {object} http.BaseResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) ApproveReview(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req ApproveRequest
	if err := ctx.ShouldBindUri(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToApproveInput(req)
	_, err := ctl.approveUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SuccessResponse(ctx, nil)
}
