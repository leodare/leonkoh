package review

import (
	"github.com/gin-gonic/gin"
)

type Controller interface {
	Delete(ctx *gin.Context)
	GetList(ctx *gin.Context)
	GetListByRestaurantId(ctx *gin.Context)
	Update(ctx *gin.Context)
	Create(ctx *gin.Context)
	ApproveReview(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller, middlewares ...gin.HandlerFunc) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/reviews")
	securedRouter.Use(middlewares...)
	{
		// implement controller to here
		securedRouter.DELETE("/:id", controller.Delete)
		securedRouter.PUT("/approve/:id", controller.ApproveReview)
		securedRouter.GET("", controller.GetList)
		securedRouter.GET("/get-list/:restaurant_id", controller.GetListByRestaurantId)
		securedRouter.PUT("/:id", controller.Update)
		securedRouter.POST("", controller.Create)
	}
}
