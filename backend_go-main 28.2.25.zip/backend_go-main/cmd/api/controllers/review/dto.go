package review

import "backend/internal/infrastructure/persistence/postgres/pagination"

type CreateRequest struct {
	Title              string   `json:"title"`
	Content            string   `json:"content"`
	RestaurantID       string   `json:"restaurant_id"`
	VisitDate          *string  `json:"visit_date"`
	TasteRating        int      `json:"taste_rating"`
	AromaRating        int      `json:"aroma_rating"`
	AtmosphereRating   int      `json:"atmosphere_rating"`
	PresentationRating int      `json:"presentation_rating"`
	ServiceRating      int      `json:"service_rating"`
	StaticIDs          []string `json:"static_ids"`
}
type CreateResponse struct {
	CreatedBy          string   `json:"created_by"`
	Title              string   `json:"title"`
	Content            string   `json:"content"`
	RestaurantID       string   `json:"restaurant_id"`
	VisitDate          *string  `json:"visit_date"`
	OverallRating      float64  `json:"overall_rating"`
	TasteRating        int      `json:"taste_rating"`
	AromaRating        int      `json:"aroma_rating"`
	AtmosphereRating   int      `json:"atmosphere_rating"`
	PresentationRating int      `json:"presentation_rating"`
	ServiceRating      int      `json:"service_rating"`
	StaticIDs          []string `json:"static_i_ds"`
	CreatedAt          string   `json:"created_at"`
}
type UpdateRequest struct {
	ID                 string   `uri:"id"`
	Title              string   `json:"title"`
	Content            string   `json:"content"`
	RestaurantID       string   `json:"restaurant_id"`
	VisitDate          *string  `json:"visit_date"`
	TasteRating        int      `json:"taste_rating"`
	AromaRating        int      `json:"aroma_rating"`
	AtmosphereRating   int      `json:"atmosphere_rating"`
	PresentationRating int      `json:"presentation_rating"`
	ServiceRating      int      `json:"service_rating"`
	StaticIDs          []string `json:"static_ids"`
}
type UpdateResponse struct {
	ID                 string   `uri:"id"`
	Title              string   `json:"title"`
	Content            string   `json:"content"`
	RestaurantID       string   `json:"restaurant_id"`
	VisitDate          *string  `json:"visit_date"`
	TasteRating        int      `json:"taste_rating"`
	AromaRating        int      `json:"aroma_rating"`
	AtmosphereRating   int      `json:"atmosphere_rating"`
	PresentationRating int      `json:"presentation_rating"`
	ServiceRating      int      `json:"service_rating"`
	StaticIDs          []string `json:"static_ids"`
}
type GetListRequest struct {
	pagination.Input
	RestaurantID string `json:"restaurant_id" form:"restaurant_id"`
	Latest       bool   `json:"latest" form:"latest"`
}
type GetListResponse struct {
	Reviews []Review `json:"reviews"`
	Meta    pagination.Meta
}
type GetListByRestaurantIdRequest struct {
	pagination.Input
	Latest bool `json:"latest" form:"latest"`
}
type GetListByRestaurantIdResponse struct {
	Reviews []Review `json:"reviews"`
	Meta    pagination.Meta
}
type Review struct {
	ID                 string   `json:"id"`
	Title              string   `json:"title"`
	Content            string   `json:"content"`
	RestaurantID       string   `json:"restaurant_id"`
	VisitDate          *string  `json:"visit_date"`
	TasteRating        int      `json:"taste_rating"`
	AromaRating        int      `json:"aroma_rating"`
	AtmosphereRating   int      `json:"atmosphere_rating"`
	PresentationRating int      `json:"presentation_rating"`
	ServiceRating      int      `json:"service_rating"`
	StaticIDs          []string `json:"static_i_ds"`
}
type DeleteRequest struct {
	ReviewID string `uri:"id"`
}
type DeleteResponse struct {
	// TODO: Thêm các trường
}
type ApproveRequest struct {
	ReviewID string `uri:"id"`
}
