package review

import (
	"backend/internal/usecases/review"
)

// MapToCreateInput Map CreateRequest to review.CreateInput
func MapToCreateInput(req CreateRequest) review.CreateInput {
	return review.CreateInput{
		Title:              req.Title,
		Content:            req.Content,
		RestaurantID:       req.RestaurantID,
		VisitDate:          req.VisitDate,
		TasteRating:        req.TasteRating,
		AromaRating:        req.AromaRating,
		AtmosphereRating:   req.AtmosphereRating,
		PresentationRating: req.PresentationRating,
		ServiceRating:      req.ServiceRating,
		StaticIDs:          req.StaticIDs,
	}
}

// MapToCreateResponse Map CreateRequest to review.CreateInput
func MapToCreateResponse(output review.CreateOutput) CreateResponse {
	return CreateResponse{
		CreatedBy:          output.CreatedBy,
		Title:              output.Title,
		Content:            output.Content,
		RestaurantID:       output.RestaurantID,
		VisitDate:          output.VisitDate,
		OverallRating:      output.OverallRating,
		TasteRating:        output.TasteRating,
		AromaRating:        output.AromaRating,
		AtmosphereRating:   output.AtmosphereRating,
		PresentationRating: output.PresentationRating,
		ServiceRating:      output.ServiceRating,
		StaticIDs:          output.StaticIDs,
		CreatedAt:          output.CreatedAt,
	}
}

// MapToUpdateInput Map UpdateRequest to review.UpdateInput
func MapToUpdateInput(req UpdateRequest) review.UpdateInput {
	return review.UpdateInput{
		ID:                 req.ID,
		Title:              req.Title,
		Content:            req.Content,
		RestaurantID:       req.RestaurantID,
		VisitDate:          req.VisitDate,
		TasteRating:        req.TasteRating,
		AromaRating:        req.AromaRating,
		AtmosphereRating:   req.AtmosphereRating,
		PresentationRating: req.PresentationRating,
		ServiceRating:      req.ServiceRating,
		StaticIDs:          req.StaticIDs,
	}
}

// MapToGetListInput Map GetListRequest to review.GetListInput
func MapToGetListInput(req GetListRequest) review.GetListInput {
	return review.GetListInput{
		Paging:       req.Input,
		RestaurantID: req.RestaurantID,
		Latest:       req.Latest,
	}
}

// MapToGetListByRestaurantIdInput Map GetListByRestaurantIdRequest and restaurantId to review.GetListByRestaurantIdInput
func MapToGetListByRestaurantIdInput(restaurantId string, req GetListByRestaurantIdRequest) review.GetListByRestaurantIdInput {
	return review.GetListByRestaurantIdInput{
		Paging:       req.Input,
		RestaurantID: restaurantId,
		Latest:       req.Latest,
	}
}

// MapToGetListResponse Map review.GetListOutput to GetListResponse
func MapToGetListResponse(output *review.GetListOutput) GetListResponse {
	return GetListResponse{
		Reviews: mapReviewEntitiesToReviewsOutput(output.Reviews),
		Meta:    output.Meta,
	}
}

// MapToGetListByRestaurantIdResponse Map review.GetListByRestaurantIdOutput to GetListByRestaurantIdResponse
func MapToGetListByRestaurantIdResponse(output *review.GetListByRestaurantIdOutput) GetListByRestaurantIdResponse {
	return GetListByRestaurantIdResponse{
		Reviews: mapReviewEntitiesToReviewsOutput(output.Reviews),
		Meta:    output.Meta,
	}
}

func mapReviewEntitiesToReviewsOutput(reviews []review.Review) []Review {
	var result []Review

	for _, r := range reviews {
		result = append(result, Review{
			ID:                 r.ID,
			Title:              r.Title,
			Content:            r.Content,
			RestaurantID:       r.RestaurantID,
			VisitDate:          r.VisitDate,
			TasteRating:        r.TasteRating,
			AromaRating:        r.AromaRating,
			AtmosphereRating:   r.AtmosphereRating,
			PresentationRating: r.PresentationRating,
			ServiceRating:      r.ServiceRating,
			StaticIDs:          r.StaticIDs,
		})
	}

	return result
}

// MapToDeleteInput Map DeleteRequest to review.DeleteInput
func MapToDeleteInput(req DeleteRequest) review.DeleteInput {
	return review.DeleteInput{
		ReviewID: req.ReviewID,
	}
}

// MapToApproveInput Map ApproveRequest to review.ApproveInput
func MapToApproveInput(req ApproveRequest) review.ApproveInput {
	return review.ApproveInput{
		ReviewID: req.ReviewID,
	}
}
