package cuisine_type

import (
	"backend/internal/usecases/cuisine-type"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
)

type controller struct {
	getListUseCase cuisine_type.GetListUseCase
	createUseCase  cuisine_type.CreateUseCase
}

// NewCuisineTypeController initializes CuisineTypeController
func NewController(
	getListUseCase cuisine_type.GetListUseCase,
	createUseCase cuisine_type.CreateUseCase,
) Controller {
	return &controller{
		getListUseCase: getListUseCase,
		createUseCase:  createUseCase,
	}
}

// Create handles requests to
// @Router /v1/cuisine-types [POST]
// @Summary Create handles requests to
// @Description This is the handler function for Create at endpoint
// @Tags CuisineType
// @Accept json
// @Produce json
// @Param payload body CreateRequest true "Payload"
// @Success 200 {object} CreateResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) Create(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req CreateRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToCreateInput(req)
	output, err := ctl.createUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	o, ok := output.(cuisine_type.CreateOutput)
	if !ok {
		ctxLogger.Errorf("Invalid output type")
		http.HandleError(ctx, xerror.NewError(xerror.InternalServer))
		return
	}
	res := MapToCreateResponse(o)
	http.SuccessResponse(ctx, res)
}

// GetList handles requests to
// @Router /v1/cuisine-types [GET]
// @Summary GetList handles requests to
// @Description This is the handler function for GetList at endpoint
// @Tags CuisineType
// @Accept json
// @Produce json
// @Param query query GetListRequest true "Query Parameters"
// @Success 200 {object} GetListResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
func (ctl *controller) GetList(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req GetListRequest

	if err := ctx.ShouldBindQuery(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToGetListInput(req)
	output, err := ctl.getListUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	response := MapToGetListResponse(output)
	http.SuccessResponse(ctx, response)
}
