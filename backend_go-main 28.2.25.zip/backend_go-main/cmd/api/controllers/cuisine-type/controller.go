package cuisine_type

import (
	"github.com/gin-gonic/gin"
)

type Controller interface {
	GetList(ctx *gin.Context)
	Create(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/cuisine-types")

	{
		// implement controller to here
		securedRouter.GET("", controller.GetList)
		securedRouter.POST("", controller.Create)
	}
}
