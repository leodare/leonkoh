package cuisine_type

import (
	"backend/internal/usecases/cuisine-type"
)

// Map CreateRequest to cuisine-type.CreateInput
func MapToCreateInput(req CreateRequest) cuisine_type.CreateInput {
	return cuisine_type.CreateInput{
		Name: req.Name,
	}
}

func MapToCreateResponse(output cuisine_type.CreateOutput) CreateResponse {
	return CreateResponse{
		ID: output.ID,
	}
}

// Map GetListRequest to cuisine-type.GetListInput
func MapToGetListInput(req GetListRequest) cuisine_type.GetListInput {
	return cuisine_type.GetListInput{
		Name:   req.Name,
		Paging: req.Input,
	}
}

// Map cuisine-type.GetListOutput to GetListResponse
func MapToGetListResponse(output *cuisine_type.GetListOutput) GetListResponse {
	cuisineTypes := make([]CuisineType, 0)
	for _, item := range output.CuisineTypes {
		cuisineTypes = append(cuisineTypes, CuisineType{
			ID:   item.ID,
			Name: item.Name,
		})
	}
	return GetListResponse{
		CuisineTypes: cuisineTypes,
		Meta:         output.Meta,
	}
}
