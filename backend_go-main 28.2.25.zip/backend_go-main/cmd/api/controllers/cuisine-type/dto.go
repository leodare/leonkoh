package cuisine_type

import (
	"backend/internal/infrastructure/persistence/postgres/pagination"
)

type CreateRequest struct {
	Name string `json:"name,required"`
}
type CreateResponse struct {
	ID string `json:"id"`
}
type GetListRequest struct {
	Name string `form:"name"`
	pagination.Input
}
type GetListResponse struct {
	CuisineTypes []CuisineType `json:"cuisine_types"`
	Meta         pagination.Meta
}

type CuisineType struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}
