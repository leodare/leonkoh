package user

import (
	"backend/internal/usecases/user"
	"backend/pkg/constants"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
)

type controller struct {
	verifyAccountUseCase  user.VerifyAccountUseCase
	resendOTPUseCase      user.ResendOTPUseCase
	changePasswordUseCase user.ChangePasswordUseCase
}

// NewUserController initializes UserController
func NewController(
	verifyAccountUseCase user.VerifyAccountUseCase,
	resendOTPUseCase user.ResendOTPUseCase,
	changePasswordUseCase user.ChangePasswordUseCase,
) Controller {
	return &controller{
		verifyAccountUseCase:  verifyAccountUseCase,
		resendOTPUseCase:      resendOTPUseCase,
		changePasswordUseCase: changePasswordUseCase,
	}
}

// VerifyAccount handles requests to /verify-account
// @Router /v1/users/verify-account [POST]
// @Summary VerifyAccount handles requests to /verify-account
// @Description This is the handler function for VerifyAccount at endpoint /verify-account
// @Tags User
// @Accept json
// @Produce json
// @Param payload body VerifyAccountRequest true "Payload"
// @Success 200 {object} http.BaseResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) VerifyAccount(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)
	userId := ctx.GetString(constants.ContextKeyUserId)

	var req VerifyAccountRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	input := MapToVerifyAccountInput(req)
	input.UserId = userId
	err := ctl.verifyAccountUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SimpleSuccessResponse(ctx)
}

// ResendOTP handles requests to /resend-otp
// @Router /v1/users/resend-otp [POST]
// @Summary ResendOTP handles requests to /resend-otp
// @Description This is the handler function for ResendOTP at endpoint /resend-otp
// @Tags User
// @Accept json
// @Produce json
// @Param payload body ResendOTPRequest true "Payload"
// @Success 200 {object} http.BaseResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) ResendOTP(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)
	userId := ctx.GetString(constants.ContextKeyUserId)
	var req ResendOTPRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}
	input := MapToResendOTPInput(req)
	input.UserId = userId
	err := ctl.resendOTPUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	http.SimpleSuccessResponse(ctx)
}

// ChangePassword handles requests to /change-password
// @Router /v1/users/change-password [POST]
// @Summary ChangePassword handles requests to /change-password
// @Description This is the handler function for ChangePassword at endpoint /change-password
// @Tags Auth
// @Accept json
// @Produce json
// @Param payload body ChangePasswordRequest true "Payload"
// @Success 200 {object} ChangePasswordResponse "Successful result"
// @Param os header string true "OS" default(ios)
// @Param device-id header string true "ID of device" default(123456-7890)
// @Param os-version header string true "OS Version" default(16)
// @Param app-version header string true "App Version" default(1.0.0)
// @Param device-model header string true "Device Model" default(iphone 12)
// @security BearerAuth
func (ctl *controller) ChangePassword(ctx *gin.Context) {
	ctxLogger := logger.NewLogger(ctx)

	var req ChangePasswordRequest
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, xerror.NewError(xerror.DataInvalid))
		return
	}

	userId := ctx.GetString(constants.ContextKeyUserId)
	ctxLogger.Info("userId: ", userId)
	if userId == "" {
		http.HandleError(ctx, xerror.NewError(xerror.CodeUnauthorized))
		return
	}

	input := user.ChangePasswordInput{
		UserID:      userId,
		OldPassword: req.OldPassword,
		NewPassword: req.NewPassword,
	}
	_, err := ctl.changePasswordUseCase.Execute(ctx.Request.Context(), input)
	if err != nil {
		ctxLogger.Error(err)
		http.HandleError(ctx, err)
		return
	}

	var response ChangePasswordResponse
	http.SuccessResponse(ctx, response)
}
