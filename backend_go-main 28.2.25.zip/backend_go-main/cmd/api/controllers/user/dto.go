package user

type VerifyAccountRequest struct {
	Otp string `json:"otp"`
}

type ResendOTPRequest struct {
	Method string `json:"method"`
	Action string `json:"action"`
}

type ChangePasswordRequest struct {
	OldPassword string `json:"old_password"`
	NewPassword string `json:"new_password"`
}

type ChangePasswordResponse struct{}
