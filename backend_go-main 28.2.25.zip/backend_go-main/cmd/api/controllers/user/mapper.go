package user

import (
	"backend/internal/services/otp"
	"backend/internal/usecases/user"
)

// Map VerifyAccountRequest to user.VerifyAccountInput
func MapToVerifyAccountInput(req VerifyAccountRequest) user.VerifyAccountInput {
	return user.VerifyAccountInput{
		OTP: req.Otp,
	}
}

// Map ResendOTPRequest to user.ResendOTPInput
func MapToResendOTPInput(req ResendOTPRequest) user.ResendOTPInput {
	return user.ResendOTPInput{
		Method: otp.Method(req.Method),
		Action: otp.Action(req.Action),
	}
}
