package user

import (
	"github.com/gin-gonic/gin"
)

type Controller interface {
	ResendOTP(ctx *gin.Context)
	VerifyAccount(ctx *gin.Context)
	ChangePassword(ctx *gin.Context)
}

func RegisterRoutesV1(router *gin.Engine, controller Controller, middlewares ...gin.HandlerFunc) {
	v1 := router.Group("/api/v1")
	securedRouter := v1.Group("/users")
	securedRouter.Use(middlewares...)

	{
		// implement controller to here
		securedRouter.POST("/resend-otp", controller.ResendOTP)
		securedRouter.POST("/verify-account", controller.VerifyAccount)
		securedRouter.POST("/change-password", controller.ChangePassword)
	}
}
