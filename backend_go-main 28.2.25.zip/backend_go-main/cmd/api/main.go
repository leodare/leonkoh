package main

import (
	"backend/cmd/api/controllers/address"
	"backend/cmd/api/controllers/auth"
	"backend/cmd/api/controllers/category"
	"backend/cmd/api/controllers/cuisine-type"
	"backend/cmd/api/controllers/profile"
	"backend/cmd/api/controllers/restaurant"
	"backend/cmd/api/controllers/review"
	"backend/cmd/api/controllers/static"
	"backend/cmd/api/controllers/user"
	_config "backend/internal/config"
	httpGin "backend/internal/middleware/http/gin"
	"backend/pkg/config"
	"backend/pkg/constants"
	"context"
	"errors"
	"flag"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"log"
	"net/http"
	"os"
	"os/signal"
	"time"

	_ "backend/cmd/api/docs"
)

type App struct {
	Name                  string
	Version               string
	ConfigFilePath        string
	ConfigFile            string
	restConfig            _config.HttpConfig
	router                *gin.Engine
	authMiddleware        *httpGin.Authentication
	restaurantController  restaurant.Controller
	authController        auth.Controller
	staticController      static.Controller
	userController        user.Controller
	cuisineTypeController cuisine_type.Controller
	reviewController      review.Controller
	addressController     address.Controller
	profileController     profile.Controller
	categoryController    category.Controller
}

func (a *App) initFlag() {
	flag.StringVar(&a.Name, "name", "service-name", "")
	flag.StringVar(&a.Version, "version", "1.0.0", "")
	flag.StringVar(&a.ConfigFilePath, "config-file-path", "./configs", "Config file path: path to config dir")
	flag.StringVar(&a.ConfigFile, "config-file", "config", "Config file path: path to config dir")
	flag.Parse()
}

func (a *App) initConfig() {
	configFiles := []config.ConfigFile{
		{
			Path: a.ConfigFilePath,
			Name: a.ConfigFile,
		},
	}
	configSource := &config.Viper{
		ConfigType:  constants.ConfigTypeFile,
		ConfigFiles: configFiles,
	}
	err := configSource.InitConfig()
	if err != nil {
		panic(err)
	}
}

func (a *App) registerRoute() {
	// Routes
	a.router.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{"message": "pong"})
	})
	// Swagger route
	a.router.GET("/api/v1/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	restaurant.RegisterRoutesV1(a.router, a.restaurantController, a.authMiddleware.Middleware)
	auth.RegisterRoutesV1(a.router, a.authController)
	static.RegisterRoutesV1(a.router, a.staticController)
	user.RegisterRoutesV1(a.router, a.userController, a.authMiddleware.Middleware)
	cuisine_type.RegisterRoutesV1(a.router, a.cuisineTypeController)
	category.RegisterRoutesV1(a.router, a.categoryController, a.authMiddleware.Middleware)
	review.RegisterRoutesV1(a.router, a.reviewController, a.authMiddleware.Middleware)
	address.RegisterRoutesV1(a.router, a.addressController, a.authMiddleware.Middleware)
	profile.RegisterRoutesV1(a.router, a.profileController, a.authMiddleware.Middleware)
}

func (a *App) Run() (err error) {
	a.registerRoute()
	srv := &http.Server{
		Addr:    fmt.Sprintf("%s:%s", a.restConfig.Path, a.restConfig.Port),
		Handler: a.router,
	}

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt)

	go func() {
		<-quit
		log.Println("Shutting down server...")

		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()

		if err := srv.Shutdown(ctx); err != nil {
			log.Fatalf("Server forced to shutdown: %v", err)
		}
	}()

	log.Printf("Server is running at %s:%s\n", a.restConfig.Path, a.restConfig.Port)
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatalf("Listen: %s\n", err)
		return err
	}

	log.Println("Server exiting")
	return nil
}

func inject(
	reviewController review.Controller,
	cuisineTypeController cuisine_type.Controller,
	authMiddleware *httpGin.Authentication,
	userController user.Controller,
	authController auth.Controller,
	restaurantController restaurant.Controller,
	staticController static.Controller,
	addressController address.Controller,
	profileController profile.Controller,
	categoryController category.Controller,
	app *App,
) error {
	// Inject dependencies
	app.reviewController = reviewController
	app.cuisineTypeController = cuisineTypeController
	app.staticController = staticController
	app.authMiddleware = authMiddleware
	app.userController = userController
	app.authController = authController
	app.restaurantController = restaurantController
	app.addressController = addressController
	app.profileController = profileController
	app.categoryController = categoryController
	return nil
}

// @title Bestfoody API
// @version 1.0
// @description Restfull API Application
// @scheme http
// @host localhost:9000
// @BasePath /api/
// @securityDefinitions.apikey BearerAuth
// @in header
// @name Authorization
// @description Provide your Bearer token in the format: Bearer {your_token}
// @securityDefinitions.apikey RefreshToken
// @in header
// @name RefreshToken
// @description Provide your Refresh token in the format: {your_refresh_token}
func main() {
	app := &App{}
	app.initFlag()
	app.initConfig()
	restConfig := _config.HttpConfig{}
	err := viper.UnmarshalKey("http", &restConfig)
	if err != nil {
		panic(err)
	}
	app.restConfig = restConfig

	router := gin.New()
	router.Use(
		gin.Recovery(),
		httpGin.CorsMiddleware(),
		gin.LoggerWithFormatter(httpGin.JsonLogMiddleware),
		httpGin.Trace,
		httpGin.ValidateHeader,
	)
	router.HandleMethodNotAllowed = true
	router.NoMethod(
		func(context *gin.Context) {
			context.AbortWithStatus(http.StatusMethodNotAllowed)
		},
	)
	app.router = router

	err = wireApp(app)
	if err != nil {
		panic(err)
	}

	if err := app.Run(); err != nil {
		panic(err)
	}

}
