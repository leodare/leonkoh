package main

// @title Bestfoody API
// @version 1.0
// @description Restfull API Application
// @scheme https
// @host bestfoody-staging-api.vinova.sg
// @BasePath /api/
// @securityDefinitions.apikey BearerAuth
// @in header
// @name Authorization
// @description Provide your Bearer token in the format: Bearer {your_token}
// @security BearerAuth
