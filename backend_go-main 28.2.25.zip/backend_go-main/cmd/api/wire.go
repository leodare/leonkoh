//go:build wireinject
// +build wireinject

// The build tag makes sure the stub is not built in the final build.

package main

import (
	"backend/cmd/api/controllers"
	"backend/internal/infrastructure"
	"backend/internal/middleware/http/gin"
	"backend/internal/services"
	"backend/internal/usecases"
	psqlhelper "backend/pkg/psql-helpler"
	"github.com/google/wire"
)

func wireApp(app *App) error {
	wire.Build(
		controllers.ControllerProviders,
		infrastructure.DBProvider,
		psqlhelper.NewTransactionManager,
		usecases.UseCaseProviders,
		services.Provider,
		infrastructure.ExternalProvider,
		infrastructure.CacheProvider,
		infrastructure.SMSProvider,
		gin.NewAuthentication,
		infrastructure.SearchEngineProvider,
		inject,
	)
	return nil
}
