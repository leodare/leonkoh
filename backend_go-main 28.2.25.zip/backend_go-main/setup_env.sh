#!/bin/bash
rm -rf configs/config.yaml
mkdir -p configs
echo "$configprod" >> configs/config.yaml
