package usecases

import (
	"backend/internal/usecases/demo"
	"context"
	"reflect"
	"testing"
)

func Test_sumABUseCase_Execute(t *testing.T) {
	type args struct {
		ctx   context.Context
		input demo.SumABCommand
	}
	tests := []struct {
		name    string
		args    args
		want    *demo.SumABResponse
		wantErr bool
	}{
		{
			name: "Test success",
			args: args{
				ctx: context.Background(),
				input: demo.SumABCommand{
					A: 10,
					B: 15,
				},
			},
			want: &demo.SumABResponse{
				Result: 25,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			uc := demo.NewSumABUseCase()
			got, err := uc.Execute(tt.args.ctx, tt.args.input)
			if (err != nil) != tt.wantErr {
				t.Errorf("Execute() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Execute() got = %v, want %v", got, tt.want)
			}
		})
	}
}
