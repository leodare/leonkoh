# MonoBase Project

## Giới thiệu

**MonoBase** Dự án được viết bằng **GoLang**, được thiết kế để làm cơ sở cho các ứng dụng lớn hơn, tuân theo kiến trúc **Clean Architecture** và **Domain-Driven Design (DDD)**. Dự án này có thể được sử dụng như một monolith hoặc tách thành các microservices tùy theo nhu cầu.

## Mục tiêu

- **Dễ dàng bảo trì**: Codebase được tổ chức rõ ràng, tách biệt các layer theo Clean Architecture.
- **Dễ dàng mở rộng**: Hỗ trợ thêm mới tính năng mà không ảnh hưởng đến hệ thống hiện có.
- **Tái sử dụng**: Các thành phần được thiết kế để có thể tái sử dụng ở nhiều nơi.
- **Kiểm thử hiệu quả**: Tổ chức code hỗ trợ viết unit test và integration test dễ dàng.

## Kiến trúc

Dự án được tổ chức theo kiến trúc **Clean Architecture**, bao gồm các layer chính:

- **Domain Layer**: Chứa các domain entities, value objects và repository interfaces.
- **Application Layer**: Chứa các services dùng chung và các use case cụ thể.
- **Interfaces Layer**: Chứa các thành phần giao tiếp với thế giới bên ngoài (HTTP handlers, CLI commands).
- **Infrastructure Layer**: Chứa các implement cụ thể cho repositories, services, caching, queue, storage, v.v.

## Cấu trúc thư mục chi tiết

### `cmd/`

Chứa các điểm nhập cho ứng dụng:

- `cli/`: Điểm nhập cho các lệnh CLI (ví dụ: migration, seeding).
- `http/`: Điểm nhập cho ứng dụng HTTP server.

### `configs/`

Chứa các file cấu hình cho ứng dụng:

- `config.yaml`: File cấu hình chính.
- `config.sample.yaml`: File mẫu cho cấu hình.

### `internal/`

Chứa toàn bộ code nội bộ của ứng dụng, được chia thành các layer theo Clean Architecture.

#### `domain/`

- `entities/`: Định nghĩa các domain entities.
- `valueobjects/`: Định nghĩa các value objects.
- `repositories/`: Định nghĩa các interface cho repositories.

#### `application/`

- `services/`: Chứa các service dùng chung, chia theo bounded context.
    - Mỗi service có `interface.go` và `service.go`.
- `usecases/`: Chứa các use case cụ thể.
    - Mỗi use case có các phương thức thực hiện nghiệp vụ và `dto.go` để định nghĩa Command/Result DTOs.

#### `interfaces/`

- `http/`: Chứa các HTTP handlers, DTOs và router.
    - `handlers/`: Chứa các HTTP handler.
    - `dto/`: Định nghĩa Request/Response DTOs.
    - `router.go`: Định nghĩa router cho HTTP server.
- `cli/`: Chứa các lệnh CLI.

#### `infrastructure/`

- `persistence/`: Implement repositories và định nghĩa persistence models.
    - `models/`: Định nghĩa persistence models (database entities).
    - `postgres/`: Implement repositories với PostgreSQL.
- `services/`: Implement các services bên ngoài (LDAP, Firebase).
- `caching/`: Implement caching (ví dụ: Redis).
- `queue/`: Implement queue systems (Kafka, RabbitMQ).
- `storage/`: Implement storage solutions (Local, S3).

### `pkg/`

Chứa các package có thể tái sử dụng mà không phụ thuộc vào ứng dụng cụ thể:

- `config/`: Tiện ích đọc cấu hình.
- `constants/`: Định nghĩa các hằng số chung.
- `errors/`: Xử lý lỗi tùy chỉnh.
- `logger/`: Cài đặt logging chung.
- `helpers/`: Các hàm tiện ích hỗ trợ.
- `utils/`: Các tiện ích khác.
- `jwt/`: Implement JWT Service dùng chung.

### `test/`

Chứa các test cases cho ứng dụng:

- `mocks/`: Chứa các mock objects để hỗ trợ testing.
- `integration/`: Chứa các bài kiểm thử tích hợp.

### `tools/`

Chứa các công cụ hỗ trợ phát triển:

- `docker-compose.yml`: Cấu hình Docker Compose cho môi trường phát triển và testing.

## Hướng dẫn sử dụng

### Cài đặt

1. **Clone repository**:

   ```bash
   git clone https://github.com/yourusername/monobase.git
   cd monobase