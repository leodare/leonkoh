package config

type HttpConfig struct {
	Path string `json:"path" yaml:"path"`
	Port string `json:"port" yaml:"port"`
}

type Config struct {
	HttpConfig HttpConfig `json:"api" yaml:"api"`
}

type ConsumerConfig struct {
	Brokers         []string `json:"brokers" yaml:"brokers"`
	GroupID         string   `json:"groupID" yaml:"groupID"`
	MaxRetry        int      `json:"maxRetry" yaml:"maxRetry"`
	RetryDelay      string   `json:"retryDelay" yaml:"retryDelay"`
	CommitInterval  string   `json:"commitInterval" yaml:"commitInterval"`
	Topic           string   `json:"topic" yaml:"topic"`
	DeadLetterTopic string   `json:"deadLetterTopic" yaml:"deadLetterTopic"`
	RetryTopic      *string  `json:"retryTopic" yaml:"retryTopic"`
}
