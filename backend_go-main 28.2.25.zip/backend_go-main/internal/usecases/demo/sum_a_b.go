package demo

import "context"

type SumABUseCase interface {
	Execute(context context.Context, input SumABCommand) (*SumABResponse, error)
}

type sumABUseCase struct {
}

func NewSumABUseCase() SumABUseCase {
	return &sumABUseCase{}
}

func (uc *sumABUseCase) Execute(ctx context.Context, input SumABCommand) (*SumABResponse, error) {
	return &SumABResponse{
		Result: input.A + input.B,
	}, nil
}
