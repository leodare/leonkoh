package demo

type SumABCommand struct {
	A int `json:"a"`
	B int `json:"b"`
}

type SumABResponse struct {
	Result int `json:"result"`
}
