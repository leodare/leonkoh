package static

import (
	"io"
	"mime/multipart"
)

type GetImageInput struct {
	ID string `json:"id"`
}
type GetImageOutput struct {
	Image       io.ReadCloser `json:"image"`
	ContentType string        `json:"content_type"`
}

type Image struct {
	ContentType string `json:"content_type"`
	Base64      string `json:"data"`
}

type UploadImagesInput struct {
	ImagesData []Image `json:"images_data"`
}
type UploadImagesOutput struct {
	IDs []string `json:"ids"`
}

type File struct {
	File        *multipart.FileHeader `json:"file"`
	ContentType string                `json:"content_type"`
}

type UploadFilesInput struct {
	Files []File `json:"files"`
}

type UploadFilesOutput struct {
	IDs []string `json:"ids"`
}

type GetFileInput struct {
	ID string `json:"id"`
}
type GetFileOutput struct {
	File     io.ReadCloser
	FileName string
	Type     string
}
