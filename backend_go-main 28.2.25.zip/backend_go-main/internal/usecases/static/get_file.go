package static

import (
	"backend/internal/services/static"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/dotrongnhan/sharing-package/pkg/logger"
)

type getFileUseCase struct {
	staticService static.Service
}

type GetFileUseCase interface {
	Execute(ctx context.Context, input GetFileInput) (*GetFileOutput, error)
}

func NewGetFileUseCase(staticService static.Service) GetFileUseCase {
	return &getFileUseCase{
		staticService: staticService,
	}
}

func (u *getFileUseCase) Execute(ctx context.Context, input GetFileInput) (*GetFileOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	res, err := u.staticService.GetFile(ctx, input.ID)
	if err != nil {
		ctxLogger.Errorf("Failed to get file, err: %v", err)
		return nil, err
	}
	if res == nil {
		ctxLogger.Errorf("File not found")
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	fileName := utils.GetFileName(res.File, res.Type)

	return &GetFileOutput{
		File:     res.File,
		FileName: fileName,
		Type:     utils.FindMimeTypesByValue(res.Type),
	}, nil
}
