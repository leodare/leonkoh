package static

import (
	"backend/internal/services/static"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/dotrongnhan/sharing-package/pkg/logger"
	"io"
	"mime/multipart"
	"strings"
)

type UploadFilesUseCase interface {
	Execute(ctx context.Context, input *UploadFilesInput) (*UploadFilesOutput, error)
}

type uploadFilesInput struct {
	staticService static.Service
}

func NewUploadFilesUseCase(staticService static.Service) UploadFilesUseCase {
	return &uploadFilesInput{
		staticService: staticService,
	}
}

func (u *uploadFilesInput) Execute(ctx context.Context, input *UploadFilesInput) (*UploadFilesOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	var result = make([]string, 0, len(input.Files))
	for _, item := range input.Files {
		file, err := handleMultipartFile(item.File)
		if err != nil {
			ctxLogger.Errorf("Failed to handle multipart file: %v", err)
			return nil, err
		}
		fileExtension := item.File.Filename[strings.LastIndex(item.File.Filename, ".")+1:]
		uploadFileOutput, err := u.staticService.UploadFile(ctx, static.UploadFileInput{
			Prefix:        "import-file/",
			File:          file,
			ContentType:   item.ContentType,
			FileExtension: fileExtension,
		})
		if err != nil {
			ctxLogger.Errorf("Failed to upload file: %v", err)
			return nil, err
		}
		result = append(result, uploadFileOutput.ID)
	}
	return &UploadFilesOutput{
		IDs: result,
	}, nil
}

func handleMultipartFile(multipartFile *multipart.FileHeader) (io.Reader, error) {
	// Mở file từ file header
	file, err := multipartFile.Open()
	if err != nil {
		return nil, xerror.NewError(xerror.CantOpenFile)
	}
	// Trả về file dưới dạng io.Reader
	return file, nil
}
