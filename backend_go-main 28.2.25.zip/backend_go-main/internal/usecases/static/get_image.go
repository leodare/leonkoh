package static

import (
	"backend/internal/services/static"
	xerror "backend/pkg/x-error"
	"context"
)

type getImageUseCase struct {
	staticService static.Service
}

type GetImageUseCase interface {
	Execute(ctx context.Context, input GetImageInput) (*GetImageOutput, error)
}

func NewGetImageUseCase(imageService static.Service) GetImageUseCase {
	return &getImageUseCase{
		staticService: imageService,
	}
}

func (u *getImageUseCase) Execute(ctx context.Context, input GetImageInput) (*GetImageOutput, error) {
	if input.ID == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	res, err := u.staticService.GetImage(ctx, input.ID)
	if err != nil {
		return nil, err
	}
	return &GetImageOutput{
		Image:       res.Image,
		ContentType: res.Type,
	}, nil
}
