package static

import (
	"backend/internal/services/static"
	"context"
)

type uploadImagesUseCase struct {
	staticService static.Service
}

type UploadImagesUseCase interface {
	Execute(ctx context.Context, input UploadImagesInput) (*UploadImagesOutput, error)
}

func NewUploadImagesUseCase(staticService static.Service) UploadImagesUseCase {
	return &uploadImagesUseCase{
		staticService: staticService,
	}
}

func (u uploadImagesUseCase) Execute(ctx context.Context, input UploadImagesInput) (*UploadImagesOutput, error) {
	var ids = make([]string, 0, len(input.ImagesData))
	for _, imageData := range input.ImagesData {
		output, err := u.staticService.UploadImage(ctx, static.UploadImageInput{
			ImageData:   imageData.Base64,
			ContentType: imageData.ContentType,
		})
		if err != nil {
			return nil, err
		}
		ids = append(ids, output.ID)
	}
	return &UploadImagesOutput{
		ids,
	}, nil
}
