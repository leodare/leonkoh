package category

import (
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
)

type deleteUseCase struct {
	categoryRepo repositories.Category
}

type DeleteUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewDeleteUseCase(
	categoryRepo repositories.Category,
	transactionManager psqlhelper.TransactionManager,
) DeleteUseCase {
	useCase := &deleteUseCase{
		categoryRepo: categoryRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *deleteUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)
	input, ok := payload.(DeleteInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	//validate and get category
	err := uc.validateInput(ctx, input)
	if err != nil {
		return nil, err
	}

	err = uc.categoryRepo.Delete(ctx, input.CategoryID)
	if err != nil {
		ctxLogger.Errorf("Failed while delete category: %s", err.Error())
		return nil, err
	}

	return nil, nil
}

func (uc *deleteUseCase) validateInput(ctx context.Context, input DeleteInput) error {
	ctxLogger := logger.NewLogger(ctx)
	//validate UserID
	_, err := uuid.Parse(input.CategoryID)
	if err != nil || input.CategoryID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}

	//validate and get category
	category, err := uc.categoryRepo.GetByID(ctx, input.CategoryID)
	if err != nil {
		if err.Error() != xerror.CodeDataNotFound {
			ctxLogger.Errorf("failed to get category by id: %s", err.Error())
			return err
		}
	}
	if category == nil {
		return xerror.NewError(xerror.CodeDataMissing)
	}
	return nil
}
