package category

import "backend/internal/entities"

func mapCategoryEntitiesToCategoriesOutput(reviews []entities.Category) []Category {
	var result []Category

	for _, r := range reviews {
		result = append(result, Category{
			ID:          r.ID,
			Name:        r.Name,
			Description: r.Description,
		})
	}

	return result
}
