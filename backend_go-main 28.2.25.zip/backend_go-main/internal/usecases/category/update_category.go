package category

import (
	"backend/internal/entities"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
	"strings"
)

type updateUseCase struct {
	categoryRepo repositories.Category
}

type UpdateUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewUpdateUseCase(
	categoryRepo repositories.Category,
	transactionManager psqlhelper.TransactionManager,
) UpdateUseCase {
	useCase := &updateUseCase{
		categoryRepo: categoryRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *updateUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)
	input, ok := payload.(UpdateInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	//validate and get category
	categoryOld, err := uc.validateInput(ctx, input)
	if err != nil {
		return nil, err
	}
	if categoryOld == nil {
		return nil, xerror.NewError(xerror.InternalServer)
	}
	categoryOld.Name = input.Name
	categoryOld.Description = input.Description
	err = uc.categoryRepo.Update(ctx, categoryOld)
	if err != nil {
		ctxLogger.Errorf("Failed while update category: %s", err.Error())
		return nil, err
	}
	categoryNew, err := uc.categoryRepo.GetByID(ctx, categoryOld.ID)
	if err != nil {
		ctxLogger.Errorf("GetByID profileRepo: %v", err)
		return nil, err
	}
	if categoryNew == nil {
		ctxLogger.Errorf("Update profile failed categoryNew is nil")
		return nil, xerror.NewError(xerror.InternalServer)
	}

	return UpdateOutput{
		ID:          categoryNew.ID,
		Name:        categoryNew.Name,
		Description: categoryNew.Description,
	}, nil
}

func (uc *updateUseCase) validateInput(ctx context.Context, input UpdateInput) (*entities.Category, error) {
	ctxLogger := logger.NewLogger(ctx)
	//validate UserID
	_, err := uuid.Parse(input.ID)
	if err != nil {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	if input.ID == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	//validate and get category
	category, err := uc.categoryRepo.GetByID(ctx, input.ID)
	if err != nil {
		ctxLogger.Errorf("failed to get category by id: %s", err.Error())
		return nil, err
	}
	if category == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	//Name
	if input.Name == nil || strings.TrimSpace(*input.Name) == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	//validate duplicate name
	categoryExist, err := uc.categoryRepo.GetByName(ctx, *input.Name)
	if err != nil {
		ctxLogger.Errorf("failed to get category by name: %s", err.Error())
		return nil, err
	}
	if categoryExist != nil && category.Name != nil && categoryExist.Name != nil {
		if strings.ToLower(*categoryExist.Name) != strings.ToLower(*category.Name) {
			return nil, xerror.NewError(xerror.CategoryExisted)
		}
	}
	return category, nil
}
