package category

import "backend/internal/infrastructure/persistence/postgres/pagination"

type CreateInput struct {
	Name        *string `json:"name"`
	Description *string `json:"description"`
}

type CreateOutput struct {
	ID string `json:"id"`
}

type UpdateInput struct {
	ID          string  `json:"id"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
}

type UpdateOutput struct {
	ID          string  `json:"id"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
}

type DeleteInput struct {
	CategoryID string
}

type GetListInput struct {
	Paging pagination.Input
}

type GetListOutput struct {
	Categories []Category
	Meta       pagination.Meta
}

type Category struct {
	ID          string  `json:"id"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
}
