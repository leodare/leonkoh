package category

import (
	"backend/internal/entities"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"strings"
)

type createUseCase struct {
	categoryRepo repositories.Category
}

type CreateUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewCreateUseCase(
	transactionManager psqlhelper.TransactionManager,
	categoryRepo repositories.Category,
) CreateUseCase {
	useCase := &createUseCase{
		categoryRepo: categoryRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *createUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)

	input, ok := payload.(CreateInput)
	if !ok {
		ctxLogger.Errorf("Invalid input type")
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	if err := uc.validateInput(ctx, input); err != nil {
		ctxLogger.Error(err)
		return nil, err
	}

	id, err := uc.categoryRepo.Create(ctx, &entities.Category{
		Name:        input.Name,
		Description: input.Description,
	})
	if err != nil {
		ctxLogger.Error(err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	return CreateOutput{
		ID: *id,
	}, nil
}

func (uc *createUseCase) validateInput(ctx context.Context, input CreateInput) (err error) {
	ctxLogger := logger.NewLogger(ctx)

	if input.Name == nil || strings.TrimSpace(*input.Name) == "" {
		return xerror.NewError(xerror.DataInvalid)
	}

	//check duplicate name category
	categoryExist, err := uc.categoryRepo.GetByName(ctx, *input.Name)
	if err != nil {
		ctxLogger.Error(err)
		return err
	}
	if categoryExist != nil {
		return xerror.NewError(xerror.CategoryExisted)
	}
	return nil
}
