package category

import (
	"backend/internal/repositories"
	"backend/internal/services/category"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
)

type getListUseCase struct {
	categoryRepo    repositories.Category
	categoryService category.Service
}

type GetListUseCase interface {
	Execute(ctx context.Context, input GetListInput) (*GetListOutput, error)
}

func NewGetListUseCase(
	categoryRepo repositories.Category,
	categoryService category.Service,
) GetListUseCase {
	return &getListUseCase{
		categoryRepo:    categoryRepo,
		categoryService: categoryService,
	}
}

func (uc *getListUseCase) Execute(ctx context.Context, input GetListInput) (*GetListOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	getListCategoriesOutput, err := uc.categoryService.GetListCategories(ctx,
		category.GetListCategoriesInput{
			Paging: input.Paging,
		})
	if err != nil {
		ctxLogger.Errorf("Failed to get list categories: %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	if getListCategoriesOutput.Data == nil {
		return &GetListOutput{}, nil
	}

	categories := mapCategoryEntitiesToCategoriesOutput(getListCategoriesOutput.Data.Data)

	return &GetListOutput{
		Categories: categories,
		Meta:       getListCategoriesOutput.Data.Meta,
	}, nil
}
