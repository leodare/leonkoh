package restaurant

import (
	"backend/internal/entities"
	"backend/internal/usecases/common"
	"backend/pkg/utils"
)

func MappingRestaurantEntityToRestaurantResponse(restaurant *entities.Restaurant) *Info {
	addressIds := make([]string, 0)
	addresses := make([]common.Address, 0)
	for _, address := range restaurant.RestaurantAddresses {
		addressIds = append(addressIds, address.AddressID)
		addresses = append(addresses, *common.MappingAddressEntityToAddress(address.Address))
	}
	cuisineTypes := make([]CuisineType, 0)
	for _, cuisineType := range restaurant.RestaurantCuisineTypes {
		cuisineTypes = append(cuisineTypes, CuisineType{
			ID:   cuisineType.CuisineTypeID,
			Name: cuisineType.CuisineType.Name,
		})
	}
	categories := make([]Category, 0)
	for _, category := range restaurant.RestaurantCategories {
		categories = append(categories, Category{
			ID:          category.CategoryID,
			Name:        category.Category.Name,
			Description: category.Category.Description,
		})
	}
	statics := make([]common.Static, 0)
	for _, static := range restaurant.RestaurantStatics {
		statics = append(statics, common.MappingStaticEntityToStatic(static.Static))
	}
	createdAt := utils.ConvertTimeToISOString(restaurant.CreatedAt)
	var updatedAt *string
	var deletedAt *string
	if restaurant.UpdatedAt != nil {
		updatedAt = utils.NewStringPtr(utils.ConvertTimeToISOString(*restaurant.UpdatedAt))
	}
	if restaurant.DeletedAt != nil {
		deletedAt = utils.NewStringPtr(utils.ConvertTimeToISOString(restaurant.DeletedAt.Time))
	}
	info := &Info{
		ID:           restaurant.ID,
		Name:         restaurant.Name,
		UnitNumber:   restaurant.UnitNumber,
		Area:         restaurant.Area,
		Phone:        restaurant.Phone,
		OpeningTime:  restaurant.OpeningTime,
		ClosingTime:  restaurant.ClosingTime,
		PriceFrom:    restaurant.PriceFrom,
		PriceTo:      restaurant.PriceTo,
		Website:      restaurant.Website,
		Email:        restaurant.Email,
		Addresses:    addresses,
		Statics:      statics,
		CuisineTypes: cuisineTypes,
		Categories:   categories,
		CreatedAt:    createdAt,
		UpdatedAt:    updatedAt,
		DeletedAt:    deletedAt,
	}

	// Mapping restaurant address
	for _, address := range restaurant.RestaurantAddresses {
		restaurantAddress := common.MappingAddressEntityToAddress(address.Address)
		info.Addresses = append(info.Addresses, *restaurantAddress)
	}
	// Mapping restaurant category
	for _, category := range restaurant.RestaurantCategories {
		info.Categories = append(info.Categories, Category{
			ID:          category.CategoryID,
			Name:        category.Category.Name,
			Description: category.Category.Description,
		})
	}
	// Mapping restaurant cuisine type
	for _, cuisineType := range restaurant.RestaurantCuisineTypes {
		info.CuisineTypes = append(info.CuisineTypes, CuisineType{
			ID:   cuisineType.CuisineTypeID,
			Name: cuisineType.CuisineType.Name,
		})
	}
	return info
}
