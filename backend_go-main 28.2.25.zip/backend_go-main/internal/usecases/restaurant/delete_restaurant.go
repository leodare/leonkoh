package restaurant

import (
	"backend/internal/repositories"
	"backend/pkg/logger"
	"backend/pkg/validate"
	"context"
)

type deleteRestaurantUseCase struct {
	validator      validate.Validator
	restaurantRepo repositories.Restaurant
}

type DeleteRestaurantUseCase interface {
	Execute(ctx context.Context, payload DeleteRestaurantInput) error
}

func NewDeleteRestaurantUseCase(restaurantRepo repositories.Restaurant) DeleteRestaurantUseCase {
	validator := validate.GetValidatorInstance()
	return &deleteRestaurantUseCase{
		validator:      validator,
		restaurantRepo: restaurantRepo,
	}
}

func (uc *deleteRestaurantUseCase) Execute(ctx context.Context, input DeleteRestaurantInput) error {
	ctxLogger := logger.NewLogger(ctx)

	if err := uc.validator.Validate(input); err != nil {
		return err
	}

	err := uc.restaurantRepo.Delete(ctx, input.Id)
	if err != nil {
		ctxLogger.Error("delete restaurant failed", err)
		return err
	}

	return nil
}
