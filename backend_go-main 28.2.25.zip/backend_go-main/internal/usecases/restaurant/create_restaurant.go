package restaurant

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/validate"
	"context"
)

type createRestaurantUseCase struct {
	validator              validate.Validator
	restaurantRepo         repositories.Restaurant
	restaurantCategoryRepo repositories.RestaurantCategory
	restaurantAddressRepo  repositories.RestaurantAddress
	restaurantEmployeeRepo repositories.RestaurantEmployee
}

type CreateRestaurantUseCase interface {
	Execute(ctx context.Context, payload CreateRestaurantInput) (*CreateRestaurantOutput, error)
}

func NewCreateRestaurantUseCase(
	restaurantRepo repositories.Restaurant,
	restaurantCategoryRepo repositories.RestaurantCategory,
	restaurantAddressRepo repositories.RestaurantAddress,
	restaurantEmployeeRepo repositories.RestaurantEmployee,
) CreateRestaurantUseCase {
	validator := validate.GetValidatorInstance()
	return &createRestaurantUseCase{
		validator:              validator,
		restaurantRepo:         restaurantRepo,
		restaurantCategoryRepo: restaurantCategoryRepo,
		restaurantAddressRepo:  restaurantAddressRepo,
		restaurantEmployeeRepo: restaurantEmployeeRepo,
	}
}
func (uc *createRestaurantUseCase) Execute(ctx context.Context, input CreateRestaurantInput) (*CreateRestaurantOutput, error) {
	if err := uc.validator.Validate(input); err != nil {
		return nil, err
	}

	restaurant := &entities.Restaurant{
		Name:        input.Name,
		UnitNumber:  input.UnitNumber,
		Area:        input.Area,
		Phone:       input.Phone,
		OpeningTime: input.OpeningTime,
		ClosingTime: input.ClosingTime,
		PriceFrom:   input.PriceFrom,
		PriceTo:     input.PriceTo,
	}
	id, err := uc.restaurantRepo.Create(ctx, restaurant)
	if err != nil {
		return nil, err
	}

	// Create restaurant category
	if err := uc.createRestaurantCategory(ctx, *id, input.CategoryIds); err != nil {
		return nil, err
	}
	// Create restaurant address
	if err := uc.createRestaurantAddress(ctx, *id, input.Addresses); err != nil {
		return nil, err
	}

	newRestaurant, err := uc.restaurantRepo.GetByID(ctx, *id)
	if err != nil {
		return nil, err
	}

	restaurantInfo := MappingRestaurantEntityToRestaurantResponse(newRestaurant)

	return &CreateRestaurantOutput{
		Info: *restaurantInfo,
	}, nil
}

func (uc *createRestaurantUseCase) createRestaurantCategory(ctx context.Context, restaurantID string, categoryIds []string) error {
	for _, categoryId := range categoryIds {
		restaurantCategory := &entities.RestaurantCategory{
			RestaurantID: restaurantID,
			CategoryID:   categoryId,
		}
		_, err := uc.restaurantCategoryRepo.Create(ctx, restaurantCategory)
		if err != nil {
			return err
		}
	}
	return nil
}

func (uc *createRestaurantUseCase) createRestaurantAddress(ctx context.Context, restaurantID string, addresses []AddressInput) error {
	for _, address := range addresses {
		restaurantAddress := &entities.RestaurantAddress{
			RestaurantID: restaurantID,
			AddressID:    address.AddressId,
			BranchName:   &address.BranchName,
		}
		_, err := uc.restaurantAddressRepo.Create(ctx, restaurantAddress)
		if err != nil {
			return err
		}
	}
	return nil
}
