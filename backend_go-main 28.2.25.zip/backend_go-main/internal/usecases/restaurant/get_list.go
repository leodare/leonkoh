package restaurant

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/internal/services/search"
	"backend/pkg/utils"
	"context"
	"fmt"
	"strings"
)

type getListUseCase struct {
	restaurantRepo repositories.Restaurant
	searchService  search.Service
}

type GetListUseCase interface {
	Execute(ctx context.Context, input GetListInput) (*GetListOutput, error)
}

func NewGetListUseCase(restaurantRepo repositories.Restaurant, searchService search.Service) GetListUseCase {
	return &getListUseCase{
		restaurantRepo: restaurantRepo,
		searchService:  searchService,
	}
}

func (uc *getListUseCase) Execute(ctx context.Context, input GetListInput) (*GetListOutput, error) {
	searchResult, err := uc.searchByInput(ctx, input)
	if err != nil {
		return nil, err
	}
	ids := make([]string, 0)
	for _, item := range searchResult.Results {
		var restaurant search.RestaurantDocument
		err := utils.MappingInterface(item, &restaurant)
		if err != nil {
			return nil, err
		}
		ids = append(ids, restaurant.ID)
	}

	condition := uc.buildConditions(ids)

	restaurants, err := uc.restaurantRepo.GetPaginatedByCondition(ctx, input.Paging, *condition)
	if err != nil {
		return nil, err
	}
	return uc.mapToGetListOutput(restaurants), nil
}

func (uc *getListUseCase) mapToGetListOutput(data *pagination.Pagination[entities.Restaurant]) *GetListOutput {
	records := make([]Info, 0)
	for _, item := range data.Data {
		info := MappingRestaurantEntityToRestaurantResponse(&item)
		records = append(records, *info)
	}
	return &GetListOutput{
		Restaurants: records,
		Meta:        data.Meta,
	}
}

func (uc *getListUseCase) searchByInput(ctx context.Context, input GetListInput) (*search.SearchOutput, error) {
	searchInput := search.SearchInput{
		IndexName: search.IndexNameRestaurant,
		Page:      input.Paging.Page,
		Limit:     input.Paging.Limit,
	}
	if input.Name != nil && *input.Name != "" {
		searchInput.Query = *input.Name
	}
	var filters []string
	if input.Latitude != nil && input.Longitude != nil && input.Radius != nil {
		filters = append(filters, fmt.Sprintf("_geoRadius(%.6f, %.6f, %d)", *input.Latitude, *input.Longitude, *input.Radius))
	}
	if len(input.CuisineTypes) > 0 {
		for _, cuisine := range input.CuisineTypes {
			filters = append(filters, fmt.Sprintf("cuisine_types = '%s'", cuisine))
		}
	}
	if len(input.Categories) > 0 {
		for _, category := range input.Categories {
			filters = append(filters, fmt.Sprintf("categories = '%s'", category))
		}
	}
	finalFilter := strings.Join(filters, " AND ")
	searchInput.Filter = &finalFilter
	result, err := uc.searchService.Search(ctx, searchInput)
	if err != nil {
		return nil, err
	}
	return result, nil

}
func (uc *getListUseCase) buildConditions(ids []string) *conditions.RestaurantCondition {
	condition := &conditions.RestaurantCondition{}
	condition = condition.
		WithIds(ids...).
		WithPreload(
			"RestaurantStatics",
			"RestaurantStatics.Static",
			"RestaurantCuisineTypes",
			"RestaurantCuisineTypes.CuisineType",
			"RestaurantAddresses",
			"RestaurantAddresses.Address",
			"RestaurantCategories",
			"RestaurantCategories.Category",
		)

	return condition
}
