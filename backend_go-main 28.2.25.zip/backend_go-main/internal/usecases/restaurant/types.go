package restaurant

import (
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/usecases/common"
)

type Category struct {
	ID          string  `json:"id"`
	Name        *string `gorm:"type:varchar;unique" json:"name"`
	Description *string `gorm:"type:text" json:"description"`
}
type CuisineType struct {
	ID   string
	Name string
}
type Info struct {
	ID           string           `json:"id"`
	Name         string           `json:"name"`
	UnitNumber   *string          `json:"unit_number"`
	Area         *string          `json:"area"`
	Phone        *string          `json:"phone"`
	OpeningTime  *string          `json:"opening_time"`
	ClosingTime  *string          `json:"closing_time"`
	PriceFrom    *float64         `json:"price_from"`
	PriceTo      *float64         `json:"price_to"`
	Website      *string          `json:"website"`
	Email        *string          `json:"email"`
	Addresses    []common.Address `json:"addresses"`
	Statics      []common.Static  `json:"statics"`
	CuisineTypes []CuisineType    `json:"cuisine_types"`
	Categories   []Category       `json:"categories"`
	CreatedAt    string           `json:"created_at"`
	UpdatedAt    *string          `json:"updated_at"`
	DeletedAt    *string          `json:"deleted_at"`
}

type AddressInput struct {
	AddressId  string `json:"address_id"`
	BranchName string `json:"branch_name"`
}

type GetListInput struct {
	Paging       pagination.Input
	Name         *string  `json:"name"`
	Latitude     *float64 `json:"latitude"`
	Longitude    *float64 `json:"longitude"`
	Radius       *int64   `json:"radius"`
	CuisineTypes []string `json:"cuisine_types" form:"cuisine_types"`
	Categories   []string `json:"categories" form:"categories"`
}

type GetListOutput struct {
	Restaurants []Info `json:"restaurants"`
	Meta        pagination.Meta
}

type CreateRestaurantInput struct {
	Name        string         `json:"name" validate:"required"`
	UnitNumber  *string        `json:"unit_number"`
	Area        *string        `json:"area"`
	Phone       *string        `json:"phone"`
	OpeningTime *string        `json:"opening_time"`
	ClosingTime *string        `json:"closing_time"`
	PriceFrom   *float64       `json:"price_from"`
	PriceTo     *float64       `json:"price_to"`
	CategoryIds []string       `json:"category_ids"`
	Addresses   []AddressInput `json:"addresses"`
	IsEmployee  bool           `json:"is_employee"`
	IsOwner     bool           `json:"is_owner"`
	UserId      string         `json:"user_id"`
}

type CreateRestaurantOutput struct {
	Info
}

type GetRestaurantByIDInput struct {
	Id     string `json:"id" validate:"required,uuid"`
	UserId string `json:"user_id"`
}

type GetRestaurantByIDOutput struct {
	Info
}

type UpdateRestaurantInput struct {
	Id          string         `json:"id" validate:"required,uuid"`
	Name        string         `json:"name" validate:"required"`
	UnitNumber  *string        `json:"unit_number"`
	Area        *string        `json:"area"`
	Phone       *string        `json:"phone"`
	OpeningTime *string        `json:"opening_time"`
	ClosingTime *string        `json:"closing_time"`
	PriceFrom   *float64       `json:"price_from"`
	PriceTo     *float64       `json:"price_to"`
	Addresses   []AddressInput `json:"addresses"`
	CategoryIds []string       `json:"category_ids"`
}

type UpdateRestaurantOutput struct {
	Info
}

type DeleteRestaurantInput struct {
	Id string `json:"id" validate:"required,uuid"`
}
