package restaurant

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"backend/pkg/validate"
	"context"
)

type updateRestaurantUseCase struct {
	validator          validate.Validator
	restaurantRepo     repositories.Restaurant
	restaurantAddress  repositories.RestaurantAddress
	restaurantCategory repositories.RestaurantCategory
}

type UpdateRestaurantUseCase interface {
	Execute(ctx context.Context, payload UpdateRestaurantInput) (*UpdateRestaurantOutput, error)
}

func NewUpdateRestaurantUseCase(
	restaurantRepo repositories.Restaurant,
	restaurantAddress repositories.RestaurantAddress,
	restaurantCategory repositories.RestaurantCategory,
) UpdateRestaurantUseCase {
	validator := validate.GetValidatorInstance()
	return &updateRestaurantUseCase{
		validator:          validator,
		restaurantRepo:     restaurantRepo,
		restaurantAddress:  restaurantAddress,
		restaurantCategory: restaurantCategory,
	}
}

func (uc *updateRestaurantUseCase) Execute(ctx context.Context, input UpdateRestaurantInput) (*UpdateRestaurantOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	if err := uc.validator.Validate(input); err != nil {
		return nil, err
	}

	restaurant, err := uc.restaurantRepo.GetByID(ctx, input.Id)
	if err != nil {
		return nil, err
	}

	restaurant.Name = input.Name
	restaurant.UnitNumber = input.UnitNumber
	restaurant.Area = input.Area
	restaurant.Phone = input.Phone
	restaurant.OpeningTime = input.OpeningTime
	restaurant.ClosingTime = input.ClosingTime
	restaurant.PriceFrom = input.PriceFrom
	restaurant.PriceTo = input.PriceTo

	if err := uc.restaurantRepo.Update(ctx, restaurant); err != nil {
		ctxLogger.Error("update restaurant failed", err)
		return nil, err
	}

	if err := uc.updateRestaurantAddress(ctx, input.Id, input.Addresses); err != nil {
		ctxLogger.Error("update restaurant address failed", err)
		return nil, err
	}

	if err := uc.updateRestaurantCategory(ctx, input.Id, input.CategoryIds); err != nil {
		ctxLogger.Error("update restaurant category failed", err)
		return nil, err
	}

	updatedRestaurant, err := uc.restaurantRepo.GetByID(ctx, input.Id)
	if err != nil {
		return nil, err
	}

	info := MappingRestaurantEntityToRestaurantResponse(updatedRestaurant)

	return &UpdateRestaurantOutput{
		Info: *info,
	}, nil
}

func (uc *updateRestaurantUseCase) updateRestaurantAddress(ctx context.Context, restaurantId string, addressed []AddressInput) error {
	// Delete all existing addresses
	if err := uc.restaurantAddress.DeleteByRestaurantID(ctx, restaurantId); err != nil {
		return err
	}

	// Create new addresses
	for _, address := range addressed {
		addressEntity := entities.RestaurantAddress{
			RestaurantID: restaurantId,
			AddressID:    address.AddressId,
			BranchName:   &address.BranchName,
		}
		_, err := uc.restaurantAddress.Create(ctx, &addressEntity)
		if err != nil {
			return err
		}
	}

	return nil
}

func (uc *updateRestaurantUseCase) updateRestaurantCategory(ctx context.Context, restaurantId string, categoryIds []string) error {
	// Delete all existing categories
	if err := uc.restaurantCategory.DeleteByRestaurantID(ctx, restaurantId); err != nil {
		return err
	}

	// Create new categories
	for _, categoryId := range categoryIds {
		categoryEntity := entities.RestaurantCategory{
			RestaurantID: restaurantId,
			CategoryID:   categoryId,
		}
		_, err := uc.restaurantCategory.Create(ctx, &categoryEntity)
		if err != nil {
			return err
		}
	}

	return nil
}
