package restaurant

import (
	"backend/internal/repositories"
	restaurantService "backend/internal/services/restaurant"
	"backend/pkg/logger"
	"backend/pkg/validate"
	"context"
)

type getRestaurantByIDUseCase struct {
	validator         validate.Validator
	restaurantRepo    repositories.Restaurant
	restaurantService restaurantService.Service
}

type GetRestaurantByIDUseCase interface {
	Execute(ctx context.Context, payload GetRestaurantByIDInput) (*GetRestaurantByIDOutput, error)
}

func NewGetRestaurantByIDUseCase(
	restaurantRepo repositories.Restaurant,
	restaurantService restaurantService.Service,
) GetRestaurantByIDUseCase {
	validator := validate.GetValidatorInstance()
	return &getRestaurantByIDUseCase{
		validator:         validator,
		restaurantRepo:    restaurantRepo,
		restaurantService: restaurantService,
	}
}

func (uc *getRestaurantByIDUseCase) Execute(ctx context.Context, input GetRestaurantByIDInput) (*GetRestaurantByIDOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	if err := uc.validator.Validate(input); err != nil {
		return nil, err
	}

	restaurant, err := uc.restaurantRepo.GetWithOtherById(ctx, input.Id)
	if err != nil {
		ctxLogger.Error("get restaurant by id failed", err)
		return nil, err
	}

	info := MappingRestaurantEntityToRestaurantResponse(restaurant)
	if input.UserId != "" {
		err := uc.restaurantService.CreateLogRestaurantView(ctx, restaurantService.CreateLogRestaurantViewInput{
			RestaurantID: input.Id,
			UserID:       input.UserId,
		})
		if err != nil {
			ctxLogger.Errorf("create log restaurant view failed, err:%s", err.Error())
		}
	}
	return &GetRestaurantByIDOutput{
		Info: *info,
	}, nil

}
