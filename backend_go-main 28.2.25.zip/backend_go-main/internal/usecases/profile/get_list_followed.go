package profile

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
	"github.com/spf13/viper"
)

type getListFollowedUseCase struct {
	userRepo    repositories.User
	followRepo  repositories.UserFollow
	profileRepo repositories.Profile
}

type GetListFollowedUseCase interface {
	Execute(ctx context.Context, input GetListFollowedInput) (*GetListFollowedOutput, error)
}

func NewGetListFollowedUseCase(
	userRepo repositories.User,
	followRepo repositories.UserFollow,
	profileRepo repositories.Profile,
) GetListFollowedUseCase {
	return &getListFollowedUseCase{
		userRepo:    userRepo,
		followRepo:  followRepo,
		profileRepo: profileRepo,
	}

}

func (uc *getListFollowedUseCase) Execute(ctx context.Context, input GetListFollowedInput) (*GetListFollowedOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	if err := uc.validateInput(ctx, input); err != nil {
		return nil, err
	}
	userFollowT, err := uc.followRepo.GetPaginatedByCondition(ctx, pagination.Input{
		Page:  input.Paging.Page,
		Limit: input.Paging.Limit,
	},
		conditions.UserFollowCondition{
			UserFollow: entities.UserFollow{
				FollowerID: input.UserID,
			},
			Options: conditions.AdditionalUserFollowCondition{
				Latest: input.IsLatest,
			},
			Preloads: []conditions.Preload{{Field: "Followed"}},
		})
	if err != nil {
		ctxLogger.Errorf("Failed to check existed follow: %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}
	var result GetListFollowedOutput

	if userFollowT == nil || userFollowT.Data == nil || len(userFollowT.Data) == 0 {
		return &result, nil
	}
	listUserId := make([]string, 0)
	for _, userFollow := range userFollowT.Data {
		listUserId = append(listUserId, userFollow.FollowedID)
	}
	// Get profile
	profileT, err := uc.profileRepo.GetByUserIds(ctx, listUserId)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return &result, nil
		}
		ctxLogger.Errorf("Failed to get profile by user ids: %v", err)
		return nil, err
	}
	if profileT == nil || len(profileT) == 0 {
		return &result, nil
	}
	mapUserIdToProfile := make(map[string]entities.Profile)
	for _, profile := range profileT {
		mapUserIdToProfile[profile.UserID] = profile
	}
	listFollowedData := make([]FollowedData, 0)

	for _, userFollow := range userFollowT.Data {
		profile, ok := mapUserIdToProfile[userFollow.FollowedID]
		if !ok {
			continue
		}
		var avatar *string
		domain := viper.GetString("domain")
		if profile.Avatar != nil {
			avatar = utils.NewString(domain + "/api/v1/statics/" + *profile.Avatar)
		}
		listFollowedData = append(listFollowedData, FollowedData{
			Id:         userFollow.ID,
			FollowerID: userFollow.FollowerID,
			FollowedID: userFollow.FollowedID,
			FirstName:  profile.FirstName,
			LastName:   profile.LastName,
			Avatar:     avatar,
		})
	}
	result.ListFollowed = listFollowedData
	result.Meta = userFollowT.Meta
	return &result, nil
}
func (uc *getListFollowedUseCase) validateInput(ctx context.Context, input GetListFollowedInput) error {
	ctxLogger := logger.NewLogger(ctx)
	//validate UserID
	_, err := uuid.Parse(input.UserID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.UserID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	user, err := uc.userRepo.GetByID(ctx, input.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return err
	}
	if user == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	if user.NeedVerify {
		return xerror.NewError(xerror.AccountNeedToVerify)
	}
	return nil
}
