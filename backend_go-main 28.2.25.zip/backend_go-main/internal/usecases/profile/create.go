package profile

import (
	"backend/internal/entities"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/spf13/viper"
	"strings"
	"time"
)

type createUseCase struct {
	reviewStaticRepo repositories.ReviewStatic
	userRepo         repositories.User
	staticRepo       repositories.Static
	profileRepo      repositories.Profile
	addressRepo      repositories.Address
}

type CreateUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewCreateUseCase(
	transactionManager psqlhelper.TransactionManager,
	userRepo repositories.User,
	staticRepo repositories.Static,
	profileRepo repositories.Profile,
	addressRepo repositories.Address,
) CreateUseCase {
	useCase := &createUseCase{
		profileRepo: profileRepo,
		userRepo:    userRepo,
		staticRepo:  staticRepo,
		addressRepo: addressRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *createUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)
	input, ok := payload.(CreateInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	if err := uc.validateInput(ctx, input); err != nil {
		return nil, err
	}
	var bio *string
	if input.Bio != nil {
		bioTemp := strings.TrimSpace(*input.Bio)
		if bioTemp != "" {
			bio = &bioTemp
		}
	}
	profile := entities.Profile{
		UserID:      input.UserID,
		FirstName:   input.FirstName,
		LastName:    input.LastName,
		Avatar:      input.Avatar,
		Bio:         bio,
		DateOfBirth: input.DateOfBirth,
		Gender:      input.Gender,
		AddressID:   input.AddressId,
	}
	profileID, err := uc.profileRepo.Create(ctx, &profile)
	if err != nil {
		ctxLogger.Errorf("Create profileRepo: %v", err)
		return nil, err
	}
	if profileID == nil {
		ctxLogger.Errorf("Create profile failed profileID is nil")
		return nil, xerror.NewError(xerror.InternalServer)
	}
	profileNew, err := uc.profileRepo.GetByID(ctx, *profileID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			ctxLogger.Errorf("Create profile failed profile not found")
			return nil, xerror.NewError(xerror.InternalServer)
		}
		ctxLogger.Errorf("GetByID profileRepo: %v", err)
		return nil, err
	}
	if profileNew == nil {
		ctxLogger.Errorf("Create profile failed profileNew is nil")
		return nil, xerror.NewError(xerror.InternalServer)
	}
	domain := viper.GetString("domain")
	var avatar *string
	if profileNew.Avatar != nil {
		avatar = utils.NewString(domain + "/api/v1/statics/" + *profileNew.Avatar)
	}
	return CreateOutput{
		Id:          profileNew.ID,
		UserID:      profileNew.UserID,
		FirstName:   profileNew.FirstName,
		LastName:    profileNew.LastName,
		Avatar:      avatar,
		Bio:         profileNew.Bio,
		DateOfBirth: profileNew.DateOfBirth,
		Gender:      profileNew.Gender,
		AddressID:   profileNew.AddressID,
		CreatedAt:   profileNew.CreatedAt,
		UpdatedAt:   profileNew.UpdatedAt,
	}, nil
}
func (uc *createUseCase) validateInput(ctx context.Context, input CreateInput) error {
	ctxLogger := logger.NewLogger(ctx)
	//validate UserID
	if input.UserID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	user, err := uc.userRepo.GetByID(ctx, input.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return err
	}
	if user == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	if user.NeedVerify {
		return xerror.NewError(xerror.AccountNeedToVerify)
	}
	//check profile exist with user_id
	profile, err := uc.profileRepo.GetByUserId(ctx, input.UserID)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed while get profile by user id: %v", err.Error())
		return err
	}
	if profile != nil {
		return xerror.NewError(xerror.CodeProfileAlreadyExists)
	}
	//FirstName
	if strings.TrimSpace(input.FirstName) == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	//LastName
	if strings.TrimSpace(input.LastName) == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	//Avatar
	if input.Avatar != nil {
		if strings.TrimSpace(*input.Avatar) == "" {
			return xerror.NewError(xerror.DataInvalid)
		}
		static, err := uc.staticRepo.GetByID(ctx, *input.Avatar)
		if err != nil {
			if err.Error() == xerror.CodeDataNotFound {
				return err
			}
			ctxLogger.Errorf("Failed while get static by id: %v", err.Error())
			return err
		}
		if static == nil {
			return xerror.NewError(xerror.CodeDataNotFound)
		}
	}
	//Bio
	//DateOfBirth
	if input.DateOfBirth != nil {
		_, err = time.Parse(time.RFC3339, *input.DateOfBirth)
		if err != nil {
			return xerror.NewError(xerror.DataInvalid)
		}
	}
	//Gender
	if input.Gender != entities.GenderMale && input.Gender != entities.GenderFemale && input.Gender != entities.GenderOther {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.AddressId != nil {
		if strings.TrimSpace(*input.AddressId) == "" {
			return xerror.NewError(xerror.DataInvalid)
		}
		_, err := uc.addressRepo.GetByID(ctx, *input.AddressId)
		if err != nil {
			if err.Error() == xerror.CodeDataNotFound {
				return err
			}
			ctxLogger.Errorf("Failed while get address by id: %s", err.Error())
			return err
		}
	}
	return nil
}
