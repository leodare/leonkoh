package profile

import (
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
	"github.com/spf13/viper"
)

type getDetailUseCase struct {
	reviewStaticRepo repositories.ReviewStatic
	userRepo         repositories.User
	staticRepo       repositories.Static
	profileRepo      repositories.Profile
	addressRepo      repositories.Address
}

type GetDetailUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewGetDetailUseCase(
	transactionManager psqlhelper.TransactionManager,
	userRepo repositories.User,
	staticRepo repositories.Static,
	profileRepo repositories.Profile,
	addressRepo repositories.Address,
) GetDetailUseCase {
	useCase := &getDetailUseCase{
		profileRepo: profileRepo,
		userRepo:    userRepo,
		staticRepo:  staticRepo,
		addressRepo: addressRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *getDetailUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)
	input, ok := payload.(GetDetailInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	_, err := uuid.Parse(input.UserId)
	if err != nil {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	profile, err := uc.profileRepo.GetByUserId(ctx, input.UserId)
	if err != nil {
		ctxLogger.Errorf("failed to get profile by user id: %s", err.Error())
		return nil, err
	}
	if profile == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	domain := viper.GetString("domain")
	var avatar *string
	if profile.Avatar != nil {
		avatar = utils.NewString(domain + "/api/v1/statics/" + *profile.Avatar)
	}
	return GetDetailOutput{
		Id:          profile.ID,
		UserID:      profile.UserID,
		FirstName:   profile.FirstName,
		LastName:    profile.LastName,
		Avatar:      avatar,
		Bio:         profile.Bio,
		DateOfBirth: profile.DateOfBirth,
		Gender:      profile.Gender,
		AddressID:   profile.AddressID,
		CreatedAt:   profile.CreatedAt,
		UpdatedAt:   profile.UpdatedAt,
	}, nil
}
