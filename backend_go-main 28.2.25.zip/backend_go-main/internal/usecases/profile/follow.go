package profile

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
	"time"
)

type followUseCase struct {
	userRepo    repositories.User
	followRepo  repositories.UserFollow
	profileRepo repositories.Profile
}

type FollowUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewFollowUseCase(
	transactionManager psqlhelper.TransactionManager,
	userRepo repositories.User,
	followRepo repositories.UserFollow,
	profileRepo repositories.Profile,
) FollowUseCase {
	useCase := &followUseCase{
		userRepo:    userRepo,
		followRepo:  followRepo,
		profileRepo: profileRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *followUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)
	input, ok := payload.(FollowInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	err := uc.validateInput(ctx, input)
	if err != nil {
		return nil, err
	}
	follow := entities.UserFollow{
		Base: entities.Base{
			CreatedAt: time.Now(),
		},
		FollowerID: input.UserID,
		FollowedID: input.FollowedID,
	}
	if err := uc.followRepo.Upsert(ctx, &follow, []string{"follower_id", "followed_id"}, []string{"deleted_at", "created_at"}); err != nil {
		ctxLogger.Errorf("Failed to create follow: %v", err)
		return nil, err
	}
	return nil, nil
}
func (uc *followUseCase) validateInput(ctx context.Context, input FollowInput) error {
	ctxLogger := logger.NewLogger(ctx)
	//validate UserID
	_, err := uuid.Parse(input.UserID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.UserID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	user, err := uc.userRepo.GetByID(ctx, input.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return err
	}
	if user == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	if user.NeedVerify {
		return xerror.NewError(xerror.AccountNeedToVerify)
	}
	//check followed
	if input.FollowedID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	followed, err := uc.userRepo.GetByID(ctx, input.FollowedID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return err
	}
	if followed == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	//check existed follow
	follow, err := uc.followRepo.GetPaginatedByCondition(ctx, pagination.Input{
		Page:  pagination.DefaultPage,
		Limit: pagination.DefaultLimit,
	}, conditions.UserFollowCondition{
		UserFollow: entities.UserFollow{
			FollowerID: input.UserID,
			FollowedID: input.FollowedID,
		},
	})
	if err != nil {
		ctxLogger.Errorf("Failed to check existed follow: %v", err)
		return xerror.NewError(xerror.InternalServer)
	}
	if follow != nil && follow.Data != nil && len(follow.Data) > 0 {
		return xerror.NewError(xerror.DataExisted)
	}
	// get profile by user id
	profile, err := uc.profileRepo.GetByUserId(ctx, input.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return err
		}
		ctxLogger.Errorf("Failed to get profile by user ID: %v", err)
		return err
	}
	if profile == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	return nil
}
