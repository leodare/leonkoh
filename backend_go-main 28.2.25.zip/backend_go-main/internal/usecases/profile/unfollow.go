package profile

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
)

type unfollowUseCase struct {
	userRepo   repositories.User
	followRepo repositories.UserFollow
}

type UnfollowUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewUnfollowUseCase(
	transactionManager psqlhelper.TransactionManager,
	userRepo repositories.User,
	followRepo repositories.UserFollow,
) UnfollowUseCase {
	useCase := &unfollowUseCase{
		userRepo:   userRepo,
		followRepo: followRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *unfollowUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)
	input, ok := payload.(UnfollowInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	userFollow, err := uc.validateInput(ctx, input)
	if err != nil {
		return nil, err
	}
	if userFollow == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	if err := uc.followRepo.Delete(ctx, userFollow.ID); err != nil {
		ctxLogger.Errorf("Failed to delete follow: %v", err)
		return nil, err
	}
	return nil, nil
}
func (uc *unfollowUseCase) validateInput(ctx context.Context, input UnfollowInput) (*entities.UserFollow, error) {
	ctxLogger := logger.NewLogger(ctx)
	//validate UserID
	_, err := uuid.Parse(input.UserID)
	if err != nil {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	if input.UserID == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	user, err := uc.userRepo.GetByID(ctx, input.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return nil, err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return nil, err
	}
	if user == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	if user.NeedVerify {
		return nil, xerror.NewError(xerror.AccountNeedToVerify)
	}
	//check followed
	if input.FollowedID == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	followed, err := uc.userRepo.GetByID(ctx, input.FollowedID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return nil, err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return nil, err
	}
	if followed == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	//check existed follow
	result, err := uc.followRepo.GetPaginatedByCondition(ctx, pagination.Input{
		Page:  pagination.DefaultPage,
		Limit: pagination.DefaultLimit,
	}, conditions.UserFollowCondition{
		UserFollow: entities.UserFollow{
			FollowerID: input.UserID,
			FollowedID: input.FollowedID,
		},
	})
	if err != nil {
		ctxLogger.Errorf("Failed to check existed follow: %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}
	if result == nil || result.Data == nil || len(result.Data) == 0 {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	return &result.Data[0], nil
}
