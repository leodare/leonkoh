package profile

import (
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"time"
)

type CreateInput struct {
	UserID      string  `json:"user_id" `
	AddressId   *string `json:"address_id"`
	FirstName   string  `json:"first_name"`
	LastName    string  `json:"last_name"`
	Avatar      *string `json:"avatar"`
	Bio         *string `json:"bio"`
	DateOfBirth *string `json:"date_of_birth"`
	Gender      string  `json:"gender"`
}

type CreateOutput struct {
	Id          string     `json:"id"`
	UserID      string     `json:"user_id" `
	AddressID   *string    `json:"address_id"`
	FirstName   string     `json:"first_name"`
	LastName    string     `json:"last_name"`
	Avatar      *string    `json:"avatar"`
	Bio         *string    `json:"bio"`
	DateOfBirth *string    `json:"date_of_birth"`
	Gender      string     `json:"gender"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   *time.Time `json:"updated_at"`
}
type UpdateInput struct {
	UserID      string  `json:"user_id" `
	AddressId   *string `json:"address_id"`
	FirstName   string  `json:"first_name"`
	LastName    string  `json:"last_name"`
	Avatar      *string `json:"avatar"`
	Bio         *string `json:"bio"`
	DateOfBirth *string `json:"date_of_birth"`
	Gender      string  `json:"gender"`
}

type UpdateOutput struct {
	Id          string     `json:"id"`
	UserID      string     `json:"user_id" `
	AddressID   *string    `json:"address_id"`
	FirstName   string     `json:"first_name"`
	LastName    string     `json:"last_name"`
	Avatar      *string    `json:"avatar"`
	Bio         *string    `json:"bio"`
	DateOfBirth *string    `json:"date_of_birth"`
	Gender      string     `json:"gender"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   *time.Time `json:"updated_at"`
}
type GetDetailInput struct {
	UserId string `json:"user_id"`
}
type GetDetailOutput struct {
	Id          string     `json:"id"`
	UserID      string     `json:"user_id" `
	AddressID   *string    `json:"address_id"`
	FirstName   string     `json:"first_name"`
	LastName    string     `json:"last_name"`
	Avatar      *string    `json:"avatar"`
	Bio         *string    `json:"bio"`
	DateOfBirth *string    `json:"date_of_birth"`
	Gender      string     `json:"gender"`
	CreatedAt   time.Time  `json:"created_at"`
	UpdatedAt   *time.Time `json:"updated_at"`
}
type FollowInput struct {
	UserID     string `json:"user_id"`
	FollowedID string `json:"followed_id"`
}
type UnfollowInput struct {
	UserID     string `json:"user_id"`
	FollowedID string `json:"followed_id"`
}
type GetListFollowedInput struct {
	UserID   string `json:"user_id"`
	IsLatest bool   `json:"is_latest"`
	Paging   pagination.Input
}
type GetListFollowedOutput struct {
	ListFollowed []FollowedData
	Meta         pagination.Meta
}
type FollowedData struct {
	Id         string  `json:"id"`
	FollowerID string  `json:"follower_id"`
	FollowedID string  `json:"followed_id"`
	FirstName  string  `json:"first_name"`
	LastName   string  `json:"last_name"`
	Avatar     *string `json:"avatar"`
}
