package profile

import (
	"backend/internal/entities"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
	"errors"
	"github.com/google/uuid"
	"github.com/spf13/viper"
	"gorm.io/gorm"
	"strings"
	"time"
)

type updateUseCase struct {
	reviewStaticRepo repositories.ReviewStatic
	userRepo         repositories.User
	staticRepo       repositories.Static
	profileRepo      repositories.Profile
	addressRepo      repositories.Address
}

type UpdateUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewUpdateUseCase(
	transactionManager psqlhelper.TransactionManager,
	userRepo repositories.User,
	staticRepo repositories.Static,
	profileRepo repositories.Profile,
	addressRepo repositories.Address,
) UpdateUseCase {
	useCase := &updateUseCase{
		profileRepo: profileRepo,
		userRepo:    userRepo,
		staticRepo:  staticRepo,
		addressRepo: addressRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *updateUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)
	input, ok := payload.(UpdateInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	//validate and get profile
	profileOld, err := uc.validateInput(ctx, input)
	if err != nil {
		return nil, err
	}
	if profileOld == nil {
		return nil, xerror.NewError(xerror.InternalServer)
	}
	var bio *string
	if input.Bio != nil {
		bioTemp := strings.TrimSpace(*input.Bio)
		if bioTemp != "" {
			bio = &bioTemp
		}
	}
	firstName := strings.TrimSpace(input.FirstName)
	lastName := strings.TrimSpace(input.LastName)
	//profile := entities.Profile{
	//	UserID:      input.UserID,
	//	FirstName:   input.FirstName,
	//	LastName:    input.LastName,
	//	Avatar:      input.Avatar,
	//	Bio:         bio,
	//	DateOfBirth: input.DateOfBirth,
	//	Gender:      input.Gender,
	//	AddressID:   input.AddressId,
	//}
	profileOld.FirstName = firstName
	profileOld.LastName = lastName
	profileOld.Avatar = input.Avatar
	profileOld.Bio = bio
	profileOld.DateOfBirth = input.DateOfBirth
	profileOld.Gender = input.Gender
	profileOld.AddressID = input.AddressId
	err = uc.profileRepo.Update(ctx, profileOld)
	if err != nil {
		ctxLogger.Errorf("Failed while update profile: %s", err.Error())
		return nil, err
	}
	profileNew, err := uc.profileRepo.GetByID(ctx, profileOld.ID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			ctxLogger.Errorf("Update profile failed profile not found")
			return nil, xerror.NewError(xerror.InternalServer)
		}
		ctxLogger.Errorf("GetByID profileRepo: %v", err)
		return nil, err
	}
	if profileNew == nil {
		ctxLogger.Errorf("Update profile failed profileNew is nil")
		return nil, xerror.NewError(xerror.InternalServer)
	}
	domain := viper.GetString("domain")
	var avatar *string
	if profileNew.Avatar != nil {
		avatar = utils.NewString(domain + "/api/v1/statics/" + *profileNew.Avatar)
	}
	return UpdateOutput{
		Id:          profileNew.ID,
		UserID:      profileNew.UserID,
		FirstName:   profileNew.FirstName,
		LastName:    profileNew.LastName,
		Avatar:      avatar,
		Bio:         profileNew.Bio,
		DateOfBirth: profileNew.DateOfBirth,
		Gender:      profileNew.Gender,
		AddressID:   profileNew.AddressID,
		CreatedAt:   profileNew.CreatedAt,
		UpdatedAt:   profileNew.UpdatedAt,
	}, nil
}
func (uc *updateUseCase) validateInput(ctx context.Context, input UpdateInput) (*entities.Profile, error) {
	ctxLogger := logger.NewLogger(ctx)
	//validate UserID
	_, err := uuid.Parse(input.UserID)
	if err != nil {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	if input.UserID == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	user, err := uc.userRepo.GetByID(ctx, input.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return nil, err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return nil, err
	}
	if user == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	if user.NeedVerify {
		return nil, xerror.NewError(xerror.AccountNeedToVerify)
	}
	//validate and get profile
	profile, err := uc.profileRepo.GetByUserId(ctx, input.UserID)
	if err != nil {
		ctxLogger.Errorf("failed to get profile by user id: %s", err.Error())
		return nil, err
	}
	if profile == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	//FirstName
	if strings.TrimSpace(input.FirstName) == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	//LastName
	if strings.TrimSpace(input.LastName) == "" {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	//Avatar
	if input.Avatar != nil {
		if strings.TrimSpace(*input.Avatar) == "" {
			return nil, xerror.NewError(xerror.DataInvalid)
		}
		static, err := uc.staticRepo.GetByID(ctx, *input.Avatar)
		if err != nil {
			if err.Error() == xerror.CodeDataNotFound {
				return nil, err
			}
			ctxLogger.Errorf("Failed while get static by id: %s", err.Error())
			return nil, err
		}
		if static == nil {
			return nil, xerror.NewError(xerror.CodeDataNotFound)
		}
	}
	//Bio
	//DateOfBirth
	if input.DateOfBirth != nil {
		_, err = time.Parse(time.RFC3339, *input.DateOfBirth)
		if err != nil {
			return nil, xerror.NewError(xerror.DataInvalid)
		}
	}
	//Gender
	if input.Gender != entities.GenderMale && input.Gender != entities.GenderFemale && input.Gender != entities.GenderOther {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	if input.AddressId != nil {
		if strings.TrimSpace(*input.AddressId) == "" {
			return nil, xerror.NewError(xerror.DataInvalid)
		}
		_, err := uc.addressRepo.GetByID(ctx, *input.AddressId)
		if err != nil {
			if err.Error() == xerror.CodeDataNotFound {
				return nil, err
			}
			ctxLogger.Errorf("Failed while get address by id: %s", err.Error())
			return nil, err
		}
	}
	return profile, nil
}
