package cuisine_type

import "backend/internal/infrastructure/persistence/postgres/pagination"

type CreateInput struct {
	Name string `json:"name"`
}

type CreateOutput struct {
	ID string `json:"id"`
}

type GetListInput struct {
	Name   string `form:"name"`
	Paging pagination.Input
}

type GetListOutput struct {
	CuisineTypes []CuisineType `json:"cuisine_types"`
	Meta         pagination.Meta
}

type CuisineType struct {
	ID   string
	Name string
}
