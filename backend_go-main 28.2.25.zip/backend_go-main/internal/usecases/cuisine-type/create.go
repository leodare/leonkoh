package cuisine_type

import (
	"backend/internal/entities"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"regexp"
)

type createUseCase struct {
	cuisineTypeRepo repositories.CuisineType
}

type CreateUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewCreateUseCase(
	transactionManager psqlhelper.TransactionManager,
	cuisineTypeRepo repositories.CuisineType,
) CreateUseCase {
	useCase := &createUseCase{
		cuisineTypeRepo: cuisineTypeRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *createUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)

	input, ok := payload.(CreateInput)
	if !ok {
		ctxLogger.Errorf("Invalid input type")
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	if err := uc.validateInput(input); err != nil {
		ctxLogger.Error(err)
		return nil, err
	}

	cuisineType, err := uc.cuisineTypeRepo.GetByName(ctx, input.Name)
	if err != nil {
		ctxLogger.Error(err)
		return nil, xerror.NewError(xerror.InternalServer)
	}
	if cuisineType != nil {
		return CreateOutput{
			ID: cuisineType.ID,
		}, nil
	}

	id, err := uc.cuisineTypeRepo.Create(ctx, &entities.CuisineType{
		Name: input.Name,
	})
	if err != nil {
		ctxLogger.Error(err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	return CreateOutput{
		ID: *id,
	}, nil
}

func (uc *createUseCase) validateInput(input CreateInput) (err error) {
	if input.Name == "" {
		return xerror.NewError(xerror.DataInvalid)
	}

	if !regexp.MustCompile(`^[a-zA-Z\s]+$`).MatchString(input.Name) {
		return xerror.NewError(xerror.DataInvalid)
	}

	return nil
}
