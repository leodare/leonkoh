package cuisine_type

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	x_error "backend/pkg/x-error"
	"context"
)

type getListUseCase struct {
	cuisineTypeRepo repositories.CuisineType
}

type GetListUseCase interface {
	Execute(ctx context.Context, input GetListInput) (*GetListOutput, error)
}

func NewGetListUseCase(cuisineTypeRepo repositories.CuisineType) GetListUseCase {
	return &getListUseCase{
		cuisineTypeRepo: cuisineTypeRepo,
	}
}

func (uc *getListUseCase) Execute(ctx context.Context, input GetListInput) (*GetListOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	c := conditions.CuisineTypeCondition{
		CuisineType: entities.CuisineType{
			Name: input.Name,
		},
	}
	list, err := uc.cuisineTypeRepo.GetPaginatedByCondition(ctx, input.Paging, c)
	if err != nil {
		ctxLogger.Errorf("GetList failed: %v", err)
		return nil, x_error.NewError(x_error.InternalServer)
	}

	return mapToGetListOutput(list), nil
}

func mapToGetListOutput(data *pagination.Pagination[entities.CuisineType]) *GetListOutput {
	records := make([]CuisineType, 0)
	for _, item := range data.Data {
		records = append(records, CuisineType{
			ID:   item.ID,
			Name: item.Name,
		})
	}
	return &GetListOutput{
		CuisineTypes: records,
		Meta:         data.Meta,
	}
}
