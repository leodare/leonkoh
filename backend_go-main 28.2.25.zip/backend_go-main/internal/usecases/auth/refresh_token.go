package auth

import (
	"backend/internal/repositories"
	"backend/internal/services/auth"
	"backend/pkg/validate"
	xerror "backend/pkg/x-error"
	"context"
)

type RefreshTokenUseCase interface {
	Execute(ctx context.Context, payload RefreshTokenInput) (*LoginOutput, error)
}

type refreshTokenUseCase struct {
	validator   validate.Validator
	authService auth.Service
	userRepo    repositories.User
}

func NewRefreshTokenUseCase(userRepo repositories.User, authService auth.Service) RefreshTokenUseCase {
	validator := validate.GetValidatorInstance()
	return &refreshTokenUseCase{
		validator:   validator,
		authService: authService,
		userRepo:    userRepo,
	}
}

func (uc *refreshTokenUseCase) Execute(ctx context.Context, payload RefreshTokenInput) (*LoginOutput, error) {
	if err := uc.validator.Validate(payload); err != nil {
		return nil, err
	}

	claims, err := uc.authService.ParseToken(ctx, payload.RefreshToken)
	if err != nil {
		return nil, err
	}
	err = uc.authService.CheckValidClaims(ctx, auth.RefreshToken, payload.DeviceId, claims)
	if err != nil {
		return nil, err
	}

	user, err := uc.userRepo.GetByID(ctx, claims.UserID)
	if err != nil {
		return nil, err
	}

	if user == nil {
		return nil, xerror.NewError(xerror.CodeUserNotFound)
	}

	accessToken, refreshToken, err := uc.authService.GenerateToken(ctx, user.ID, payload.DeviceId)
	if err != nil {
		return nil, err
	}

	return &LoginOutput{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		Username:     user.Username,
		Email:        user.Email,
		Phone:        user.Phone,
		NeedVerify:   user.NeedVerify,
	}, nil
}
