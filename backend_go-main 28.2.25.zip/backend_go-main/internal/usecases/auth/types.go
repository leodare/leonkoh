package auth

type LoginInput struct {
	DeviceId string `json:"device_id" validate:"required"`
	Username string `json:"username" validate:"required,x_username"`
	Password string `json:"password" validate:"required,min=8,max=50,x_password"`
}

type LoginOutput struct {
	AccessToken  string  `json:"access_token"`
	RefreshToken string  `json:"refresh_token"`
	Username     string  `json:"username"`
	Email        *string `json:"email"`
	Phone        string  `json:"phone"`
	NeedVerify   bool    `json:"need_verify"`
}

type RegisterInput struct {
	DeviceId string  `json:"device_id" validate:"required"`
	Username string  `json:"username" validate:"required,x_username"`
	Password string  `json:"password" validate:"required,min=8,max=50,x_password"`
	Email    *string `json:"email" validate:"omitempty,x_email"`
	Phone    string  `json:"phone" validate:"omitempty,x_phone_number"`
}

type RegisterOutput struct {
	ID           string  `json:"id"`
	Username     string  `json:"username"`
	Email        *string `json:"email"`
	Phone        string  `json:"phone"`
	NeedVerify   bool    `json:"need_verify"`
	CreatedAt    string  `json:"created_at"`
	UpdatedAt    *string `json:"updated_at"`
	AccessToken  string  `json:"access_token"`
	RefreshToken string  `json:"refresh_token"`
}

type LogoutInput struct {
	// TODO: Define input fields here
}

type LogoutOutput struct {
	// TODO: Define output fields here
}

type RefreshTokenInput struct {
	RefreshToken string `json:"refresh_token" validate:"required"`
	DeviceId     string `json:"device_id" validate:"required"`
}
