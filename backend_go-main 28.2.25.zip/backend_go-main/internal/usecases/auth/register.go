package auth

import (
	"backend/internal/entities"
	conditions2 "backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/repositories"
	"backend/internal/services/auth"
	"backend/internal/services/otp"
	"backend/pkg/logger"
	"backend/pkg/utils"
	"backend/pkg/validate"
	xerror "backend/pkg/x-error"
	"context"
)

type registerUseCase struct {
	userRepo    repositories.User
	validator   validate.Validator
	authService auth.Service
	otpService  otp.Service
}

type RegisterUseCase interface {
	Execute(ctx context.Context, input RegisterInput) (*RegisterOutput, error)
}

func NewRegisterUseCase(
	userRepo repositories.User,
	authService auth.Service,
	otpService otp.Service,
) RegisterUseCase {
	validator := validate.GetValidatorInstance()
	return &registerUseCase{
		userRepo:    userRepo,
		validator:   validator,
		authService: authService,
		otpService:  otpService,
	}
}

func (uc *registerUseCase) Execute(ctx context.Context, input RegisterInput) (*RegisterOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	if err := uc.validator.Validate(input); err != nil {
		return nil, err
	}

	isExist, err := uc.isUserExist(ctx, input.Username, input.Phone, input.Email)
	if err != nil {
		return nil, err
	}
	if isExist {
		return nil, xerror.NewError(xerror.CodeUserAlreadyExists)
	}

	hashPassword := utils.HashAndSalt(input.Password)
	phone := utils.NormalizePhoneNumber(&input.Phone)
	email := uc.normalizeEmail(input.Email)
	newUserId, err := uc.userRepo.Create(ctx, &entities.User{
		Username:   input.Username,
		Password:   hashPassword,
		Email:      email,
		Phone:      *phone,
		NeedVerify: true,
	})
	if err != nil {
		return nil, err
	}

	newUser, err := uc.userRepo.GetByID(ctx, *newUserId)
	if err != nil {
		return nil, err
	}

	accessToken, refreshToken, err := uc.authService.GenerateToken(ctx, newUser.ID, input.DeviceId)
	if err != nil {
		return nil, err
	}

	createdAt := utils.ConvertTimeToISOString(newUser.CreatedAt)

	err = uc.otpService.SendOTP(ctx, newUser.ID, otp.RegisterAction, otp.SMSMethod)
	if err != nil {
		ctxLogger.Errorf("Failed to send OTP: %v", err)
	}

	return &RegisterOutput{
		ID:           newUser.ID,
		Username:     newUser.Username,
		Email:        newUser.Email,
		Phone:        newUser.Phone,
		NeedVerify:   newUser.NeedVerify,
		CreatedAt:    createdAt,
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
	}, nil
}

func (uc *registerUseCase) isUserExist(ctx context.Context, username string, phone string, email *string) (bool, error) {
	conditions := conditions2.NewUserConditions().WithUsername(username).WithOrEqPhone(&phone).WithOrEqEmail(email)
	users, err := uc.userRepo.GetByCondition(
		ctx,
		*conditions,
	)
	if err != nil {
		return false, err
	}

	if users != nil && len(users) > 0 {
		return true, nil
	}

	return false, nil
}

func (uc *registerUseCase) normalizeEmail(email *string) *string {
	if email != nil && *email == "" {
		return nil
	}
	return email
}
