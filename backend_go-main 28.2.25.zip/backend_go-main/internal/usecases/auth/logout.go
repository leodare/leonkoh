package auth

import (
	middleware "backend/internal/middleware/usecase"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
)

type logoutUseCase struct{}

type LogoutUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewLogoutUseCase(transactionManager psqlhelper.TransactionManager) LogoutUseCase {
	useCase := &logoutUseCase{}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *logoutUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)

	input, ok := payload.(LogoutInput)
	if !ok {
		ctxLogger.Errorf("Invalid input type")
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	if err := uc.validateInput(input); err != nil {
		ctxLogger.Errorf("Invalid input: %v", err)
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	// TODO: Implement business logic here

	return nil, nil
}

func (uc *logoutUseCase) validateInput(input LogoutInput) (err error) {
	return nil
}
