package auth

import (
	conditions2 "backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/repositories"
	"backend/internal/services/auth"
	"backend/pkg/utils"
	"backend/pkg/validate"
	xerror "backend/pkg/x-error"
	"context"
)

type loginUseCase struct {
	validator   validate.Validator
	authService auth.Service
	userRepo    repositories.User
}

type LoginUseCase interface {
	Execute(ctx context.Context, input LoginInput) (*LoginOutput, error)
}

func NewLoginUseCase(userRepo repositories.User, authService auth.Service) LoginUseCase {
	validator := validate.GetValidatorInstance()
	return &loginUseCase{
		validator:   validator,
		authService: authService,
		userRepo:    userRepo,
	}
}

func (uc *loginUseCase) Execute(ctx context.Context, input LoginInput) (*LoginOutput, error) {
	if err := uc.validator.Validate(input); err != nil {
		return nil, err
	}

	conditions := conditions2.NewUserConditions().WithUsername(input.Username)
	users, err := uc.userRepo.GetByCondition(
		ctx,
		*conditions,
	)
	if err != nil {
		return nil, err
	}

	if users == nil || len(users) == 0 {
		return nil, xerror.NewError(xerror.CodeInvalidUsernameOrPassword)
	}

	user := users[0]
	valid := utils.ComparePassword(user.Password, input.Password)
	if !valid {
		return nil, xerror.NewError(xerror.CodeInvalidUsernameOrPassword)
	}

	accessToken, refreshToken, err := uc.authService.GenerateToken(ctx, user.ID, input.DeviceId)
	if err != nil {
		return nil, err
	}

	return &LoginOutput{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		Username:     user.Username,
		Email:        user.Email,
		Phone:        user.Phone,
		NeedVerify:   user.NeedVerify,
	}, nil
}
