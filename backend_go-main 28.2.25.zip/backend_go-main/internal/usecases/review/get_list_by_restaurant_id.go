package review

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/repositories"
	"backend/internal/services/review"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
)

type getListByRestaurantIdUseCase struct {
	reviewRepo     repositories.Review
	reviewService  review.Service
	restaurantRepo repositories.Restaurant
}

type GetListByRestaurantIdUseCase interface {
	Execute(ctx context.Context, input GetListByRestaurantIdInput) (*GetListByRestaurantIdOutput, error)
}

func NewGetListByRestaurantIdUseCase(
	reviewService review.Service,
	reviewRepo repositories.Review,
	restaurantRepo repositories.Restaurant,
) GetListByRestaurantIdUseCase {
	return &getListByRestaurantIdUseCase{
		reviewService:  reviewService,
		reviewRepo:     reviewRepo,
		restaurantRepo: restaurantRepo,
	}
}

func (uc *getListByRestaurantIdUseCase) Execute(ctx context.Context, input GetListByRestaurantIdInput) (*GetListByRestaurantIdOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	if err := uc.validateInput(ctx, input); err != nil {
		return nil, err
	}
	reviewCondition := conditions.ReviewCondition{
		Review:  entities.Review{RestaurantID: input.RestaurantID},
		Options: conditions.AdditionalReviewCondition{},
	}
	if input.Latest {
		reviewCondition.Sorting = []conditions.Sorting{{
			Field: "created_at",
			Order: conditions.OrderDESC,
		}}
	} else {
		reviewCondition.Sorting = []conditions.Sorting{{
			Field: "created_at",
			Order: conditions.OrderASC,
		}}
	}
	reviews, err := uc.reviewRepo.GetPaginatedByCondition(ctx, input.Paging, reviewCondition)
	if err != nil {
		ctxLogger.Errorf("Failed to fetch reviews: %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	if reviews == nil || reviews.Data == nil || len(reviews.Data) == 0 {
		return &GetListByRestaurantIdOutput{}, nil
	}

	reviewData := mapReviewEntitiesToReviewsOutput(reviews.Data)

	return &GetListByRestaurantIdOutput{
		Reviews: reviewData,
		Meta:    reviews.Meta,
	}, nil
}

func (uc *getListByRestaurantIdUseCase) validateInput(ctx context.Context, input GetListByRestaurantIdInput) (err error) {
	ctxLogger := logger.NewLogger(ctx)
	if input.RestaurantID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	_, err = uuid.Parse(input.RestaurantID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	restaurant, err := uc.restaurantRepo.GetByID(ctx, input.RestaurantID)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to fetch restaurant: %v", err)
		return err
	}
	if restaurant == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	return nil
}
