package review

import (
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/internal/services/review"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
)

type deleteUseCase struct {
	reviewRepo    repositories.Review
	reviewService review.Service
}

type DeleteUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewDeleteUseCase(
	transactionManager psqlhelper.TransactionManager,
	reviewRepo repositories.Review,
	reviewService review.Service,
) DeleteUseCase {
	useCase := &deleteUseCase{
		reviewRepo:    reviewRepo,
		reviewService: reviewService,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *deleteUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)

	input, ok := payload.(DeleteInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	err := uc.validateInput(input)
	if err != nil {
		ctxLogger.Errorf("Failed to validate input, error: %v", err)
		return nil, err
	}

	reviewInDB, err := uc.reviewRepo.GetByID(ctx, input.ReviewID)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to get review, error: %v", err)
		return nil, err
	}
	if reviewInDB == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	err = uc.reviewRepo.Delete(ctx, input.ReviewID)
	if err != nil {
		ctxLogger.Errorf("Failed to delete review, error: %v", err)
		return nil, err
	}

	err = uc.reviewService.UpdateRestaurantRating(ctx, reviewInDB.RestaurantID)
	if err != nil {
		ctxLogger.Errorf("Failed to update restaurant rating, error: %v", err)
		return nil, err
	}
	return nil, nil
}

func (uc *deleteUseCase) validateInput(input DeleteInput) (err error) {
	if input.ReviewID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	_, err = uuid.Parse(input.ReviewID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	return nil
}
