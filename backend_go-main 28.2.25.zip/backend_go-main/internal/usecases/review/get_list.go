package review

import (
	"backend/internal/repositories"
	"backend/internal/services/review"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
)

type getListUseCase struct {
	reviewRepo    repositories.Review
	reviewService review.Service
}

type GetListUseCase interface {
	Execute(ctx context.Context, input GetListInput) (*GetListOutput, error)
}

func NewGetListUseCase(
	reviewService review.Service,
	reviewRepo repositories.Review,
) GetListUseCase {
	return &getListUseCase{
		reviewService: reviewService,
		reviewRepo:    reviewRepo,
	}
}

func (uc *getListUseCase) Execute(ctx context.Context, input GetListInput) (*GetListOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	if err := uc.validateInput(input); err != nil {
		ctxLogger.Errorf("Invalid input: %v", err)
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	fetchReviewsOuput, err := uc.reviewService.FetchReviews(ctx, review.FetchReviewsInput{
		Paging:       input.Paging,
		RestaurantID: input.RestaurantID,
		Latest:       input.Latest,
	})
	if err != nil {
		ctxLogger.Errorf("Failed to fetch reviews: %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	if fetchReviewsOuput.Data == nil {
		return &GetListOutput{}, nil
	}

	reviews := mapReviewEntitiesToReviewsOutput(fetchReviewsOuput.Data.Data)

	return &GetListOutput{
		Reviews: reviews,
		Meta:    fetchReviewsOuput.Data.Meta,
	}, nil
}

func (uc *getListUseCase) validateInput(input GetListInput) (err error) {
	return nil
}
