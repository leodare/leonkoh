package review

import "backend/internal/infrastructure/persistence/postgres/pagination"

type CreateInput struct {
	Title              string
	Content            string
	RestaurantID       string
	VisitDate          *string
	TasteRating        int
	AromaRating        int
	AtmosphereRating   int
	PresentationRating int
	ServiceRating      int
	StaticIDs          []string
	ExecutorId         string
}

type CreateOutput struct {
	CreatedBy          string   `json:"created_by"`
	Title              string   `json:"title"`
	Content            string   `json:"content"`
	RestaurantID       string   `json:"restaurant_id"`
	VisitDate          *string  `json:"visit_date"`
	OverallRating      float64  `json:"overall_rating"`
	TasteRating        int      `json:"taste_rating"`
	AromaRating        int      `json:"aroma_rating"`
	AtmosphereRating   int      `json:"atmosphere_rating"`
	PresentationRating int      `json:"presentation_rating"`
	ServiceRating      int      `json:"service_rating"`
	StaticIDs          []string `json:"static_i_ds"`
	CreatedAt          string   `json:"created_at"`
}

type UpdateInput struct {
	ID                 string
	Title              string
	Content            string
	RestaurantID       string
	VisitDate          *string
	TasteRating        int
	AromaRating        int
	AtmosphereRating   int
	PresentationRating int
	ServiceRating      int
	StaticIDs          []string
	ExecutorId         string
}
type UpdateOutput struct {
	CreatedBy          string   `json:"created_by"`
	Title              string   `json:"title"`
	Content            string   `json:"content"`
	RestaurantID       string   `json:"restaurant_id"`
	VisitDate          *string  `json:"visit_date"`
	OverallRating      float64  `json:"overall_rating"`
	TasteRating        int      `json:"taste_rating"`
	AromaRating        int      `json:"aroma_rating"`
	AtmosphereRating   int      `json:"atmosphere_rating"`
	PresentationRating int      `json:"presentation_rating"`
	ServiceRating      int      `json:"service_rating"`
	StaticIDs          []string `json:"static_i_ds"`
	CreatedAt          string   `json:"created_at"`
}
type GetListInput struct {
	Paging       pagination.Input
	RestaurantID string
	Latest       bool
}

type GetListByRestaurantIdOutput struct {
	Reviews []Review
	Meta    pagination.Meta
}
type GetListByRestaurantIdInput struct {
	Paging       pagination.Input
	RestaurantID string
	Latest       bool
}

type GetListOutput struct {
	Reviews []Review
	Meta    pagination.Meta
}
type Review struct {
	ID                 string
	Title              string
	Content            string
	RestaurantID       string
	VisitDate          *string
	TasteRating        int
	AromaRating        int
	AtmosphereRating   int
	PresentationRating int
	ServiceRating      int
	StaticIDs          []string
}

type DeleteInput struct {
	ReviewID string
}
type ApproveInput struct {
	ReviewID string
}
