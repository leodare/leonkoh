package review

import (
	"backend/internal/entities"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/internal/services/review"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
	"time"
)

type createUseCase struct {
	reviewRepo       repositories.Review
	restaurantRepo   repositories.Restaurant
	reviewStaticRepo repositories.ReviewStatic
	reviewService    review.Service
	userRepo         repositories.User
	staticRepo       repositories.Static
}

type CreateUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewCreateUseCase(
	reviewService review.Service,
	transactionManager psqlhelper.TransactionManager,
	reviewRepo repositories.Review,
	reviewStaticRepo repositories.ReviewStatic,
	restaurantRepo repositories.Restaurant,
	userRepo repositories.User,
	staticRepo repositories.Static,

) CreateUseCase {
	useCase := &createUseCase{
		reviewService:    reviewService,
		reviewRepo:       reviewRepo,
		reviewStaticRepo: reviewStaticRepo,
		restaurantRepo:   restaurantRepo,
		userRepo:         userRepo,
		staticRepo:       staticRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *createUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)

	input, ok := payload.(CreateInput)
	if !ok {
		ctxLogger.Errorf("Invalid input type")
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	if err := uc.validateInput(ctx, input); err != nil {
		return nil, err
	}

	_, err := uc.restaurantRepo.GetByID(ctx, input.RestaurantID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return nil, xerror.NewError(xerror.CodeDataNotFound)
		}
		ctxLogger.Errorf("Failed to get restaurant: %v", err)
		return nil, err
	}

	overallRating := getOverallRating(input.TasteRating, input.AromaRating, input.AtmosphereRating, input.PresentationRating, input.ServiceRating)

	newReview := &entities.Review{
		CreatedBy:          input.ExecutorId,
		Title:              input.Title,
		Content:            input.Content,
		RestaurantID:       input.RestaurantID,
		VisitDate:          input.VisitDate,
		OverallRating:      overallRating,
		TasteRating:        input.TasteRating,
		AromaRating:        input.AromaRating,
		AtmosphereRating:   input.AtmosphereRating,
		PresentationRating: input.PresentationRating,
		ServiceRating:      input.ServiceRating,
		IsApproved:         false,
	}

	reviewID, err := uc.reviewRepo.Create(ctx, newReview)
	if err != nil {
		ctxLogger.Errorf("Failed to create review: %v", err)
		return nil, err
	}

	if len(input.StaticIDs) > 0 {
		var newReviewStatics []*entities.ReviewStatic
		for _, sID := range input.StaticIDs {
			newReviewStatics = append(newReviewStatics, &entities.ReviewStatic{
				ReviewID: *reviewID,
				StaticID: sID,
			})
		}
		_, err = uc.reviewStaticRepo.CreateMany(ctx, newReviewStatics)
		if err != nil {
			ctxLogger.Errorf("Failed to create review statics: %v", err)
			return nil, err
		}
	}

	newReviewDB, err := uc.reviewRepo.GetByID(ctx, *reviewID)
	if err != nil {
		ctxLogger.Errorf("Failed to get review: %v", err)
		return nil, err
	}
	if newReviewDB == nil {
		return nil, xerror.NewError(xerror.InternalServer)
	}
	statics, err := uc.reviewStaticRepo.GetRecordsByReviewID(ctx, *reviewID)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to get review statics: %v", err)
		return nil, err
	}
	var staticIDs []string
	for _, s := range statics {
		staticIDs = append(staticIDs, s.StaticID)
	}
	err = uc.reviewService.ApproveReview(ctx, input.RestaurantID)
	if err != nil {
		ctxLogger.Errorf("Failed to approve review: %v", err)
		return nil, err
	}
	return CreateOutput{
		CreatedBy:          newReviewDB.CreatedBy,
		Title:              newReviewDB.Title,
		Content:            newReviewDB.Content,
		RestaurantID:       newReviewDB.RestaurantID,
		VisitDate:          newReviewDB.VisitDate,
		OverallRating:      newReviewDB.OverallRating,
		TasteRating:        newReviewDB.TasteRating,
		AromaRating:        newReviewDB.AromaRating,
		AtmosphereRating:   newReviewDB.AtmosphereRating,
		PresentationRating: newReviewDB.PresentationRating,
		ServiceRating:      newReviewDB.ServiceRating,
		StaticIDs:          staticIDs,
		CreatedAt:          newReviewDB.CreatedAt.String(),
	}, nil
}

func (uc *createUseCase) validateInput(ctx context.Context, input CreateInput) (err error) {
	ctxLogger := logger.NewLogger(ctx)
	if input.ExecutorId == "" {
		return xerror.NewError(xerror.CodeUnauthorized)
	}
	user, err := uc.userRepo.GetByID(ctx, input.ExecutorId)
	if err != nil {
		ctxLogger.Errorf("Failed to get user: %v", err)
		return err
	}
	if user == nil {
		return xerror.NewError(xerror.CodeUnauthorized)
	}
	if user.NeedVerify == true {
		return xerror.NewError(xerror.AccountNeedToVerify)
	}
	reviewInD, err := uc.reviewRepo.GetByExecutorIdAndRestaurantId(ctx, input.ExecutorId, input.RestaurantID)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to get review by executor ID: %v", err)
		return err
	}
	if reviewInD != nil {
		return xerror.NewError(xerror.ReviewExisted)
	}
	if input.Title == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.Content == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.RestaurantID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	_, err = uuid.Parse(input.RestaurantID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.VisitDate != nil {
		_, err := time.Parse(time.RFC3339, *input.VisitDate)
		if err != nil {
			return xerror.NewError(xerror.DataInvalid)
		}
	}
	if input.TasteRating < 1 || input.TasteRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.AromaRating < 1 || input.AromaRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.AtmosphereRating < 1 || input.AtmosphereRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.PresentationRating < 1 || input.PresentationRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.ServiceRating < 1 || input.ServiceRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if len(input.StaticIDs) > 0 {
		statics, err := uc.staticRepo.GetByIDs(ctx, input.StaticIDs)
		if err != nil {
			ctxLogger.Errorf("Failed to get statics: %v", err)
			return err
		}
		if len(statics) != len(input.StaticIDs) {
			return xerror.NewError(xerror.DataInvalid)
		}
	}
	return nil
}
