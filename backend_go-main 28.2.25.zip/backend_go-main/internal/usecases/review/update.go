package review

import (
	"backend/internal/entities"
	middleware "backend/internal/middleware/usecase"
	"backend/internal/repositories"
	"backend/internal/services/review"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/google/uuid"
	"time"
)

type updateUseCase struct {
	reviewRepo       repositories.Review
	reviewStaticRepo repositories.ReviewStatic
	restaurantRepo   repositories.Restaurant
	reviewService    review.Service
	staticRepo       repositories.Static
	userRepo         repositories.User
}

type UpdateUseCase interface {
	Execute(ctx context.Context, payload interface{}) (interface{}, error)
}

func NewUpdateUseCase(
	transactionManager psqlhelper.TransactionManager,
	reviewRepo repositories.Review,
	reviewStaticRepo repositories.ReviewStatic,
	restaurantRepo repositories.Restaurant,
	reviewService review.Service,
	staticRepo repositories.Static,
	userRepo repositories.User,
) UpdateUseCase {
	useCase := &updateUseCase{
		reviewRepo:       reviewRepo,
		reviewStaticRepo: reviewStaticRepo,
		restaurantRepo:   restaurantRepo,
		reviewService:    reviewService,
		staticRepo:       staticRepo,
		userRepo:         userRepo,
	}
	return middleware.NewUseCaseWithMiddleware(
		useCase.Execute,
		middleware.TransactionMiddleware(transactionManager),
	)
}

func (uc *updateUseCase) Execute(ctx context.Context, payload interface{}) (interface{}, error) {
	ctxLogger := logger.NewLogger(ctx)

	input, ok := payload.(UpdateInput)
	if !ok {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	if err := uc.validateInput(ctx, input); err != nil {
		return nil, err
	}
	oldReview, err := uc.reviewRepo.GetByID(ctx, input.ID)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to get review by ID: %v", err)
		return nil, err
	}
	if oldReview == nil {
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}
	if oldReview.RestaurantID != input.RestaurantID {
		return nil, xerror.NewError(xerror.DataInvalid)
	}
	if oldReview.CreatedBy != input.ExecutorId {
		return nil, xerror.NewError(xerror.Forbidden)
	}
	overallRating := getOverallRating(input.TasteRating, input.AromaRating, input.AtmosphereRating, input.PresentationRating, input.ServiceRating)
	oldReview.CreatedBy = input.ExecutorId
	oldReview.Title = input.Title
	oldReview.Content = input.Content
	oldReview.RestaurantID = input.RestaurantID
	oldReview.VisitDate = input.VisitDate
	oldReview.OverallRating = overallRating
	oldReview.TasteRating = input.TasteRating
	oldReview.AromaRating = input.AromaRating
	oldReview.AtmosphereRating = input.AtmosphereRating
	oldReview.PresentationRating = input.PresentationRating
	oldReview.ServiceRating = input.ServiceRating
	if err := uc.reviewRepo.Update(ctx, oldReview); err != nil {
		ctxLogger.Errorf("Failed to update review by ID %s, error: %v", input.ID, err)
		return nil, err
	}
	//delete statics review by review id
	if err := uc.reviewStaticRepo.DeleteByReviewID(ctx, input.ID); err != nil {
		ctxLogger.Errorf("Failed to delete review static by review id: %v", err)
		return nil, err
	}
	//create new statics review by review id
	reviewId := oldReview.ID
	if len(input.StaticIDs) > 0 {
		var newReviewStatics []*entities.ReviewStatic
		for _, sID := range input.StaticIDs {
			newReviewStatics = append(newReviewStatics, &entities.ReviewStatic{
				ReviewID: reviewId,
				StaticID: sID,
			})
		}
		_, err = uc.reviewStaticRepo.CreateMany(ctx, newReviewStatics)
		if err != nil {
			ctxLogger.Errorf("Failed to create review statics: %v", err)
			return nil, err
		}
	}

	newReviewDB, err := uc.reviewRepo.GetByID(ctx, reviewId)
	if err != nil {
		ctxLogger.Errorf("Failed to get review: %v", err)
		return nil, err
	}
	if newReviewDB == nil {
		return nil, xerror.NewError(xerror.InternalServer)
	}
	statics, err := uc.reviewStaticRepo.GetRecordsByReviewID(ctx, reviewId)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to get review statics: %v", err)
		return nil, err
	}
	var staticIDs []string
	for _, s := range statics {
		staticIDs = append(staticIDs, s.StaticID)
	}
	err = uc.reviewService.ApproveReview(ctx, input.RestaurantID)
	if err != nil {
		ctxLogger.Errorf("Failed to approve review: %v", err)
		return nil, err
	}
	return UpdateOutput{
		CreatedBy:          newReviewDB.CreatedBy,
		Title:              newReviewDB.Title,
		Content:            newReviewDB.Content,
		RestaurantID:       newReviewDB.RestaurantID,
		VisitDate:          newReviewDB.VisitDate,
		OverallRating:      newReviewDB.OverallRating,
		TasteRating:        newReviewDB.TasteRating,
		AromaRating:        newReviewDB.AromaRating,
		AtmosphereRating:   newReviewDB.AtmosphereRating,
		PresentationRating: newReviewDB.PresentationRating,
		ServiceRating:      newReviewDB.ServiceRating,
		StaticIDs:          staticIDs,
		CreatedAt:          newReviewDB.CreatedAt.String(),
	}, nil
}

func (uc *updateUseCase) validateInput(ctx context.Context, input UpdateInput) (err error) {
	ctxLogger := logger.NewLogger(ctx)
	if input.ID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	_, err = uuid.Parse(input.ID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.ExecutorId == "" {
		return xerror.NewError(xerror.CodeUnauthorized)
	}
	_, err = uuid.Parse(input.ExecutorId)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	user, err := uc.userRepo.GetByID(ctx, input.ExecutorId)
	if err != nil {
		ctxLogger.Errorf("Failed to get user: %v", err)
		return err
	}
	if user == nil {
		return xerror.NewError(xerror.CodeUnauthorized)
	}
	if user.NeedVerify == true {
		return xerror.NewError(xerror.AccountNeedToVerify)
	}
	if input.Title == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.Content == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.RestaurantID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	_, err = uuid.Parse(input.RestaurantID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	restaurant, err := uc.restaurantRepo.GetByID(ctx, input.RestaurantID)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to get restaurant: %v", err)
		return err
	}
	if restaurant == nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.VisitDate != nil {
		_, err := time.Parse(time.RFC3339, *input.VisitDate)
		if err != nil {
			return xerror.NewError(xerror.DataInvalid)
		}
	}
	if input.TasteRating < 1 || input.TasteRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.AromaRating < 1 || input.AromaRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.AtmosphereRating < 1 || input.AtmosphereRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.PresentationRating < 1 || input.PresentationRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.ServiceRating < 1 || input.ServiceRating > 10 {
		return xerror.NewError(xerror.DataInvalid)
	}
	if len(input.StaticIDs) > 0 {
		statics, err := uc.staticRepo.GetByIDs(ctx, input.StaticIDs)
		if err != nil {
			ctxLogger.Errorf("Failed to get statics: %v", err)
			return err
		}
		if len(statics) != len(input.StaticIDs) {
			return xerror.NewError(xerror.DataInvalid)
		}
	}
	return nil
}
