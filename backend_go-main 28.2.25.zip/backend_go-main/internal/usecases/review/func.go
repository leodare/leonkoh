package review

import (
	"backend/internal/entities"
	"backend/pkg/utils"
)

func getOverallRating(taste, aroma, atmosphere, presentation, service int) float64 {
	overallRating := (float64(taste) + float64(aroma) + float64(atmosphere) + float64(presentation) + float64(service)) / 5
	return utils.Round(overallRating, 2)
}
func mapReviewEntitiesToReviewsOutput(reviews []entities.Review) []Review {
	var result []Review

	for _, r := range reviews {
		var staticIds []string
		for _, s := range r.ReviewStatics {
			staticIds = append(staticIds, s.StaticID)
		}
		result = append(result, Review{
			ID:                 r.ID,
			Title:              r.Title,
			Content:            r.Content,
			RestaurantID:       r.RestaurantID,
			VisitDate:          r.VisitDate,
			TasteRating:        r.TasteRating,
			AromaRating:        r.AromaRating,
			AtmosphereRating:   r.AtmosphereRating,
			PresentationRating: r.PresentationRating,
			ServiceRating:      r.ServiceRating,
			StaticIDs:          staticIds,
		})
	}

	return result
}
