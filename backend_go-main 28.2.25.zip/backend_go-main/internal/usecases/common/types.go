package common

type AdminUnitType struct {
	Name        string `json:"name"`
	Description string `json:"description"`
}

type AdminUnit struct {
	Name       string        `json:"name"`
	Type       AdminUnitType `json:"type"`
	Parent     *AdminUnit    `json:"parent"`
	Code       *string       `json:"code"`
	PostalCode *string       `json:"postal_code"`
}

type Address struct {
	ID         string    `json:"id"`
	AdminUnit  AdminUnit `json:"admin_unit"`
	Address1   *string   `json:"address_1"`
	Address2   *string   `json:"address_2"`
	PostalCode *string   `json:"postal_code"`
	Latitude   *float64  `json:"latitude"`
	Longitude  *float64  `json:"longitude"`
}

type Static struct {
	ID       string  `json:"id"`
	URL      string  `json:"url"`
	FileSize int64   `json:"file_size"`
	FileType string  `json:"file_type"`
	Metadata *string `json:"metadata"`
	Alt      *string `json:"alt"`
}
