package common

import "backend/internal/entities"

func MappingAddressEntityToAddress(address entities.Address) *Address {
	return &Address{
		AdminUnit:  MappingAdminUnitEntityToAdminUnit(address.AdminUnit),
		Address1:   address.Address1,
		Address2:   address.Address2,
		PostalCode: address.PostalCode,
		Latitude:   address.Latitude,
		Longitude:  address.Longitude,
	}
}

func MappingAdminUnitEntityToAdminUnit(adminUnit entities.AdminUnit) AdminUnit {
	adminUnitDto := AdminUnit{
		Name: adminUnit.Name,
		Type: AdminUnitType{
			Name:        adminUnit.Type.Name,
			Description: adminUnit.Type.Description,
		},
		Parent:     nil,
		Code:       adminUnit.Code,
		PostalCode: adminUnit.PostalCode,
	}
	if adminUnit.Parent != nil {
		parent := MappingAdminUnitEntityToAdminUnit(*adminUnit.Parent)
		adminUnitDto.Parent = &parent
	}
	return adminUnitDto
}

func MappingStaticEntityToStatic(static entities.Static) Static {
	return Static{
		ID:       static.ID,
		URL:      static.URL,
		FileSize: static.FileSize,
		FileType: static.FileType,
		Metadata: static.Metadata,
		Alt:      static.Alt,
	}
}
