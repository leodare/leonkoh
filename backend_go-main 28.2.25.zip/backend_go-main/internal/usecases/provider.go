package usecases

import (
	"backend/internal/usecases/address"
	"backend/internal/usecases/auth"
	"backend/internal/usecases/category"
	"backend/internal/usecases/cuisine-type"
	"backend/internal/usecases/demo"
	"backend/internal/usecases/profile"
	"backend/internal/usecases/restaurant"
	"backend/internal/usecases/review"
	"backend/internal/usecases/static"
	"backend/internal/usecases/user"
	"github.com/google/wire"
)

var UseCaseProviders = wire.NewSet(
	review.NewDeleteUseCase,
	review.NewGetListUseCase,
	review.NewUpdateUseCase,
	review.NewCreateUseCase,
	restaurant.NewCreateRestaurantUseCase,
	restaurant.NewGetRestaurantByIDUseCase,
	restaurant.NewUpdateRestaurantUseCase,
	restaurant.NewDeleteRestaurantUseCase,
	cuisine_type.NewGetListUseCase,
	cuisine_type.NewCreateUseCase,
	user.NewResendOTPUseCase,
	user.NewVerifyAccountUseCase,
	user.NewChangePasswordUseCase,
	auth.NewRegisterUseCase,
	auth.NewLogoutUseCase,
	auth.NewLoginUseCase,
	auth.NewRefreshTokenUseCase,
	restaurant.NewGetListUseCase,
	demo.NewSumABUseCase,
	static.NewUploadImagesUseCase,
	static.NewGetImageUseCase,
	static.NewUploadFilesUseCase,
	static.NewGetFileUseCase,
	review.NewGetListByRestaurantIdUseCase,
	review.NewApproveUseCase,
	address.NewSearchAddressUseCase,
	profile.NewCreateUseCase,
	profile.NewUpdateUseCase,
	profile.NewGetDetailUseCase,
	profile.NewFollowUseCase,
	profile.NewUnfollowUseCase,
	profile.NewGetListFollowedUseCase,
	category.NewCreateUseCase,
	category.NewUpdateUseCase,
	category.NewDeleteUseCase,
	category.NewGetListUseCase,
)
