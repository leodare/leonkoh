package user

import (
	"backend/internal/repositories"
	"backend/internal/services/otp"
	"backend/pkg/validate"
	xerror "backend/pkg/x-error"
	"context"
)

type verifyAccountUseCase struct {
	validator  validate.Validator
	otpService otp.Service
	userRepo   repositories.User
}

type VerifyAccountUseCase interface {
	Execute(ctx context.Context, payload VerifyAccountInput) error
}

func NewVerifyAccountUseCase(otpService otp.Service, userRepo repositories.User) VerifyAccountUseCase {
	validator := validate.GetValidatorInstance()
	return &verifyAccountUseCase{
		validator:  validator,
		otpService: otpService,
		userRepo:   userRepo,
	}
}

func (uc *verifyAccountUseCase) Execute(ctx context.Context, payload VerifyAccountInput) error {
	if err := uc.validator.Validate(payload); err != nil {
		return err
	}

	err := uc.otpService.VerifyOTP(ctx, payload.UserId, payload.OTP, otp.RegisterAction)
	if err != nil {
		return err
	}

	user, err := uc.userRepo.GetByID(ctx, payload.UserId)
	if err != nil {
		return err
	}
	if user == nil {
		return xerror.NewError(xerror.CodeUserNotFound)
	}

	err = uc.userRepo.SetNeedVerify(ctx, user.ID, false)
	if err != nil {
		return err
	}

	return nil
}
