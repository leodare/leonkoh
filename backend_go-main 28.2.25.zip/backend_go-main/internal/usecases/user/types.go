package user

import "backend/internal/services/otp"

type VerifyAccountInput struct {
	UserId string `json:"user_id" validate:"required,uuid"`
	OTP    string `json:"otp" validate:"required,min=6,max=6"`
}

type ResendOTPInput struct {
	UserId string     `json:"user_id" validate:"required,uuid"`
	Method otp.Method `json:"method" validate:"required"`
	Action otp.Action `json:"action" validate:"required"`
}

type ChangePasswordInput struct {
	UserID      string `json:"user_id" `
	OldPassword string `json:"old_password" validate:"required,max=50,x_password"`
	NewPassword string `json:"new_password" validate:"required,min=8,max=50,x_password"`
}

type ChangePasswordOutput struct{}
