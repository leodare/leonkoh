package user

import (
	"backend/internal/services/otp"
	"backend/pkg/validate"
	"context"
)

type resendOTPUseCase struct {
	validator  validate.Validator
	otpService otp.Service
}

type ResendOTPUseCase interface {
	Execute(ctx context.Context, payload ResendOTPInput) error
}

func NewResendOTPUseCase(otpService otp.Service) ResendOTPUseCase {
	validator := validate.GetValidatorInstance()
	return &resendOTPUseCase{
		validator:  validator,
		otpService: otpService,
	}
}

func (uc *resendOTPUseCase) Execute(ctx context.Context, payload ResendOTPInput) error {
	if err := uc.validator.Validate(payload); err != nil {
		return err
	}

	err := uc.otpService.SendOTP(ctx, payload.UserId, payload.Action, payload.Method)
	if err != nil {
		return err
	}

	return nil
}
