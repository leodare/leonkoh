package user

import (
	"backend/internal/repositories"
	"backend/pkg/logger"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
)

type ChangePasswordUseCase interface {
	Execute(ctx context.Context, payload ChangePasswordInput) (*ChangePasswordOutput, error)
}

type changePasswordUseCase struct {
	userRepo repositories.User
}

func NewChangePasswordUseCase(userRepo repositories.User) ChangePasswordUseCase {
	return &changePasswordUseCase{
		userRepo: userRepo,
	}
}

func (uc *changePasswordUseCase) Execute(ctx context.Context, payload ChangePasswordInput) (*ChangePasswordOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	user, err := uc.userRepo.GetByID(ctx, payload.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return nil, err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return nil, err
	}

	if user == nil {
		ctxLogger.Errorf("Failed while get user by id: %s", xerror.CodeDataNotFound)
		return nil, xerror.NewError(xerror.CodeDataNotFound)
	}

	valid := utils.ComparePassword(user.Password, payload.OldPassword)
	if !valid {
		return nil, xerror.NewError(xerror.CodeInvalidUsernameOrPassword)
	}

	hashPassword := utils.HashAndSalt(payload.NewPassword)
	user.Password = hashPassword
	err = uc.userRepo.Update(ctx, user)
	if err != nil {
		ctxLogger.Errorf("Failed while update user: %s", err.Error())
		return nil, err
	}

	return nil, nil
}
