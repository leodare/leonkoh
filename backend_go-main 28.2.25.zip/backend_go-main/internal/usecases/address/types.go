package address

import (
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/usecases/common"
)

type SearchAddressInput struct {
	Keyword string   `json:"keyword"`
	Lat     *float64 `json:"lat"`
	Lng     *float64 `json:"lng"`
	Radius  *int64   `json:"radius"`
	Paging  pagination.Input
}

type SearchAddressOutput struct {
	Addresses  ListAddressOutput   `json:"addresses"`
	AdminUnits ListAdminUnitOutput `json:"admin_units"`
}

type ListAddressOutput struct {
	Addresses []common.Address `json:"addresses"`
	Meta      pagination.Meta
}

type ListAdminUnitOutput struct {
	AdminUnits []common.AdminUnit `json:"admin_units"`
	Meta       pagination.Meta
}
