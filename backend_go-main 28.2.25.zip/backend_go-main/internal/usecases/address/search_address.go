package address

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/internal/services/search"
	"backend/internal/usecases/common"
	"backend/pkg/utils"
	"context"
	"fmt"
)

type SearchAddressUseCase interface {
	Execute(ctx context.Context, input SearchAddressInput) (*SearchAddressOutput, error)
}

type searchAddressUseCase struct {
	addressRepo   repositories.Address
	adminUnitRepo repositories.AdminUnit
	searchService search.Service
}

func NewSearchAddressUseCase(addressRepo repositories.Address, adminUnitRepo repositories.AdminUnit, searchService search.Service) SearchAddressUseCase {
	return &searchAddressUseCase{
		addressRepo:   addressRepo,
		adminUnitRepo: adminUnitRepo,
		searchService: searchService,
	}
}

func (uc *searchAddressUseCase) Execute(ctx context.Context, input SearchAddressInput) (*SearchAddressOutput, error) {
	addresses, err := uc.searchAddress(ctx, input)
	if err != nil {
		return nil, err
	}
	adminUnits, err := uc.searchAdminUnit(ctx, input)
	if err != nil {
		return nil, err
	}
	return &SearchAddressOutput{
		Addresses:  *addresses,
		AdminUnits: *adminUnits,
	}, nil
}

func (uc *searchAddressUseCase) searchAddress(ctx context.Context, input SearchAddressInput) (*ListAddressOutput, error) {
	var filter *string
	if input.Lat != nil && input.Lng != nil {
		// Default radius is 1000m
		radius := int64(1000)
		if input.Radius != nil {
			radius = *input.Radius
		}
		filter = utils.NewStringPtr(fmt.Sprintf(`"filter": "_geoRadius(%.6f, %.6f, %d)"`, *input.Lat, *input.Lng, radius))
	}
	addressSearchingResult, err := uc.searchService.Search(ctx, search.SearchInput{
		Query:     input.Keyword,
		IndexName: search.IndexNameAddress,
		Page:      input.Paging.Page,
		Limit:     input.Paging.Limit,
		Filter:    filter,
	})
	if err != nil {
		return nil, err
	}
	addresses := make([]common.Address, 0)
	for _, result := range addressSearchingResult.Results {
		address := common.Address{}
		if err := utils.MappingInterface(result, &address); err != nil {
			return nil, err
		}
		adminUnits, err := uc.adminUnitRepo.GetHierarchyByAddressId(ctx, address.ID)
		if err != nil {
			return nil, err
		}
		adminUnit := adminUnits[0]
		currentLevel := &adminUnit
		for index := 1; index < len(adminUnits); index++ {
			currentLevel.Parent = &adminUnits[index]
			currentLevel = currentLevel.Parent
		}
		addressAdminUnit := common.AdminUnit{}
		if err := utils.MappingInterface(adminUnit, &addressAdminUnit); err != nil {
			return nil, err
		}
		address.AdminUnit = addressAdminUnit
		addresses = append(addresses, address)
	}
	return &ListAddressOutput{
		Addresses: addresses,
		Meta: pagination.Meta{
			ItemsPerPage: addressSearchingResult.HitsPerPage,
			TotalItems:   addressSearchingResult.TotalHits,
			CurrentPage:  addressSearchingResult.Page,
			TotalPages:   addressSearchingResult.TotalPages,
		},
	}, nil
}

func (uc *searchAddressUseCase) searchAdminUnit(ctx context.Context, input SearchAddressInput) (*ListAdminUnitOutput, error) {
	adminUnitSearchingResult, err := uc.searchService.Search(ctx, search.SearchInput{
		Query:     input.Keyword,
		IndexName: search.IndexNameAdminUnit,
		Page:      input.Paging.Page,
		Limit:     input.Paging.Limit,
	})
	if err != nil {
		return nil, err
	}
	addresses := make([]common.AdminUnit, 0)
	for _, result := range adminUnitSearchingResult.Results {
		address := common.AdminUnit{}
		adminUnit := entities.AdminUnit{}
		if err := utils.MappingInterface(result, &adminUnit); err != nil {
			return nil, err
		}
		adminUnits, err := uc.adminUnitRepo.GetHierarchy(ctx, adminUnit.ID)
		if err != nil {
			return nil, err
		}
		adminUnit = adminUnits[0]
		currentLevel := &adminUnit
		for index := 1; index < len(adminUnits); index++ {
			currentLevel.Parent = &adminUnits[index]
			currentLevel = currentLevel.Parent
		}
		addressAdminUnit := &common.AdminUnit{}
		if err := utils.MappingInterface(adminUnit, &addressAdminUnit); err != nil {
			return nil, err
		}
		address.Parent = addressAdminUnit
		addresses = append(addresses, address)
	}
	return &ListAdminUnitOutput{
		AdminUnits: addresses,
		Meta: pagination.Meta{
			ItemsPerPage: adminUnitSearchingResult.HitsPerPage,
			TotalItems:   adminUnitSearchingResult.TotalHits,
			CurrentPage:  adminUnitSearchingResult.Page,
			TotalPages:   adminUnitSearchingResult.TotalPages,
		},
	}, nil
}
