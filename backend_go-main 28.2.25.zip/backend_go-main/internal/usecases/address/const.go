package address

const (
	AdminUnitTypeCountry      = "a71366ea-80bc-4581-b16f-d8804955304f"
	AdminUnitTypeRegion       = "8c81ee24-1a4e-421b-b999-254f9f3837dc"
	AdminUnitTypeState        = "990fe317-0de8-488e-a1a9-a249ce251331"
	AdminUnitTypeProvince     = "f0eb580c-9bed-4ae0-979e-fed70ac6ad99"
	AdminUnitTypeTerritory    = "06e98f06-931f-41eb-97fe-e9994d642c20"
	AdminUnitTypeDepartment   = "2d792c3e-7ca3-4345-832e-cfb0e38ea261"
	AdminUnitTypeDivision     = "f36da35a-c517-488f-b79a-72e4bf4ac731"
	AdminUnitTypeCounty       = "512ab232-adaa-43da-b661-29b409288d30"
	AdminUnitTypeDistrict     = "e5090a8d-f08a-4073-89c6-39efb44b75a6"
	AdminUnitTypeMunicipality = "f88705ae-9a13-4cfb-84c5-3cb97d88638f"
	AdminUnitTypeCity         = "71aa9e14-9a2f-4624-a825-b3af1bb6fdc3"
	AdminUnitTypeTown         = "56e5dce0-fffb-4760-8500-beb6bbcd471a"
	AdminUnitTypeCommune      = "a0ed4adc-75d0-40dd-96ce-43dca92f09ad"
	AdminUnitTypeWard         = "cf1d2299-9338-4171-9bc2-5df8cdd32792"
	AdminUnitTypeSubdistrict  = "784a0bcc-8ef0-4eda-84c8-53ea49cd4ad1"
	AdminUnitTypeVillage      = "ee782642-de73-43a9-b9d8-263820e89839"
	AdminUnitTypeHamlet       = "596a6b42-6121-4717-a590-b0e5668029ec"
	AdminUnitTypeNeighborhood = "1062c8cc-e7ee-4c6c-be86-9db58254d535"
)
