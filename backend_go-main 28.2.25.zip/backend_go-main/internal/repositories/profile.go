package repositories

import (
	"backend/internal/entities"
	"context"
)

type Profile interface {
	Base[entities.Profile]
	GetByUserId(ctx context.Context, userId string) (*entities.Profile, error)
	GetByUserIds(ctx context.Context, userIds []string) ([]entities.Profile, error)
}
