package repositories

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"context"
)

type UserFollow interface {
	Base[entities.UserFollow]
	GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.UserFollowCondition) (*pagination.Pagination[entities.UserFollow], error)
}
