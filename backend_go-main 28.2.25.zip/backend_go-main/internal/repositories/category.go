package repositories

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"context"
)

type Category interface {
	Base[entities.Category]
	GetByName(ctx context.Context, name string) (*entities.Category, error)
	GetList(ctx context.Context, paging pagination.Input) (*pagination.Pagination[entities.Category], error)
}
