package repositories

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"context"
)

type Review interface {
	Base[entities.Review]
	GetByRestaurantID(ctx context.Context, restaurantID string) ([]entities.Review, error)
	GetByExecutorIdAndRestaurantId(ctx context.Context, executorId string, restaurantId string) (*entities.Review, error)
	GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.ReviewCondition) (*pagination.Pagination[entities.Review], error)
}
