package repositories

import (
	"backend/internal/entities"
	"context"
)

type Address interface {
	Base[entities.Address]
	GetAll(ctx context.Context) ([]entities.Address, error)
	GetBatch(ctx context.Context, offset, limit int) ([]entities.Address, error)
}
