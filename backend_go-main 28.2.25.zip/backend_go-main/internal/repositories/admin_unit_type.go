package repositories

import "backend/internal/entities"

type AdminUnitType interface {
	Base[entities.AdminUnitType]
}
