package repositories

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"context"
)

type Restaurant interface {
	Base[entities.Restaurant]
	GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.RestaurantCondition) (*pagination.Pagination[entities.Restaurant], error)
	UpdateOverallRating(ctx context.Context, restaurantID string, rating float64) error
	GetWithOtherById(ctx context.Context, restaurantID string) (*entities.Restaurant, error)
	GetBatch(ctx context.Context, offset, limit int, preloads ...string) ([]entities.Restaurant, error)
}
