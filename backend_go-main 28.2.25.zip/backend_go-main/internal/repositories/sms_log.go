package repositories

import (
	"backend/internal/entities"
)

type SmsLog interface {
	Base[entities.SMSLog]
}
