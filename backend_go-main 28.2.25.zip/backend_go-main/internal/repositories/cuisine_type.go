package repositories

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"context"
)

type CuisineType interface {
	Base[entities.CuisineType]
	GetByName(ctx context.Context, name string) (*entities.CuisineType, error)
	GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.CuisineTypeCondition) (*pagination.Pagination[entities.CuisineType], error)
}
