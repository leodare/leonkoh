package repositories

import (
	"backend/internal/entities"
	"context"
)

type RestaurantAddress interface {
	Base[entities.RestaurantAddress]
	DeleteByRestaurantID(ctx context.Context, restaurantID string) error
}
