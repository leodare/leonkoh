package repositories

import "backend/internal/entities"

type RestaurantEmployee interface {
	Base[entities.RestaurantEmployee]
}
