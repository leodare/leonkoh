package repositories

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"context"
)

type SmsTemplate interface {
	Base[entities.SMSTemplate]
	GetByCondition(ctx context.Context, conditions conditions.SMSTemplateConditions) ([]entities.SMSTemplate, error)
}
