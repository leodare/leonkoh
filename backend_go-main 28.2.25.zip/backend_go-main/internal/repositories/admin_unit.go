package repositories

import (
	"backend/internal/entities"
	"context"
)

type AdminUnit interface {
	Base[entities.AdminUnit]
	GetAll(ctx context.Context) ([]entities.AdminUnit, error)
	GetBatch(ctx context.Context, offset, limit int) ([]entities.AdminUnit, error)
	GetHierarchy(ctx context.Context, id string) ([]entities.AdminUnit, error)
	GetHierarchyByAddressId(ctx context.Context, addressId string) ([]entities.AdminUnit, error)
}
