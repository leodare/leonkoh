package repositories

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"context"
)

type User interface {
	Base[entities.User]
	GetByConditionWithPaging(ctx context.Context, input pagination.Input, condition conditions.UserConditions) (*pagination.Pagination[entities.User], error)
	GetByCondition(ctx context.Context, condition conditions.UserConditions) ([]*entities.User, error)
	SetNeedVerify(ctx context.Context, userId string, needVerify bool) error
}
