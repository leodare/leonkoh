package repositories

import (
	"backend/internal/entities"
	"context"
)

type ReviewStatic interface {
	Base[entities.ReviewStatic]
	GetRecordsByReviewID(ctx context.Context, reviewID string) ([]entities.ReviewStatic, error)
	DeleteByReviewID(ctx context.Context, reviewID string) error
}
