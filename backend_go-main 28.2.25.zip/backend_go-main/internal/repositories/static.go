package repositories

import (
	"backend/internal/entities"
	"context"
)

type Static interface {
	Base[entities.Static]
	GetImageByUrl(ctx context.Context, url string) (*entities.Static, error)
}
