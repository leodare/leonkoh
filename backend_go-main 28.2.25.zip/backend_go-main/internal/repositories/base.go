package repositories

import (
	"context"
	"gorm.io/gorm"
)

type Base[T any] interface {
	GetDb(ctx context.Context) *gorm.DB
	Create(ctx context.Context, entity *T) (*string, error)
	CreateMany(ctx context.Context, entities []*T) ([]string, error)
	Update(ctx context.Context, entity *T) error
	UpdateMany(ctx context.Context, ids []string, entity T) error
	GetByID(ctx context.Context, id string) (*T, error)
	GetByIDs(ctx context.Context, id []string) ([]T, error)
	Delete(ctx context.Context, id string) error
	DeleteMany(ctx context.Context, id []string) error
	Upsert(ctx context.Context, entity *T, conflictColumns []string, updateColumns []string) error
}
