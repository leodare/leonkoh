package repositories

import (
	"backend/internal/entities"
)

type LogRestaurantView interface {
	Base[entities.LogRestaurantView]
}
