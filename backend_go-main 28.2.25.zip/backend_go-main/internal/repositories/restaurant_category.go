package repositories

import (
	"backend/internal/entities"
	"context"
)

type RestaurantCategory interface {
	Base[entities.RestaurantCategory]
	DeleteByRestaurantID(ctx context.Context, restaurantID string) error
}
