package search

import "time"

type Geolocation struct {
	Lat float64 `json:"lat"`
	Lng float64 `json:"lng"`
}
type SearchInput struct {
	Query     string  `json:"query"`
	IndexName string  `json:"collection"`
	Page      int     `json:"page"`
	Limit     int     `json:"limit"`
	Filter    *string `json:"filter"`
}

type SearchOutput struct {
	Results     []interface{} `json:"results"`
	HitsPerPage int           `json:"hitsPerPage"`
	Page        int           `json:"page"`
	TotalPages  int           `json:"totalPages"`
	TotalHits   int64         `json:"totalHits"`
}

type AddressDocument struct {
	ID          string       `json:"id"`
	UserID      *string      `json:"user_id"`
	AdminUnitID string       `json:"admin_unit_id"`
	Address1    *string      `json:"address_1"`
	Address2    *string      `json:"address_2"`
	PostalCode  *string      `json:"postal_code"`
	Latitude    *float64     `json:"latitude"`
	Longitude   *float64     `json:"longitude"`
	Geo         *Geolocation `json:"_geo"`
	CreatedAt   time.Time    `json:"created_at"`
	UpdatedAt   *time.Time   `json:"updated_at"`
	DeletedAt   *time.Time   `json:"deleted_at"`
}

type AdminUnitDocument struct {
	ID         string     `json:"id"`
	Name       string     `json:"name"`
	TypeID     string     `json:"type_id"`
	ParentID   *string    `json:"parent_id"`
	Code       *string    `json:"code"`
	PostalCode *string    `json:"postal_code"`
	CreatedAt  time.Time  `json:"created_at"`
	UpdatedAt  *time.Time `json:"updated_at"`
	DeletedAt  *time.Time `json:"deleted_at"`
}

type RestaurantDocument struct {
	ID               string       `json:"id"`
	Name             string       `json:"name"`
	UnitNumber       *string      `json:"unit_number"`
	Area             *string      `json:"area"`
	Phone            *string      `json:"phone"`
	OpeningTime      *string      `json:"opening_time"`
	ClosingTime      *string      `json:"closing_time"`
	OverallRating    *float64     `json:"overall_rating"`
	PriceFrom        *float64     `json:"price_from"`
	PriceTo          *float64     `json:"price_to"`
	Website          *string      `json:"website"`
	Email            *string      `json:"email"`
	CuisineTypeIds   []string     `json:"cuisine_types"`
	CuisineTypeNames []string     `json:"cuisine_type_names"`
	Addresses        []string     `json:"addresses"`
	Geo              *Geolocation `json:"_geo"`
	CategoryIDs      []string     `json:"category_ids"`
	CategoryNames    []string     `json:"category_names"`
}
