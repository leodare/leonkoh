package search

type SearchingCollection string

const (
	Address    SearchingCollection = "address"
	Restaurant SearchingCollection = "restaurant"
)

const (
	IndexNameAddress    = "address"
	IndexNameAdminUnit  = "adminUnit"
	IndexNameRestaurant = "restaurant"
)
