package search

import (
	searchEngine "backend/internal/infrastructure/searching/interface"
	"backend/internal/repositories"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"fmt"
	"time"
)

type Service interface {
	Search(ctx context.Context, input SearchInput) (*SearchOutput, error)
	ReIndexCollection(ctx context.Context, collection SearchingCollection) error
}

type service struct {
	searchEngine   searchEngine.SearchEngine
	addressRepo    repositories.Address
	adminUnitRepo  repositories.AdminUnit
	restaurantRepo repositories.Restaurant
}

func NewService(
	searchEngine searchEngine.SearchEngine,
	addressRepo repositories.Address,
	adminUnitRepo repositories.AdminUnit,
	restaurantRepo repositories.Restaurant,
) Service {
	return &service{
		searchEngine:   searchEngine,
		addressRepo:    addressRepo,
		adminUnitRepo:  adminUnitRepo,
		restaurantRepo: restaurantRepo,
	}
}

func (s *service) Search(ctx context.Context, input SearchInput) (*SearchOutput, error) {
	payload := searchEngine.SearchInput{
		Query:      input.Query,
		Collection: input.IndexName,
		Page:       input.Page,
		Limit:      input.Limit,
		Filter:     input.Filter,
	}
	result, err := s.searchEngine.Search(ctx, payload)
	if err != nil {
		return nil, err
	}
	return &SearchOutput{
		Results:     result.Results,
		HitsPerPage: result.HitsPerPage,
		Page:        result.Page,
		TotalPages:  result.TotalPages,
		TotalHits:   int64(result.TotalHits),
	}, nil
}

func (s *service) ReIndexCollection(ctx context.Context, collection SearchingCollection) error {
	ctxLogger := logger.NewLogger(ctx)
	switch collection {
	case Address:
		err := s.ReIndexAddress(ctx)
		if err != nil {
			ctxLogger.Errorf("ReIndexAddress failed: %v", err)
			return err
		}
	case Restaurant:
		err := s.ReIndexRestaurant(ctx)
		if err != nil {
			ctxLogger.Errorf("ReIndexRestaurant failed: %v", err)
			return err
		}
	default:
		return xerror.NewError(xerror.IndexNotFound)
	}
	return nil
}

//#region Index Address

func (s *service) ReIndexAddress(ctx context.Context) error {
	ctxLogger := logger.NewLogger(ctx)

	// Batch size
	const batchSize = 1000

	// Process addresses in batches
	err := s.processAddressInBatches(ctx, batchSize)
	if err != nil {
		ctxLogger.Errorf("ReIndexAddress failed for addresses: %v", err)
		return err
	}

	// Process admin units in batches
	err = s.processAdminUnitInBatches(ctx, batchSize)
	if err != nil {
		ctxLogger.Errorf("ReIndexAddress failed for admin units: %v", err)
		return err
	}

	return nil
}

func (s *service) processAddressInBatches(ctx context.Context, batchSize int) error {
	offset := 0
	for {
		// Fetch batch of data
		records, err := s.addressRepo.GetBatch(ctx, offset, batchSize)
		if err != nil {
			return fmt.Errorf("fetchBatch failed: %w", err)
		}

		// Break if no more records
		if len(records) == 0 {
			break
		}
		addressDocuments := make([]AddressDocument, len(records))
		for i, record := range records {
			var location *Geolocation
			if record.Latitude != nil && record.Longitude != nil {
				location = &Geolocation{
					Lat: *record.Latitude,
					Lng: *record.Longitude,
				}
			}
			var deletedAt *time.Time
			if record.DeletedAt != nil {
				deletedAt = &record.DeletedAt.Time
			}
			addressDocuments[i] = AddressDocument{
				ID:          record.ID,
				UserID:      record.UserID,
				AdminUnitID: record.AdminUnitID,
				Address1:    record.Address1,
				Address2:    record.Address2,
				PostalCode:  record.PostalCode,
				Latitude:    record.Latitude,
				Longitude:   record.Longitude,
				Geo:         location,
				CreatedAt:   record.CreatedAt,
				UpdatedAt:   record.UpdatedAt,
				DeletedAt:   deletedAt,
			}
		}

		// Prepare input for indexing
		interfaceSlice := make([]interface{}, len(records))
		for i, record := range addressDocuments {
			interfaceSlice[i] = record
		}
		input := searchEngine.IndexDocumentInput{
			Documents:  interfaceSlice,
			Collection: IndexNameAddress,
		}

		// Index batch
		err = s.searchEngine.IndexDocument(ctx, input)
		if err != nil {
			return fmt.Errorf("IndexDocument failed: %w", err)
		}

		// Move offset forward
		offset += len(records)
	}

	return nil
}
func (s *service) processAdminUnitInBatches(ctx context.Context, batchSize int) error {
	offset := 0
	for {
		// Fetch batch of data
		records, err := s.adminUnitRepo.GetBatch(ctx, offset, batchSize)
		if err != nil {
			return fmt.Errorf("fetchBatch failed: %w", err)
		}

		// Break if no more records
		if len(records) == 0 {
			break
		}
		adminUnitDocuments := make([]AdminUnitDocument, len(records))
		for i, record := range records {
			var deletedAt *time.Time
			if record.DeletedAt != nil {
				deletedAt = &record.DeletedAt.Time
			}
			adminUnitDocuments[i] = AdminUnitDocument{
				ID:         record.ID,
				Name:       record.Name,
				TypeID:     record.TypeID,
				ParentID:   record.ParentID,
				Code:       record.Code,
				PostalCode: record.PostalCode,
				CreatedAt:  record.CreatedAt,
				UpdatedAt:  record.UpdatedAt,
				DeletedAt:  deletedAt,
			}
		}

		// Prepare input for indexing
		interfaceSlice := make([]interface{}, len(records))
		for i, record := range adminUnitDocuments {
			interfaceSlice[i] = record
		}
		input := searchEngine.IndexDocumentInput{
			Documents:  interfaceSlice,
			Collection: IndexNameAdminUnit,
		}

		// Index batch
		err = s.searchEngine.IndexDocument(ctx, input)
		if err != nil {
			return fmt.Errorf("IndexDocument failed: %w", err)
		}

		// Move offset forward
		offset += len(records)
	}

	return nil
}

//#endregion

//#region Index Address

func (s *service) ReIndexRestaurant(ctx context.Context) error {
	ctxLogger := logger.NewLogger(ctx)

	// Batch size
	const batchSize = 1000

	// Process restaurants in batches
	err := s.processRestaurantInBatches(ctx, batchSize)
	if err != nil {
		ctxLogger.Errorf("ReIndexRestaurant failed: %v", err)
		return err
	}

	return nil
}

func (s *service) processRestaurantInBatches(ctx context.Context, batchSize int) error {
	offset := 0
	for {
		// Fetch batch of data
		records, err := s.restaurantRepo.GetBatch(
			ctx,
			offset,
			batchSize,
			"RestaurantCuisineTypes",
			"RestaurantCuisineTypes.CuisineType",
			"RestaurantAddresses",
			"RestaurantAddresses.Address",
			"RestaurantCategories",
			"RestaurantCategories.Category",
		)
		if err != nil {
			return fmt.Errorf("fetchBatch failed: %w", err)
		}

		// Break if no more records
		if len(records) == 0 {
			break
		}
		restaurantDocuments := make([]RestaurantDocument, len(records))
		for i, record := range records {
			cuisineTypeIds := make([]string, 0)
			cuisineTypeNames := make([]string, 0)
			categoryIDs := make([]string, 0)
			categoryNames := make([]string, 0)
			addresses := make([]string, 0)
			var geo *Geolocation
			for _, address := range record.RestaurantAddresses {
				addressStr := ""
				if address.Address.Address1 != nil {
					addressStr += *address.Address.Address1
				}
				if address.Address.Address2 != nil {
					addressStr += ", " + *address.Address.Address2
				}
				addresses = append(addresses, addressStr)
				if address.Address.Latitude != nil && address.Address.Longitude != nil && geo == nil {
					geo = &Geolocation{
						Lat: *address.Address.Latitude,
						Lng: *address.Address.Longitude,
					}
				}
			}
			for _, cuisineType := range record.RestaurantCuisineTypes {
				cuisineTypeIds = append(cuisineTypeIds, cuisineType.CuisineTypeID)
				cuisineTypeNames = append(cuisineTypeNames, cuisineType.CuisineType.Name)
			}
			for _, category := range record.RestaurantCategories {
				categoryIDs = append(categoryIDs, category.CategoryID)
				categoryNames = append(categoryNames, *category.Category.Name)
			}
			restaurantDocuments[i] = RestaurantDocument{
				ID:               record.ID,
				Name:             record.Name,
				UnitNumber:       record.UnitNumber,
				Area:             record.Area,
				Phone:            record.Phone,
				OpeningTime:      record.OpeningTime,
				ClosingTime:      record.ClosingTime,
				OverallRating:    record.OverallRating,
				PriceFrom:        record.PriceFrom,
				PriceTo:          record.PriceTo,
				Website:          record.Website,
				Email:            record.Email,
				CuisineTypeIds:   cuisineTypeIds,
				CuisineTypeNames: cuisineTypeNames,
				Addresses:        addresses,
				Geo:              geo,
				CategoryIDs:      categoryIDs,
				CategoryNames:    categoryNames,
			}
		}

		// Prepare input for indexing
		interfaceSlice := make([]interface{}, len(records))
		for i, record := range restaurantDocuments {
			interfaceSlice[i] = record
		}
		input := searchEngine.IndexDocumentInput{
			Documents:  interfaceSlice,
			Collection: IndexNameRestaurant,
		}

		// Index batch
		err = s.searchEngine.IndexDocument(ctx, input)
		if err != nil {
			return fmt.Errorf("IndexDocument failed: %w", err)
		}

		// Move offset forward
		offset += len(records)
	}

	return nil
}

//#endregion
