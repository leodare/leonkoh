package category

import (
	"backend/internal/repositories"
	"backend/pkg/logger"
	x_error "backend/pkg/x-error"
	"context"
)

type service struct {
	categoryRepo repositories.Category
}

type Service interface {
	GetListCategories(ctx context.Context, input GetListCategoriesInput) (*GetListCategoriesOutput, error)
}

func NewService(
	categoryRepo repositories.Category,
) Service {
	return &service{
		categoryRepo: categoryRepo,
	}
}

func (s service) GetListCategories(ctx context.Context, input GetListCategoriesInput) (*GetListCategoriesOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	data, err := s.categoryRepo.GetList(ctx, input.Paging)
	if err != nil {
		ctxLogger.Error("get categories failed", err)
		return nil, x_error.NewError(x_error.InternalServer)
	}

	return &GetListCategoriesOutput{
		Data: data,
	}, nil
}
