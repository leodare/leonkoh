package category

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/pagination"
)

type GetListCategoriesInput struct {
	Paging pagination.Input
}

type GetListCategoriesOutput struct {
	Data *pagination.Pagination[entities.Category]
}
