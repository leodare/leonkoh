package otp

import (
	"backend/internal/entities"
	caching "backend/internal/infrastructure/caching/interface"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	sms "backend/internal/infrastructure/sms/interface"
	"backend/internal/repositories"
	"backend/pkg/constants"
	"backend/pkg/logger"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"bytes"
	"context"
	"fmt"
	"github.com/spf13/viper"
	"math/rand"
	"text/template"
)

type Service interface {
	SendOTP(ctx context.Context, userId string, action Action, methods ...Method) error
	VerifyOTP(ctx context.Context, userId, otp string, action Action) error
}

type service struct {
	userRepo        repositories.User
	smsLogRepo      repositories.SmsLog
	smsTemplateRepo repositories.SmsTemplate
	smsService      sms.Service
	cacheManager    caching.Provider
}

func NewOTPService(
	userRepo repositories.User,
	smsLogRepo repositories.SmsLog,
	smsTemplateRepo repositories.SmsTemplate,
	smsService sms.Service,
	cacheManager caching.Provider,
) Service {
	return &service{
		userRepo:        userRepo,
		smsLogRepo:      smsLogRepo,
		smsTemplateRepo: smsTemplateRepo,
		smsService:      smsService,
		cacheManager:    cacheManager,
	}
}

func (s *service) SendOTP(ctx context.Context, userId string, action Action, methods ...Method) error {
	user, err := s.getUser(ctx, userId)
	if err != nil {
		return err
	}
	otpCode := s.generateOTP(ctx)
	err = s.setOTPToCache(ctx, userId, otpCode, action)
	if err != nil {
		return err
	}
	for _, method := range methods {
		switch method {
		case SMSMethod:
			err := s.sendSMS(ctx, user.Phone, otpCode)
			if err != nil {
				return err
			}
		case EmailMethod:
			if user.Email == nil || *user.Email == "" {
				return xerror.NewError(xerror.EmailRequired)
			}
			err := s.sendEmail(ctx, *user.Email, "OTP", otpCode)
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func (s *service) sendSMS(ctx context.Context, phoneNumber, otpCode string) error {
	ctxLogger := logger.NewLogger(ctx)
	content, err := s.getSMSContent(ctx, otpCode)
	if err != nil {
		return err
	}
	smsLog := &entities.SMSLog{
		Phone:   phoneNumber,
		Content: content,
	}
	err = s.smsService.Send(ctx, phoneNumber, content)
	if err != nil {
		smsLog.Status = entities.SMSStatusFailed
		smsLog.Message = utils.NewString(err.Error())
	} else {
		smsLog.Status = entities.SMSStatusSent
	}
	_, rErr := s.smsLogRepo.Create(ctx, smsLog)
	if rErr != nil {
		ctxLogger.Errorf("Failed to log SMS: %v", err)
		return rErr
	}
	return err
}

func (s *service) sendEmail(ctx context.Context, email, subject, content string) error {
	return nil
}

func (s *service) VerifyOTP(ctx context.Context, userId, otp string, action Action) error {
	ctxLogger := logger.NewLogger(ctx)
	cacheKey := s.generateCacheKey(userId, string(action))
	cachedOTP, err := s.cacheManager.GetState(ctx, CachePrefixOTP, cacheKey)
	if err != nil {
		ctxLogger.Errorf("Failed to get OTP from cache: %v", err)
		return err
	}
	if cachedOTP == "" {
		return xerror.NewError(xerror.OTPNotMatch)
	}
	if cachedOTP != otp {
		return xerror.NewError(xerror.OTPNotMatch)
	}

	// Remove OTP from cache after verifying
	err = s.cacheManager.RemoveState(ctx, CachePrefixOTP, cacheKey)
	if err != nil {
		ctxLogger.Errorf("Failed to remove OTP from cache: %v", err)
		return err
	}

	return nil
}

func (s *service) getUser(ctx context.Context, userId string) (*entities.User, error) {
	user, err := s.userRepo.GetByID(ctx, userId)
	if err != nil {
		return nil, err
	}
	return user, nil
}

func (s *service) generateCacheKey(userId, action string) string {
	return fmt.Sprintf("%s_%s", userId, action)
}

func (s *service) setOTPToCache(ctx context.Context, userId, otp string, action Action) error {
	ctxLogger := logger.NewLogger(ctx)
	key := s.generateCacheKey(userId, string(action))
	otpExpiredTime := viper.GetInt(fmt.Sprintf("otp.%sExpiredTime", action))
	err := s.cacheManager.SetState(ctx, CachePrefixOTP, key, otp, otpExpiredTime)
	if err != nil {
		ctxLogger.Errorf("Failed to set OTP to cache: %v", err)
		return err
	}
	return nil
}

func (s *service) getSMSContent(ctx context.Context, otp string) (string, error) {
	condition := conditions.NewSMSTemplateConditions().WithCode(string(constants.OTPTemplate))
	smsTemplates, err := s.smsTemplateRepo.GetByCondition(ctx, *condition)
	if err != nil {
		return "", err
	}
	if len(smsTemplates) == 0 {
		return "", xerror.NewError(xerror.SMSTemplateNotFound)
	}
	templateText := smsTemplates[0].Template
	tmpl, err := template.New("sms").Parse(templateText)
	if err != nil {
		return "", err
	}
	var messageBody bytes.Buffer
	data := struct {
		OTP string
	}{
		OTP: otp,
	}
	err = tmpl.Execute(&messageBody, data)
	if err != nil {
		fmt.Println("Lỗi khi thực thi template:", err)
		return "", err
	}
	return messageBody.String(), nil
}

func (s *service) generateOTP(ctx context.Context) string {
	// Generate a random 6-digit number
	otp := rand.Intn(1000000) // Range: 0-999999

	// Format it as a 6-digit string with leading zeros if necessary
	otpString := fmt.Sprintf("%06d", otp)

	// Optionally, log or return errors if needed
	return otpString
}
