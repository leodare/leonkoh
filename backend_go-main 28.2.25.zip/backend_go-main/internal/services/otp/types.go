package otp

type Action string

type Method string
