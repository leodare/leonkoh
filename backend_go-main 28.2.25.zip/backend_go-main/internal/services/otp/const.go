package otp

const (
	// RegisterAction is the action for register
	RegisterAction Action = "register"
	// ForgotPasswordAction is the action for forgot password
	ForgotPasswordAction Action = "forgotPassword"
)
const (
	// SMSMethod is the method for sending OTP via SMS
	SMSMethod Method = "sms"
	// EmailMethod is the method for sending OTP via Email
	EmailMethod Method = "email"
)

const (
	CachePrefixOTP                         = "otp_"
	CachePrefixLockCreateLogRestaurantView = "lock_create_log_restaurant_view"
)
