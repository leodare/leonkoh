package restaurant

type GenKeyLockCreateLogRestaurantView struct {
	RestaurantID string
	UserID       string
}
type CreateLogRestaurantViewInput struct {
	RestaurantID string
	UserID       string
}
