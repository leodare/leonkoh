package restaurant

import (
	"backend/internal/entities"
	caching "backend/internal/infrastructure/caching/interface"
	"backend/internal/repositories"
	"backend/internal/services/otp"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"fmt"
	"github.com/google/uuid"
	"github.com/spf13/viper"
)

type service struct {
	userRepo          repositories.User
	restaurantRepo    repositories.Restaurant
	logRestaurantRepo repositories.LogRestaurantView
	cacheManager      caching.Provider
}

type Service interface {
	CreateLogRestaurantView(ctx context.Context, input CreateLogRestaurantViewInput) error
	GenKeyLockCreateLogRestaurantView(restaurantID, userID string) string
}

func NewService(
	userRepo repositories.User,
	restaurantRepo repositories.Restaurant,
	logRestaurantRepo repositories.LogRestaurantView,
	cacheManager caching.Provider,

) Service {
	return &service{
		userRepo:          userRepo,
		restaurantRepo:    restaurantRepo,
		logRestaurantRepo: logRestaurantRepo,
		cacheManager:      cacheManager,
	}
}
func (s service) CreateLogRestaurantView(ctx context.Context, input CreateLogRestaurantViewInput) error {
	ctxLogger := logger.NewLogger(ctx)
	err := s.validateCreateLogRestaurantView(ctx, input)
	if err != nil {
		return err
	}
	resultCache, err := s.cacheManager.GetState(ctx, otp.CachePrefixLockCreateLogRestaurantView, s.GenKeyLockCreateLogRestaurantView(input.RestaurantID, input.UserID))
	if err != nil {
		ctxLogger.Errorf("GetState error: %s", err.Error())
	}
	if resultCache != "false" && resultCache != "" {
		return nil
	}
	timeExpire := viper.GetInt("cacheExpire.lockCreateLogRestaurantView")
	if timeExpire == 0 {
		timeExpire = 1
	}
	_, err = s.logRestaurantRepo.Create(ctx, &entities.LogRestaurantView{
		RestaurantID: input.RestaurantID,
		UserID:       input.UserID,
	})
	if err != nil {
		ctxLogger.Errorf("Failed while create log restaurant view: %s", err.Error())
		return err
	}
	err = s.cacheManager.SetState(ctx, otp.CachePrefixLockCreateLogRestaurantView, s.GenKeyLockCreateLogRestaurantView(input.RestaurantID, input.UserID), "true", timeExpire)
	if err != nil {
		ctxLogger.Errorf("SetState error: %s", err.Error())
		return err
	}
	return nil
}
func (s service) validateCreateLogRestaurantView(ctx context.Context, input CreateLogRestaurantViewInput) error {
	ctxLogger := logger.NewLogger(ctx)
	//validate userId
	_, err := uuid.Parse(input.UserID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.UserID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	user, err := s.userRepo.GetByID(ctx, input.UserID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return err
		}
		ctxLogger.Errorf("Failed while get user by id: %s", err.Error())
		return err
	}
	if user == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	if user.NeedVerify {
		return xerror.NewError(xerror.AccountNeedToVerify)
	}
	//validate restaurantId
	_, err = uuid.Parse(input.RestaurantID)
	if err != nil {
		return xerror.NewError(xerror.DataInvalid)
	}
	if input.RestaurantID == "" {
		return xerror.NewError(xerror.DataInvalid)
	}
	restaurant, err := s.restaurantRepo.GetByID(ctx, input.RestaurantID)
	if err != nil {
		if err.Error() == xerror.CodeDataNotFound {
			return err
		}
		ctxLogger.Errorf("Failed while get restaurant by id: %s", err.Error())
		return err
	}
	if restaurant == nil {
		return xerror.NewError(xerror.CodeDataNotFound)
	}
	return nil
}
func (s service) GenKeyLockCreateLogRestaurantView(restaurantID, userID string) string {
	return fmt.Sprintf("restaurantID:%s|userID:%s", restaurantID, userID)
}
