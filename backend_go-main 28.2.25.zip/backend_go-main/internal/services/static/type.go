package static

import "io"

type UploadImageInput struct {
	ContentType string
	ImageData   string
}
type GetImageOutput struct {
	Image io.ReadCloser
	Type  string
}

type UploadFileInput struct {
	Prefix        string
	File          io.Reader
	ContentType   string
	FileExtension string
}

type GetFileOutput struct {
	File io.ReadCloser
	Type string
}

type UploadImageOutput struct {
	ID string
}

type UploadFileOutput struct {
	ID string
}
