package static

import (
	"backend/internal/entities"
	storage "backend/internal/infrastructure/storage/interface"
	"backend/internal/repositories"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
	"fmt"
	"github.com/dotrongnhan/sharing-package/pkg/logger"
	"time"
)

type Service interface {
	UploadImage(ctx context.Context, payload UploadImageInput) (*UploadImageOutput, error)
	GetImage(ctx context.Context, imageId string) (*GetImageOutput, error)
	UploadFile(ctx context.Context, payload UploadFileInput) (*UploadFileOutput, error)
	GetFile(ctx context.Context, id string) (*GetFileOutput, error)
}

type service struct {
	storageProvider storage.Service
	staticRepo      repositories.Static
}

func NewService(
	storageProvider storage.Service,
	staticRepo repositories.Static,
) Service {
	return &service{
		storageProvider: storageProvider,
		staticRepo:      staticRepo,
	}
}

func (s *service) UploadImage(ctx context.Context, payload UploadImageInput) (*UploadImageOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	if payload.ImageData == "" || payload.ContentType == "" {
		ctxLogger.Errorf("image data or content type is empty")
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	imageUrl, err := s.storageProvider.GetImageURl(payload.ImageData, payload.ContentType)
	if err != nil {
		ctxLogger.Errorf("Failed to get image url, err : %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	// check if image already exists
	static, err := s.staticRepo.GetImageByUrl(ctx, imageUrl)
	if err != nil && err.Error() != xerror.CodeDataNotFound {
		ctxLogger.Errorf("Failed to get image by url, err : %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	if static != nil {
		return &UploadImageOutput{
			ID: static.ID,
		}, nil
	}

	url, err := s.storageProvider.UploadImage(payload.ContentType, payload.ImageData)
	if err != nil {
		ctxLogger.Errorf("Failed to upload image to storage, err : %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	static = &entities.Static{
		Base: entities.Base{
			ID:        utils.GenerateUniqueKey(),
			CreatedAt: time.Now(),
		},
		URL:      url,
		FileSize: int64(len(payload.ImageData)),
		FileType: payload.ContentType,
	}

	_, err = s.staticRepo.Create(ctx, static)
	if err != nil {

		return nil, xerror.NewError(xerror.InternalServer)
	}

	return &UploadImageOutput{
		ID: static.ID,
	}, nil
}

func (s *service) GetImage(ctx context.Context, imageId string) (*GetImageOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	if imageId == "" {
		ctxLogger.Errorf("imageToken is empty")
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	staticRecord, err := s.staticRepo.GetByID(ctx, imageId)
	if err != nil {
		ctxLogger.Errorf("Failed to get image by token, err : %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	if staticRecord == nil {
		ctxLogger.Errorf("Image not found")
		return nil, xerror.NewError(xerror.ImageNotFound)
	}

	imageData, err := s.storageProvider.GetImage(staticRecord.URL)
	if err != nil {
		ctxLogger.Errorf("Failed to get image from storage, err : %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	return &GetImageOutput{
		Image: imageData,
		Type:  staticRecord.FileType,
	}, nil
}

func (s *service) UploadFile(ctx context.Context, payload UploadFileInput) (*UploadFileOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	id := utils.GenerateUniqueKey()
	fileExtension := payload.FileExtension
	if fileExtension == "" {
		fileE, err := utils.GetFileExtensionFromContentType(payload.ContentType)
		if err != nil {
			ctxLogger.Errorf("Failed to get file extension from content type, err: %v", err)
			return nil, xerror.NewError(xerror.InvalidFileType)
		}
		fileExtension = fileE
	}

	uniqueFileName := fmt.Sprintf("%s/%s.%s", payload.Prefix, id, fileExtension)

	url, err := s.storageProvider.UploadFileFromStream(payload.File, uniqueFileName, payload.ContentType)
	if err != nil {
		ctxLogger.Errorf("Failed to upload file to storage, err: %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	fileRecord := &entities.Static{
		Base: entities.Base{
			ID:        id,
			CreatedAt: time.Now(),
		},
		URL:      url,
		FileType: payload.ContentType,
	}

	_, err = s.staticRepo.Create(ctx, fileRecord)
	if err != nil {
		ctxLogger.Errorf("Failed to save file metadata, err: %v", err)
		return nil, xerror.NewError(xerror.InternalServer)
	}

	return &UploadFileOutput{
		ID: id,
	}, nil
}

func (s *service) GetFile(ctx context.Context, id string) (*GetFileOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	if id == "" {
		ctxLogger.Errorf("token is empty")
		return nil, xerror.NewError(xerror.DataInvalid)
	}

	staticRecord, err := s.staticRepo.GetByID(ctx, id)
	if err != nil {
		ctxLogger.Errorf("Failed to get file by token, err: %v", err)
		return nil, err
	}

	if staticRecord == nil {
		ctxLogger.Errorf("File not found")
		return nil, xerror.NewError(xerror.FileNotFound)
	}

	// Use the URL from the metadata to retrieve the file from storage
	fileData, err := s.storageProvider.GetFileReader(staticRecord.URL)
	if err != nil {
		ctxLogger.Errorf("Failed to get file from storage, err: %v", err)
		return nil, err
	}

	return &GetFileOutput{
		File: fileData,
		Type: staticRecord.FileType,
	}, nil
}
