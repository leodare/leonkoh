package services

import (
	"backend/internal/services/auth"
	"backend/internal/services/category"
	"backend/internal/services/otp"
	"backend/internal/services/restaurant"
	"backend/internal/services/review"
	"backend/internal/services/search"
	"backend/internal/services/static"
	"github.com/google/wire"
)

var Provider = wire.NewSet(
	auth.NewAuthService,
	static.NewService,
	otp.NewOTPService,
	review.NewService,
	search.NewService,
	restaurant.NewService,
	category.NewService,
)
