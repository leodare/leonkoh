package review

import (
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"backend/pkg/utils"
	x_error "backend/pkg/x-error"
	"context"
)

type service struct {
	reviewRepo     repositories.Review
	restaurantRepo repositories.Restaurant
}

type Service interface {
	UpdateRestaurantRating(ctx context.Context, restaurantID string) error
	FetchReviews(ctx context.Context, input FetchReviewsInput) (*FetchReviewsOutput, error)
	ApproveReview(ctx context.Context, reviewId string) error
}

func NewService(
	reviewRepo repositories.Review,
	restaurantRepo repositories.Restaurant,
) Service {
	return &service{
		reviewRepo:     reviewRepo,
		restaurantRepo: restaurantRepo,
	}
}

func (s *service) FetchReviews(ctx context.Context, input FetchReviewsInput) (*FetchReviewsOutput, error) {
	ctxLogger := logger.NewLogger(ctx)

	condition := buildFetchReviewsConditions(input)
	data, err := s.reviewRepo.GetPaginatedByCondition(ctx, input.Paging, condition)
	if err != nil {
		ctxLogger.Error("get reviews failed", err)
		return nil, x_error.NewError(x_error.InternalServer)
	}

	return &FetchReviewsOutput{
		Data: data,
	}, nil
}

func buildFetchReviewsConditions(input FetchReviewsInput) conditions.ReviewCondition {
	condition := conditions.ReviewCondition{}

	if input.RestaurantID != "" {
		condition.Review.RestaurantID = input.RestaurantID
	}

	if input.Latest {
		condition.Sorting = []conditions.Sorting{{
			Field: "created_at",
			Order: conditions.OrderDESC,
		}}
	}

	return condition
}

func (s *service) UpdateRestaurantRating(ctx context.Context, restaurantID string) error {
	ctxLogger := logger.NewLogger(ctx)
	if restaurantID == "" {
		ctxLogger.Error("restaurantID is required")
		return x_error.NewError(x_error.DataInvalid)
	}

	reviews, err := s.reviewRepo.GetByRestaurantID(ctx, restaurantID)
	if err != nil {
		ctxLogger.Error("get reviews by restaurant ID failed", err)
		return err
	}

	if len(reviews) == 0 {
		err = s.restaurantRepo.UpdateOverallRating(ctx, restaurantID, 0)
		if err != nil {
			ctxLogger.Error("update restaurant rating failed", err)
			return err
		}
		return nil
	}

	var totalRating float64
	for _, review := range reviews {
		totalRating += review.OverallRating
	}

	averageRating := totalRating / float64(len(reviews))

	err = s.restaurantRepo.UpdateOverallRating(ctx, restaurantID, utils.Round(averageRating, 2))
	if err != nil {
		ctxLogger.Error("update restaurant rating failed", err)
		return err
	}
	return nil
}
func (s *service) ApproveReview(ctx context.Context, reviewId string) error {
	ctxLogger := logger.NewLogger(ctx)
	if reviewId == "" {
		return x_error.NewError(x_error.DataInvalid)
	}
	// get review by id
	review, err := s.reviewRepo.GetByID(ctx, reviewId)
	if err != nil && err.Error() != x_error.CodeDataNotFound {
		ctxLogger.Error("get reviews by restaurant ID failed", err)
		return err
	}
	if review == nil {
		return x_error.NewError(x_error.CodeDataNotFound)
	}
	// get restaurant by review.restaurant_id
	restaurant, err := s.restaurantRepo.GetByID(ctx, review.RestaurantID)
	if err != nil && err.Error() != x_error.CodeDataNotFound {
		ctxLogger.Error("get restaurant by id failed", err)
		return err
	}
	if restaurant == nil {
		return x_error.NewError(x_error.CodeDataNotFound)
	}
	// update review status
	review.IsApproved = true
	err = s.reviewRepo.Update(ctx, review)
	if err != nil {
		ctxLogger.Error("update review failed", err)
		return err
	}
	// update restaurant rating
	err = s.UpdateRestaurantRating(ctx, review.RestaurantID)
	if err != nil {
		ctxLogger.Error("update restaurant rating failed", err)
		return err
	}
	return nil
}
