package review

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/pagination"
)

type FetchReviewsInput struct {
	Paging       pagination.Input
	RestaurantID string
	Latest       bool
}

type FetchReviewsOutput struct {
	Data *pagination.Pagination[entities.Review]
}
