package auth

import (
	"backend/pkg/utils"
	"github.com/golang-jwt/jwt/v4"
	"time"
)

type TokenType string

const (
	AccessToken  TokenType = "access"
	RefreshToken TokenType = "refresh"
)

type Claims struct {
	UUID      string `json:"uuid"`
	UserID    string `json:"user_id"`
	DeviceID  string `json:"device_id"`
	TokenType string `json:"token_type"`
	CreatedAt int64  `json:"created_at"`
	jwt.RegisteredClaims
}

func NewClaims(
	userID string,
	deviceID string,
	tokenType TokenType,
	expiredTime time.Time,
	issuer string,
) *Claims {
	return &Claims{
		UUID:      utils.GenerateUniqueKey(),
		UserID:    userID,
		DeviceID:  deviceID,
		TokenType: string(tokenType),
		CreatedAt: jwt.TimeFunc().Unix(),
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expiredTime),
			Issuer:    issuer,
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
}
