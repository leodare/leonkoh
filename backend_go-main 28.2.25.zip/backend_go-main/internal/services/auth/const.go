package auth

const (
	AccessTokenExpiredDefault  = 10
	RefreshTokenExpiredDefault = 60
)
