package auth

import (
	caching "backend/internal/infrastructure/caching/interface"
	"backend/pkg/logger"
	"backend/pkg/utils"
	xerror "backend/pkg/x-error"
	"context"
	"encoding/json"
	"fmt"
	"github.com/golang-jwt/jwt/v4"
	"github.com/spf13/viper"
	"time"
)

type Service interface {
	GenerateToken(ctx context.Context, userID string, deviceId string) (accessToken string, refreshToken string, err error)
	GenerateAccessToken(ctx context.Context, userID string, deviceId string) (string, error)
	GenerateRefreshToken(ctx context.Context, userID string, deviceId string) (string, error)
	ParseToken(ctx context.Context, token string) (*Claims, error)
	CheckValidClaims(ctx context.Context, tokenType TokenType, deviceId string, claims *Claims) error
	RevokeToken(ctx context.Context, token string) error
}

type service struct {
	secretKey    string
	issuer       string
	cacheManager caching.Provider
}

func NewAuthService(cacheManager caching.Provider) Service {
	secretKey := viper.GetString("jwt.secret_key")
	issuer := viper.GetString("jwt.issuer")
	return &service{
		secretKey:    secretKey,
		issuer:       issuer,
		cacheManager: cacheManager,
	}
}

func (s *service) GenerateToken(ctx context.Context, userID string, deviceId string) (accessToken string, refreshToken string, err error) {
	accessToken, err = s.GenerateAccessToken(ctx, userID, deviceId)
	if err != nil {
		return "", "", err
	}

	refreshToken, err = s.GenerateRefreshToken(ctx, userID, deviceId)
	if err != nil {
		return "", "", err
	}

	return accessToken, refreshToken, nil
}

func (s *service) GenerateAccessToken(ctx context.Context, userID string, deviceId string) (string, error) {
	ctxLogger := logger.NewLogger(ctx)
	configExpired := viper.GetInt("jwt.access_token_expired")
	if configExpired == 0 {
		configExpired = AccessTokenExpiredDefault
	}
	expiredTime := time.Now().Add(time.Duration(configExpired) * time.Minute)
	claims := NewClaims(userID, deviceId, AccessToken, expiredTime, s.issuer)
	token := jwt.NewWithClaims(jwt.SigningMethodHS512, claims)
	t, err := token.SignedString([]byte(s.secretKey))
	if err != nil {
		ctxLogger.Errorf("failed while signed access token: %v", err)
		return "", err
	}
	err = s.setCacheAuth(ctx, claims, configExpired)
	if err != nil {
		ctxLogger.Errorf("failed while set cache auth access token: %v", err)
		return "", err
	}
	return t, nil
}

func (s *service) GenerateRefreshToken(ctx context.Context, userID string, deviceId string) (string, error) {
	ctxLogger := logger.NewLogger(ctx)
	configExpired := viper.GetInt("jwt.refresh_token_expired")
	if configExpired == 0 {
		configExpired = RefreshTokenExpiredDefault
	}
	expiredTime := time.Now().Add(time.Duration(configExpired) * time.Minute)
	claims := NewClaims(userID, deviceId, RefreshToken, expiredTime, s.issuer)
	token := jwt.NewWithClaims(jwt.SigningMethodHS512, claims)
	t, err := token.SignedString([]byte(s.secretKey))
	if err != nil {
		ctxLogger.Errorf("failed while signed refresh token: %v", err)
		return "", err
	}
	err = s.setCacheAuth(ctx, claims, configExpired)
	if err != nil {
		ctxLogger.Errorf("failed while set cache auth refresh token: %v", err)
		return "", err
	}
	return t, nil
}

func (s *service) ParseToken(ctx context.Context, token string) (*Claims, error) {
	ctxLogger := logger.NewLogger(ctx)
	parsedToken, err := jwt.ParseWithClaims(
		token, &Claims{}, func(token *jwt.Token) (interface{}, error) {
			if _, isValid := token.Method.(*jwt.SigningMethodHMAC); !isValid {
				return nil, fmt.Errorf("invalid token - %s", token.Header["alg"])
			}
			return []byte(s.secretKey), nil
		},
	)
	if err != nil {
		ctxLogger.Errorf("Failed while parse token: %v", err.Error())
		return nil, err
	}
	if !parsedToken.Valid {
		return nil, xerror.NewError(xerror.CodeInvalidToken)
	}
	claims, ok := parsedToken.Claims.(*Claims)
	if !ok {
		ctxLogger.Errorf("Token payload invalid, %v", claims)
		return nil, xerror.NewError(xerror.CodeInvalidToken)
	}

	return claims, nil
}

func (s *service) RevokeToken(ctx context.Context, token string) error {
	ctxLogger := logger.NewLogger(ctx)
	claims, err := s.ParseToken(ctx, token)
	if err != nil {
		return err
	}
	err = s.cacheManager.RemoveState(ctx, fmt.Sprintf("%s-", claims.TokenType), claims.UUID)
	if err != nil {
		ctxLogger.Errorf("Failed while remove cache value of token %s", claims.UUID)
		return err
	}
	return nil
}

func (s *service) CheckValidClaims(ctx context.Context, tokenType TokenType, deviceId string, claims *Claims) error {
	ctxLogger := logger.NewLogger(ctx)
	if claims.DeviceID != deviceId {
		if utils.IsDebug() {
			ctxLogger.Warnf("DeviceID not match, %s != %s", claims.DeviceID, deviceId)
		}
		return xerror.NewError(xerror.CodeInvalidToken)
	}
	if claims.TokenType != string(tokenType) {
		if utils.IsDebug() {
			ctxLogger.Warnf("TokenType not match, %s != %s", claims.TokenType, tokenType)
		}
		return xerror.NewError(xerror.CodeInvalidToken)
	}
	value, err := s.cacheManager.GetState(
		ctx,
		fmt.Sprintf("%s-", claims.TokenType),
		claims.UUID,
	)
	if err != nil {
		ctxLogger.Errorf("Failed while get cache value of token %s", claims.UUID)
		return err
	}
	cacheClaims := &Claims{}
	err = json.Unmarshal([]byte(value), cacheClaims)
	if err != nil {
		ctxLogger.Errorf("Failed while parse cache value to claim, %v", err.Error())
		return xerror.NewError(xerror.CodeInvalidToken)
	}
	if claims.TokenType != cacheClaims.TokenType {
		if utils.IsDebug() {
			ctxLogger.Warnf("TokenType not match, %s != %s", claims.TokenType, cacheClaims.TokenType)
		}
		return xerror.NewError(xerror.CodeInvalidToken)
	}
	return nil
}

func (s *service) setCacheAuth(ctx context.Context, claims *Claims, duration int) error {
	ctxLogger := logger.NewLogger(ctx)
	value, err := json.Marshal(claims)
	if err != nil {
		ctxLogger.Errorf("failed while marshal claims: %v", err)
		return err
	}
	err = s.cacheManager.SetState(
		ctx,
		fmt.Sprintf("%s-", claims.TokenType),
		claims.UUID,
		string(value),
		duration,
	)
	if err != nil {
		ctxLogger.Errorf("failed while set cache auth: %v", err)
		return err
	}
	return nil
}
