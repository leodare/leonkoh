package migration

type Migration interface {
	MigrateUp()
	MigrateDown()
}
