package searching

import (
	_interface "backend/internal/infrastructure/searching/interface"
	"backend/internal/infrastructure/searching/meilisearch"
	"github.com/spf13/viper"
)

func getConfig() *_interface.Config {
	config := _interface.Config{}
	err := viper.UnmarshalKey("searching", &config)
	if err != nil {
		panic(err)
	}
	return &config
}

func NewSearchEngine() _interface.SearchEngine {
	config := getConfig()
	switch config.Driver {
	case _interface.SearchEngineMeiliSearch:
		return meilisearch.NewMeiliSearch(config.MeiliSearchConfig)
	default:
		panic("invalid searching type")
	}
}
