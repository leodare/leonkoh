package meilisearch

import "time"

type Task struct {
	TaskUid    int       `json:"taskUid"`
	IndexUid   string    `json:"indexUid"`
	Status     string    `json:"status"`
	Type       string    `json:"type"`
	EnqueuedAt time.Time `json:"enqueuedAt"`
}

type SearchRequest struct {
	Q                   string  `json:"q"`
	ShowMatchesPosition bool    `json:"showMatchesPosition"`
	ShowRankingScore    bool    `json:"showRankingScore"`
	Page                int     `json:"page"`
	HitsPerPage         int     `json:"hitsPerPage"`
	Filter              *string `json:"filter"`
}

type SearchResponse struct {
	Hits             []map[string]interface{} `json:"hits"`
	Query            string                   `json:"query"`
	ProcessingTimeMs int                      `json:"processingTimeMs"`
	HitsPerPage      int                      `json:"hitsPerPage"`
	Page             int                      `json:"page"`
	TotalPages       int                      `json:"totalPages"`
	TotalHits        int                      `json:"totalHits"`
}

// MatchesPosition struct for "_matchesPosition" field
type MatchesPosition struct {
	Address1 []Match `json:"address_1"`
}

// Match struct for start and length in "_matchesPosition"
type Match struct {
	Start  int `json:"start"`
	Length int `json:"length"`
}
