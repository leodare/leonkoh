package meilisearch

import (
	"backend/internal/infrastructure/external/http"
	_interface "backend/internal/infrastructure/searching/interface"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"fmt"
	"io"
	http2 "net/http"
)

type MeiliSearch struct {
	httpClient http.Client
	config     *_interface.MeiliSearchConfig
}

func (m *MeiliSearch) GenerateHeaderItems() map[string]string {
	headers := make(map[string]string)
	contentTypeHeaders := "Content-Type"
	acceptHeaders := "Accept"
	authHeaders := "Authorization"

	appSecret := m.config.AdminKey

	headers[acceptHeaders] = "application/json"
	headers[contentTypeHeaders] = "application/json;charset=UTF-8"
	headers[authHeaders] = fmt.Sprintf("Bearer %s", appSecret)

	return headers

}

func (m *MeiliSearch) Search(ctx context.Context, input _interface.SearchInput) (*_interface.SearchOutput, error) {
	ctxLogger := logger.NewLogger(ctx)
	endpoint := fmt.Sprintf("/indexes/%s/search", input.Collection)
	headers := m.GenerateHeaderItems()
	response := SearchResponse{}
	searchRequest := SearchRequest{
		Q:                   input.Query,
		ShowMatchesPosition: true,
		ShowRankingScore:    true,
		Page:                input.Page,
		HitsPerPage:         input.Limit,
		Filter:              input.Filter,
	}
	resp, err := m.httpClient.Post(ctx, endpoint, searchRequest, headers)
	if err != nil {
		ctxLogger.Errorf("failed to create collection: %v", err)
		return nil, err
	}
	if resp.StatusCode != http2.StatusOK && resp.StatusCode != http2.StatusAccepted {
		bodyBytes, _ := io.ReadAll(resp.Body)
		ctxLogger.Errorf("failed to create collection: %v", string(bodyBytes))
		return nil, xerror.NewError(xerror.MeiliSearchSearchFailed)
	}
	err = http.ParseJSONResponse(ctx, resp, &response)
	if err != nil {
		ctxLogger.Errorf("failed to parse response: %v", err)
		return nil, err
	}
	interfaceSlice := make([]interface{}, len(response.Hits))
	for i, hit := range response.Hits {
		interfaceSlice[i] = hit
	}

	return &_interface.SearchOutput{
		Results:     interfaceSlice,
		HitsPerPage: response.HitsPerPage,
		Page:        response.Page,
		TotalPages:  response.TotalPages,
		TotalHits:   response.TotalHits,
	}, nil

}

func (m *MeiliSearch) IndexDocument(ctx context.Context, input _interface.IndexDocumentInput) error {
	ctxLogger := logger.NewLogger(ctx)
	endpoint := fmt.Sprintf("/indexes/%s/documents", input.Collection)
	headers := m.GenerateHeaderItems()
	response := Task{}
	resp, err := m.httpClient.Post(ctx, endpoint, input.Documents, headers)
	if err != nil {
		ctxLogger.Errorf("failed to create documents: %v", err)
		return err
	}
	if resp.StatusCode != http2.StatusOK && resp.StatusCode != http2.StatusAccepted {
		ctxLogger.Errorf("failed to create documents: %v", err)
		return xerror.NewError(xerror.MeiliSearchCreateDocumentsFailed)
	}
	err = http.ParseJSONResponse(ctx, resp, &response)
	if err != nil {
		return err
	}

	return nil
}

func (m *MeiliSearch) DeleteAllDocuments(ctx context.Context, collection string) error {
	ctxLogger := logger.NewLogger(ctx)
	endpoint := fmt.Sprintf("/indexes/%s/documents", collection)
	headers := m.GenerateHeaderItems()
	response := Task{}
	resp, err := m.httpClient.Delete(ctx, endpoint, nil, headers)
	if err != nil {
		ctxLogger.Errorf("failed to create collection: %v", err)
		return err
	}
	if resp.StatusCode != http2.StatusOK && resp.StatusCode != http2.StatusAccepted {
		ctxLogger.Errorf("failed to create collection: %v", err)
		return xerror.NewError(xerror.MeiliSearchDeleteDocumentsFailed)
	}
	err = http.ParseJSONResponse(ctx, resp, &response)
	if err != nil {
		return err
	}

	return nil
}

func (m *MeiliSearch) CreateCollection(ctx context.Context, input _interface.CreateCollectionInput) error {
	ctxLogger := logger.NewLogger(ctx)
	endpoint := fmt.Sprintf("/indexes")
	headers := m.GenerateHeaderItems()
	response := Task{}
	resp, err := m.httpClient.Post(ctx, endpoint, input, headers)
	if err != nil {
		ctxLogger.Errorf("failed to create collection: %v", err)
		return err
	}
	if resp.StatusCode != http2.StatusOK && resp.StatusCode != http2.StatusAccepted {
		ctxLogger.Errorf("failed to create collection: %v", err)
		return xerror.NewError(xerror.MeiliSearchCreateCollectionFailed)
	}
	err = http.ParseJSONResponse(ctx, resp, &response)
	if err != nil {
		return err
	}

	return nil
}

func NewMeiliSearch(config *_interface.MeiliSearchConfig) _interface.SearchEngine {
	httpClient := http.NewHttpClient(config.HostInfo, config.Timeout)
	return &MeiliSearch{httpClient: httpClient, config: config}
}
