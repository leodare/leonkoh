package _interface

import "context"

const (
	SearchEngineMeiliSearch = "meilisearch"
)

type SearchEngine interface {
	Search(ctx context.Context, input SearchInput) (*SearchOutput, error)
	IndexDocument(ctx context.Context, input IndexDocumentInput) error
	DeleteAllDocuments(ctx context.Context, collection string) error
	CreateCollection(ctx context.Context, input CreateCollectionInput) error
}
