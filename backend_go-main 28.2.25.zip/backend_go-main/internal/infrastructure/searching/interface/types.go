package _interface

import "time"

type SearchInput struct {
	Query      string  `json:"query"`
	Collection string  `json:"collection"`
	Page       int     `json:"page"`
	Limit      int     `json:"limit"`
	Filter     *string `json:"filter"`
}

type SearchOutput struct {
	Results     []interface{} `json:"results"`
	HitsPerPage int           `json:"hitsPerPage"`
	Page        int           `json:"page"`
	TotalPages  int           `json:"totalPages"`
	TotalHits   int           `json:"totalHits"`
}

type IndexDocumentInput struct {
	Documents  []interface{} `json:"documents"`
	Collection string        `json:"collection"`
}

type CreateCollectionInput struct {
	Collection string `json:"collection"`
}

type MeiliSearchConfig struct {
	HostInfo  string        `yaml:"hostInfo" json:"hostInfo"`
	SearchKey string        `yaml:"searchKey" json:"searchKey"`
	AdminKey  string        `yaml:"adminKey" json:"adminKey"`
	Timeout   time.Duration `yaml:"timeout" json:"timeout"`
}

type Config struct {
	Driver            string             `yaml:"driver" json:"driver"`
	MeiliSearchConfig *MeiliSearchConfig `yaml:"meiliSearchConfig" json:"meiliSearchConfig"`
}
