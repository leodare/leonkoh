package _interface

type Type string

type TwilioConfig struct {
	AccountSID string `json:"account_sid" yaml:"accountSID"`
	AuthToken  string `json:"auth_token" yaml:"authToken"`
	From       string `json:"from" yaml:"from"`
}
