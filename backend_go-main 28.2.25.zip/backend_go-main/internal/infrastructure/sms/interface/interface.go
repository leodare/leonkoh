package _interface

import "context"

type Service interface {
	Send(ctx context.Context, phoneNumber, content string) error
}
