package twilio

import (
	_interface "backend/internal/infrastructure/sms/interface"
	"backend/pkg/logger"
	"backend/pkg/utils"
	"context"
	"github.com/spf13/viper"
	twilioGo "github.com/twilio/twilio-go"
	twilioApi "github.com/twilio/twilio-go/rest/api/v2010"
)

type twilio struct {
	config _interface.TwilioConfig
	client *twilioGo.RestClient
}

func NewTwilio() _interface.Service {
	config := _interface.TwilioConfig{}
	err := viper.UnmarshalKey("twilio", &config)
	if err != nil {
		panic(err)
	}
	client := twilioGo.NewRestClientWithParams(
		twilioGo.ClientParams{
			Username: config.AccountSID,
			Password: config.AuthToken,
		},
	)
	return &twilio{
		config: config,
		client: client,
	}
}

func (t *twilio) Send(ctx context.Context, phoneNumber, content string) error {
	if utils.IsDebug() {
		return nil
	}
	ctxLogger := logger.NewLogger(ctx)
	params := t.createParams(ctx, phoneNumber, content)
	resp, err := t.client.Api.CreateMessage(params)
	if err != nil {
		ctxLogger.Errorf("Failed to send sms, err: %v", err)
		return err
	}
	ctxLogger.Infof("Send sms success, response: %v", resp)
	return nil
}

func (t *twilio) createParams(ctx context.Context, phoneNumber, content string) *twilioApi.CreateMessageParams {
	params := &twilioApi.CreateMessageParams{}
	params.SetTo(phoneNumber)
	params.SetFrom(t.config.From)
	params.SetBody(content)
	return params
}
