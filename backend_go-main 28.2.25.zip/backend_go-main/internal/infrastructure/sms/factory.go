package sms

import (
	_interface "backend/internal/infrastructure/sms/interface"
	"backend/internal/infrastructure/sms/twilio"
)

const (
	Twilio _interface.Type = "twilio"
)

func New(provider _interface.Type) _interface.Service {
	switch provider {
	case Twilio:
		return twilio.NewTwilio()
	default:
		panic("invalid sms provider")
	}
}
