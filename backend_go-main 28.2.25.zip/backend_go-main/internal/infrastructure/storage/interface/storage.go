package _interface

import (
	"io"
	"time"
)

type Service interface {
	GetImageURl(base64Data, contentType string) (string, error)
	UploadImage(contentType, imageData string) (string, error)
	GetImage(imageName string) (io.ReadCloser, error)
	GetFileReader(fileName string) (io.ReadCloser, error)
	UploadFileFromStream(reader io.Reader, fileName, contentType string) (string, error)
}

type Object struct {
	Key          string
	LastModified time.Time
}

type Metadata struct {
	Size         int64
	LastModified time.Time
	ContentType  string
	Metadata     map[string]string
}
