package local

import (
	_interface "backend/internal/infrastructure/storage/interface"
	"github.com/spf13/viper"
)

type Service struct {
	BasePath string
}

func NewLocalStorage() _interface.Service {
	return &Service{BasePath: getBasePath()}
}

func getBasePath() string {
	return viper.GetString("storage.local.base_path")
}
