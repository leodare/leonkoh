package local

import (
	_interface "backend/internal/infrastructure/storage/interface"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

func (l *Service) GetImageURl(base64Data, contentType string) (string, error) {
	//TODO implement me
	panic("implement me")
}

func (l *Service) UploadFileFromStream(reader io.Reader, fileName, contentType string) (string, error) {
	panic("implement me")
}
func (l *Service) UploadImage(contentType string, imageData string) (string, error) {
	//TODO implement me
	panic("implement me")
}

func (l *Service) GetImage(imageName string) (io.ReadCloser, error) {
	//TODO implement me
	panic("implement me")
}

func (l *Service) GetFileReader(fileName string) (io.ReadCloser, error) {
	panic("implement me")
}

func (l *Service) UploadFile(containerName, filePath, fileName string) error {
	sourceFile, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer sourceFile.Close()

	targetDir := filepath.Join(l.BasePath, containerName)
	if err := os.MkdirAll(targetDir, 0755); err != nil {
		return err
	}

	targetPath := filepath.Join(targetDir, fileName)
	targetFile, err := os.Create(targetPath)
	if err != nil {
		return err
	}
	defer targetFile.Close()

	if _, err := io.Copy(targetFile, sourceFile); err != nil {
		return err
	}
	fmt.Printf("File %s uploaded successfully to %s.\n", fileName, targetPath)
	return nil
}

func (l *Service) DownloadFile(containerName, fileName, localPath string) error {
	sourcePath := filepath.Join(l.BasePath, containerName, fileName)
	sourceFile, err := os.Open(sourcePath)
	if err != nil {
		return err
	}
	defer sourceFile.Close()

	targetFile, err := os.Create(localPath)
	if err != nil {
		return err
	}
	defer targetFile.Close()

	if _, err := io.Copy(targetFile, sourceFile); err != nil {
		return err
	}
	fmt.Printf("File %s downloaded successfully to %s.\n", fileName, localPath)
	return nil
}

func (l *Service) ListObjects(containerName, prefix string) ([]_interface.Object, error) {
	var objects []_interface.Object
	targetDir := filepath.Join(l.BasePath, containerName)

	err := filepath.Walk(targetDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() && filepath.HasPrefix(info.Name(), prefix) {
			objects = append(objects, _interface.Object{
				Key:          info.Name(),
				LastModified: info.ModTime(),
			})
		}
		return nil
	})

	if err != nil {
		return nil, err
	}
	return objects, nil
}

func (l *Service) CreateContainer() error {
	dirPath := filepath.Join(l.BasePath, "")
	if err := os.MkdirAll(dirPath, 0755); err != nil {
		return err
	}
	fmt.Printf("Directory %s created successfully.\n", dirPath)
	return nil
}

func (l *Service) DeleteContainer() error {
	dirPath := filepath.Join(l.BasePath, "")
	if err := os.RemoveAll(dirPath); err != nil {
		return err
	}
	fmt.Printf("Directory %s deleted successfully.\n", dirPath)
	return nil
}

func (l *Service) ChangeVisibility(containerName string, makePublic bool) error {
	// Local storage does not support visibility like S3. No operation.
	return nil
}

func (l *Service) MoveFile(sourceContainer, sourceFile, destContainer, destFile string) error {
	sourcePath := filepath.Join(l.BasePath, sourceContainer, sourceFile)
	destPath := filepath.Join(l.BasePath, destContainer, destFile)

	if err := os.Rename(sourcePath, destPath); err != nil {
		return err
	}
	fmt.Printf("File %s moved successfully to %s.\n", sourceFile, destPath)
	return nil
}

func (l *Service) CopyFile(sourceContainer, sourceFile, destContainer, destFile string) error {
	sourcePath := filepath.Join(l.BasePath, sourceContainer, sourceFile)
	destPath := filepath.Join(l.BasePath, destContainer, destFile)

	source, err := os.Open(sourcePath)
	if err != nil {
		return err
	}
	defer source.Close()

	dest, err := os.Create(destPath)
	if err != nil {
		return err
	}
	defer dest.Close()

	if _, err = io.Copy(dest, source); err != nil {
		return err
	}
	fmt.Printf("File %s copied successfully to %s.\n", sourceFile, destPath)
	return nil
}

func (l *Service) RenameFile(containerName, newFileName, oldFileName string) error {
	return l.MoveFile(containerName, oldFileName, containerName, newFileName)
}

func (l *Service) ShareFile(containerName, fileName string, expireTime int) (string, error) {
	// Local storage does not support file sharing like S3. Returning file path.
	path := filepath.Join(l.BasePath, containerName, fileName)
	return fmt.Sprintf("File available at: %s", path), nil
}

func (l *Service) GetObjectMetadata(containerName, fileName string) (_interface.Metadata, error) {
	path := filepath.Join(l.BasePath, containerName, fileName)
	fileInfo, err := os.Stat(path)
	if err != nil {
		return _interface.Metadata{}, err
	}

	metadata := _interface.Metadata{
		Size:         fileInfo.Size(),
		LastModified: fileInfo.ModTime(),
		ContentType:  "application/octet-stream", // Default type, you might want to infer this differently
		Metadata:     make(map[string]string),    // Additional metadata can be managed if needed
	}

	return metadata, nil
}
