package s3

import (
	"github.com/spf13/viper"
	"strings"
)

type Config struct {
	Region   string `yaml:"region"`
	EndPoint string `yaml:"endpoint"`
	Id       string `yaml:"id"`
	Secret   string `yaml:"secret"`
	Bucket   string `yaml:"bucket"`
}

func getStorageConfig() Config {
	s3Config := Config{}
	if err := viper.UnmarshalKey("storage.s3", &s3Config); err != nil {
		panic(err)
	}
	return s3Config
}

// insertSlashEveryTwoCharacters inserts a '/' character after every two characters in the input string
func insertSlashEveryTwoCharacters(input string) string {
	var parts []string
	for i := 0; i < len(input); i += 8 {
		parts = append(parts, input[i:i+8])
	}
	return strings.Join(parts, "/")
}
