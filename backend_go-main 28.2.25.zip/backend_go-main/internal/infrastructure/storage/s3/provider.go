package s3

import (
	_interface "backend/internal/infrastructure/storage/interface"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
)

type Service struct {
	Client   *s3.S3
	Uploader *s3manager.Uploader
	Config   Config
}

func NewS3Service() _interface.Service {
	config := getStorageConfig()
	sess := session.Must(session.NewSession(&aws.Config{
		Credentials:      credentials.NewStaticCredentials(config.Id, config.Secret, ""),
		Region:           aws.String(config.Region),
		S3ForcePathStyle: aws.Bool(true)}))
	return &Service{
		Client:   s3.New(sess),
		Uploader: s3manager.NewUploader(sess),
		Config:   config,
	}
}
