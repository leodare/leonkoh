package s3

import (
	_interface "backend/internal/infrastructure/storage/interface"
	"bytes"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
	"io"
	"os"
	"strings"
	"time"
)

func (s *Service) GetImageURl(base64Data, contentType string) (string, error) {
	data, err := base64.StdEncoding.DecodeString(base64Data)
	if err != nil {
		return "", fmt.Errorf("failed to decode base64 data: %v", err)
	}

	// Create an MD5 hash from the data
	hasher := md5.New()
	hasher.Write(data)
	hashBytes := hasher.Sum(nil)

	// Convert the binary hash data to a hexadecimal string
	hashStr := hex.EncodeToString(hashBytes)

	// Split the hash string into parts of two characters each, separated by '/'
	path := insertSlashEveryTwoCharacters(hashStr)
	path = path + "." + strings.Split(contentType, "/")[1]
	return path, nil
}

func (s *Service) UploadImage(contentType string, imageData string) (string, error) {
	imageName, err := s.GetImageURl(imageData, contentType)
	if err != nil {
		return "", err
	}
	data, err := base64.StdEncoding.DecodeString(imageData)
	if err != nil {
		return "", fmt.Errorf("failed to decode base64 data: %v", err)
	}
	_, err = s.Uploader.Upload(&s3manager.UploadInput{
		Bucket:      aws.String(s.Config.Bucket),
		Key:         aws.String(imageName),
		Body:        bytes.NewReader(data),
		ContentType: aws.String(contentType),
	})
	return imageName, err
}

func (s *Service) GetImage(imageName string) (io.ReadCloser, error) {

	req, err := s.Client.GetObject(&s3.GetObjectInput{
		Bucket: aws.String(s.Config.Bucket),
		Key:    aws.String(imageName),
	})
	if err != nil {
		return nil, err
	}

	return req.Body, nil
}

func (s *Service) UploadFile(containerName, filePath, fileName string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = s.Uploader.Upload(&s3manager.UploadInput{
		Bucket: aws.String(containerName),
		Key:    aws.String(fileName),
		Body:   file,
	})
	return err
}

func (s *Service) UploadFileFromStream(reader io.Reader, fileName, contentType string) (string, error) {
	_, err := s.Uploader.Upload(&s3manager.UploadInput{
		Bucket:      aws.String(s.Config.Bucket),
		Key:         aws.String(fileName),
		Body:        reader,
		ContentType: aws.String(contentType),
	})
	if err != nil {
		return "", fmt.Errorf("failed to upload file: %v", err)
	}
	return fileName, nil
}

func (s *Service) GetFileReader(fileName string) (io.ReadCloser, error) {
	req, err := s.Client.GetObject(&s3.GetObjectInput{
		Bucket: aws.String(s.Config.Bucket),
		Key:    aws.String(fileName),
	})
	if err != nil {
		return nil, fmt.Errorf("failed to get object: %v", err)
	}

	return req.Body, nil
}
func (s *Service) DownloadFile(containerName, fileName, localPath string) error {
	file, err := os.Create(localPath)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = s3manager.NewDownloader(session.Must(session.NewSession())).Download(file,
		&s3.GetObjectInput{
			Bucket: aws.String(containerName),
			Key:    aws.String(fileName),
		})
	return err
}

func (s *Service) ListObjects(containerName, prefix string) ([]_interface.Object, error) {
	resp, err := s.Client.ListObjectsV2(&s3.ListObjectsV2Input{
		Bucket: aws.String(containerName),
		Prefix: aws.String(prefix),
	})
	if err != nil {
		return nil, err
	}

	var objects []_interface.Object
	for _, item := range resp.Contents {
		objects = append(objects, _interface.Object{
			Key:          *item.Key,
			LastModified: *item.LastModified,
		})
	}
	return objects, nil
}

func (s *Service) CreateContainer() error {
	_, err := s.Client.CreateBucket(&s3.CreateBucketInput{
		Bucket: aws.String(s.Config.Bucket),
	})
	return err
}

func (s *Service) DeleteContainer() error {
	_, err := s.Client.DeleteBucket(&s3.DeleteBucketInput{
		Bucket: aws.String(s.Config.Bucket),
	})
	return err
}

func (s *Service) ChangeVisibility(containerName string, makePublic bool) error {
	acl := "private"
	if makePublic {
		acl = "public-read"
	}
	_, err := s.Client.PutBucketAcl(&s3.PutBucketAclInput{
		Bucket: aws.String(containerName),
		ACL:    aws.String(acl),
	})
	return err
}

func (s *Service) MoveFile(sourceContainer, sourceFile, destContainer, destFile string) error {
	_, err := s.Client.CopyObject(&s3.CopyObjectInput{
		Bucket:     aws.String(destContainer),
		CopySource: aws.String(sourceContainer + "/" + sourceFile),
		Key:        aws.String(destFile),
	})
	if err != nil {
		return err
	}
	_, err = s.Client.DeleteObject(&s3.DeleteObjectInput{
		Bucket: aws.String(sourceContainer),
		Key:    aws.String(sourceFile),
	})
	return err
}

func (s *Service) CopyFile(sourceContainer, sourceFile, destContainer, destFile string) error {
	_, err := s.Client.CopyObject(&s3.CopyObjectInput{
		Bucket:     aws.String(destContainer),
		CopySource: aws.String(sourceContainer + "/" + sourceFile),
		Key:        aws.String(destFile),
	})
	return err
}

func (s *Service) RenameFile(containerName, newFileName, oldFileName string) error {
	return s.MoveFile(containerName, oldFileName, containerName, newFileName)
}

func (s *Service) ShareFile(containerName, fileName string, expireTime int) (string, error) {
	req, _ := s.Client.GetObjectRequest(&s3.GetObjectInput{
		Bucket: aws.String(containerName),
		Key:    aws.String(fileName),
	})
	url, err := req.Presign(time.Duration(expireTime) * time.Minute)
	return url, err
}

func (s *Service) GetObjectMetadata(containerName, fileName string) (_interface.Metadata, error) {
	input := &s3.HeadObjectInput{
		Bucket: aws.String(containerName),
		Key:    aws.String(fileName),
	}
	result, err := s.Client.HeadObject(input)
	if err != nil {
		return _interface.Metadata{}, err
	}

	metadata := _interface.Metadata{
		Size:         *result.ContentLength,
		LastModified: *result.LastModified,
		ContentType:  *result.ContentType,
		Metadata:     aws.StringValueMap(result.Metadata),
	}

	return metadata, nil
}
