package s3

import "time"

type Object struct {
	Key          string
	LastModified time.Time
}

type Metadata struct {
	Size         int64
	LastModified time.Time
	ContentType  string
	Metadata     map[string]string
}
