package storage

import (
	_interface "backend/internal/infrastructure/storage/interface"
	"backend/internal/infrastructure/storage/local"
	"backend/internal/infrastructure/storage/s3"
	"github.com/spf13/viper"
)

func NewService() _interface.Service {
	storageType := getStorageType()

	switch storageType {
	case "s3":
		return s3.NewS3Service()
	case "local":
		// chưa test, copy từ gpt nên méo chắc chạy được không
		return local.NewLocalStorage()
	default:
		panic("Unsupported storage type")
	}
}

func getStorageType() string {
	return viper.GetString("storage.type")
}
