package caching

import (
	"backend/internal/infrastructure/caching/interface"
	"backend/internal/infrastructure/caching/redis"
)

func CreateMemoryStore() _interface.Provider {
	p, err := redis.NewRedisProvider()
	if err != nil {
		//panic(err)
	}
	return p
}
