package _interface

import "context"

type Provider interface {
	SetState(ctx context.Context, prefixKey, key, state string, expiration int) error
	// GetState returns the state from the session store
	GetState(ctx context.Context, prefixKey string, key string) (string, error)
	// RemoveState removes the social login state from the session store
	RemoveState(ctx context.Context, prefixKey string, key string) error

	GetStates(ctx context.Context, prefix string, cursor uint64) (map[string]string, error)
}
