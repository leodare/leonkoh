package redis

import (
	"backend/internal/infrastructure/caching/interface"
	xerror "backend/pkg/x-error"
	"context"
	"github.com/go-redis/redis/v8"
	"github.com/spf13/viper"
)

type provider struct {
	store *redis.Client
}

func NewRedisProvider() (_interface.Provider, error) {
	network := viper.GetString("redis.network")
	if network == "" {
		return nil, xerror.NewError(xerror.ConfigKeyNotFound)
	}
	address := viper.GetString("redis.address")
	if address == "" {
		return nil, xerror.NewError(xerror.ConfigKeyNotFound)
	}
	username := viper.GetString("redis.username")
	password := viper.GetString("redis.password")
	db := viper.GetInt("redis.db")

	opt := &redis.Options{
		Network:  network,
		Addr:     address,
		Username: username,
		Password: password,
		DB:       db,
	}

	rdb := redis.NewClient(opt)
	_, err := rdb.Ping(context.Background()).Result()
	if err != nil {
		return nil, err
	}

	return &provider{
		store: rdb,
	}, nil
}
