package redis

import (
	"backend/pkg/logger"
	"context"
	"errors"
	"github.com/go-redis/redis/v8"
	"time"
)

func (c *provider) SetState(ctx context.Context, prefixKey, key, value string, expiration int) error {
	ctxLogger := logger.NewLogger(ctx)
	var expireMinuteTime = time.Duration(expiration) * time.Minute
	err := c.store.Set(ctx, prefixKey+key, value, expireMinuteTime).Err()
	if err != nil {
		ctxLogger.Errorf("Failed to set state with key %s, value %s, error: %v", key, value, err)
		return err
	}

	return nil
}

func (c *provider) GetState(ctx context.Context, prefixKey string, key string) (string, error) {
	ctxLogger := logger.NewLogger(ctx)
	data, err := c.store.Get(ctx, prefixKey+key).Result()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return "", nil
		}
		ctxLogger.Errorf("Failed to get state with key %s, error: %v", key, err)
		return "", err
	}

	return data, err
}

func (c *provider) RemoveState(ctx context.Context, prefixKey string, key string) error {
	ctxLogger := logger.NewLogger(ctx)
	err := c.store.Del(ctx, prefixKey+key).Err()
	if err != nil {
		ctxLogger.Errorf("Failed to remove state with key %s, error: %v", key, err)
		return err
	}

	return nil
}

func (c *provider) GetStates(ctx context.Context, prefix string, cursor uint64) (map[string]string, error) {
	ctxLogger := logger.NewLogger(ctx)
	scanKeys, _, err := c.store.Scan(ctx, cursor, prefix, 0).Result()
	if err != nil {
		ctxLogger.Errorf("Failed to scan keys with prefix %s, error: %v", prefix, err)
		return nil, err
	}
	var result map[string]string
	for _, key := range scanKeys {
		var val string
		val, err = c.store.Get(ctx, key).Result()
		if err != nil {
			ctxLogger.Errorf("Failed to get value with key %s, error: %v", key, err)
			return nil, err
		}
		if result == nil {
			result = make(map[string]string)
		}
		result[key] = val
	}
	return result, nil
}
