package _interface

import "context"

type Service interface {
	SendRaw(ctx context.Context, id, email, subject, content string) error
	SendByTemplate(ctx context.Context, id, email, template string, data map[string]interface{}) error
}
