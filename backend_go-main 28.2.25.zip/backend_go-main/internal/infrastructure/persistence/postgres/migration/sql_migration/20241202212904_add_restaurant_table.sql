-- +goose Up
-- +goose StatementBegin
create table restaurants
(
    id           uuid                     default gen_random_uuid() not null
        primary key,
    name         varchar,
    address      varchar,
    unit_number  varchar,
    area         varchar,
    phone        varchar,
    opening_time time,
    closing_time time,
    price_from   double precision,
    price_to     double precision,
    latitude     numeric,
    longitude    numeric,
    postal_code  varchar,
    created_at   timestamp with time zone default now(),
    updated_at   timestamp with time zone default now(),
    deleted_at   timestamp with time zone
);
create table restaurant_statics
(
    id            uuid                     default gen_random_uuid() not null
        primary key,
    restaurant_id uuid
        constraint fk_restaurant_statics_restaurant
            references restaurants,
    static_id     uuid
        constraint fk_restaurant_statics_static
            references statics,
    created_at    timestamp with time zone default now(),
    updated_at    timestamp with time zone default now(),
    deleted_at    timestamp with time zone
);

create table restaurants_cuisine_types
(
    id              uuid default gen_random_uuid() not null
        primary key,
    restaurant_id   uuid
        constraint fk_restaurants_cuisine_types_restaurant
            references restaurants,
    cuisine_type_id uuid
        constraint fk_restaurants_cuisine_types_cuisine
            references cuisine_types
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS restaurants;
DROP TABLE IF EXISTS restaurant_statics;
DROP TABLE IF EXISTS restaurants_cuisine_types;
-- +goose StatementEnd
