-- +goose Up
-- +goose StatementBegin
create unique index cuisine_types_name_uindex
    on cuisine_types (name);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
drop index cuisine_types_name_uindex;
-- +goose StatementEnd
