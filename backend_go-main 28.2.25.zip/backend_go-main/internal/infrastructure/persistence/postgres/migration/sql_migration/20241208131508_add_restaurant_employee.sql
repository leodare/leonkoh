-- +goose Up
-- +goose StatementBegin
CREATE TABLE restaurant_employee
(
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id uuid not null,
    employee_id   uuid not null,
    is_owner      boolean,
    created_at    timestamptz      DEFAULT NOW(),
    updated_at    timestamptz      DEFAULT NOW(),
    deleted_at    timestamptz,
    CONSTRAINT fk_restaurant_employee_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants (id),
    CONSTRAINT fk_restaurant_employee_user FOREIGN KEY (employee_id) REFERENCES users (id)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
drop table restaurant_employee;
-- +goose StatementEnd
