-- +goose Up
-- +goose StatementBegin
CREATE TABLE "reviews"
(
    "id"                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    "created_by"          uuid,
    "title"               varchar,
    "content"             text,
    "restaurant_id"       uuid,
    "visit_date"          date,
    "overall_rating"      decimal(3, 2),
    "taste_rating"        integer,
    "aroma_rating"        integer,
    "atmosphere_rating"   integer,
    "presentation_rating" integer,
    "service_rating"      integer,
    "created_at"          timestamptz      DEFAULT NOW(),
    "updated_at"          timestamptz      DEFAULT NOW(),
    "deleted_at"          timestamptz,
    CONSTRAINT fk_reviews_user FOREIGN KEY ("created_by") REFERENCES "users" ("id"),
    CONSTRAINT fk_reviews_restaurant FOREIGN KEY ("restaurant_id") REFERENCES "restaurants" ("id")
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS "reviews";
-- +goose StatementEnd
