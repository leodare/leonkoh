-- +goose Up
-- +goose StatementBegin
CREATE TABLE user_follows
(
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(), -- Khóa chính duy nhất
    follower_id   uuid NOT NULL REFERENCES users (id), -- User đang follow (user_1)
    followed_id   uuid NOT NULL REFERENCES users (id), -- User được follow (user_2)
    created_at    timestamptz NOT NULL DEFAULT NOW(), -- Thời gian tạo mối quan hệ follow
    updated_at    timestamptz, -- Thời gian cập nhật gần nhất (nếu cần)
    deleted_at    timestamptz, -- Thời gian xóa mối quan hệ (nếu cần xóa mềm)
    UNIQUE (follower_id, followed_id) -- Đảm bảo không trùng lặp follower-followed
);
CREATE INDEX idx_user_follows_follower_id ON user_follows (follower_id); -- Index cho follower_id
CREATE INDEX idx_user_follows_followed_id ON user_follows (followed_id); -- Index cho followed_id
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE user_follows;
-- +goose StatementEnd