-- +goose Up
-- +goose StatementBegin
CREATE TABLE categories
(
    id           uuid PRIMARY KEY     DEFAULT gen_random_uuid(),
    name         varchar UNIQUE,
    description  text,
    "created_at" timestamptz NOT NULL DEFAULT NOW(),
    "updated_at" timestamptz,
    "deleted_at" timestamptz
);
INSERT INTO categories (name, description) VALUES ('Stall', ''), ('Restaurant', '');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
drop table categories;
-- +goose StatementEnd
