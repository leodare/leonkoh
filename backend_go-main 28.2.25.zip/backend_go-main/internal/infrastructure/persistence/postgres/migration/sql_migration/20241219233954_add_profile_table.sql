-- +goose Up
-- +goose StatementBegin
CREATE TABLE profiles
(
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
    address_id    uuid REFERENCES addresses (id) ON DELETE SET NULL ON UPDATE CASCADE,
    first_name    TEXT NOT NULL,
    last_name     TEXT NOT NULL,
    avatar        TEXT,
    bio           TEXT,
    date_of_birth DATE,
    gender        TEXT NOT NULL,
    "created_at"  timestamptz NOT NULL DEFAULT NOW(),
    "updated_at"  timestamptz,
    "deleted_at"  timestamptz
);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE profiles;
-- +goose StatementEnd