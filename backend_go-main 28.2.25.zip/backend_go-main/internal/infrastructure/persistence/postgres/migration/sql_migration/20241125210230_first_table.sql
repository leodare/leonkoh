-- +goose Up
-- +goose StatementBegin
CREATE TABLE IF NOT EXISTS sms_log
(
    id         UUID                     DEFAULT gen_random_uuid()     NOT NULL PRIMARY KEY,
    phone      VARCHAR                                                NOT NULL,
    content    TEXT                                                   NOT NULL,
    status     sms_status               DEFAULT 'pending'::sms_status NOT NULL,
    message    TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()                 NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE,
    deleted_at TIMESTAMP WITH TIME ZONE
                             );

CREATE TABLE IF NOT EXISTS sms_template
(
    id         UUID                     DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    code       VARCHAR                                            NOT NULL UNIQUE,
    name       VARCHAR                                            NOT NULL,
    template   TEXT                                               NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()             NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE,
    deleted_at TIMESTAMP WITH TIME ZONE
                             );

CREATE TABLE IF NOT EXISTS users
(
    id          UUID                     DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    username    VARCHAR                                            NOT NULL UNIQUE,
    password    VARCHAR                                            NOT NULL,
    email       VARCHAR,
    phone       VARCHAR                                            NOT NULL,
    need_verify BOOLEAN                  DEFAULT TRUE              NOT NULL,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT now()             NOT NULL,
    updated_at  TIMESTAMP WITH TIME ZONE,
    deleted_at  TIMESTAMP WITH TIME ZONE
                              );


CREATE TABLE IF NOT EXISTS cuisine_types
(
    id         UUID                     DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    name       VARCHAR(255)                                      NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()            NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE,
    deleted_at TIMESTAMP WITH TIME ZONE
                             );


-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS sms_log;
DROP TABLE IF EXISTS sms_template;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS cuisine_types;
-- +goose StatementEnd
