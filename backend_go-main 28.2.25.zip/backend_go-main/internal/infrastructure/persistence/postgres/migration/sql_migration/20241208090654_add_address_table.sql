-- +goose Up
-- +goose StatementBegin
CREATE TABLE admin_unit_types
(
    "id"         uuid PRIMARY KEY     DEFAULT gen_random_uuid(),
    name         text UNIQUE NOT NULL,
    description  TEXT,
    "created_at" timestamptz NOT NULL DEFAULT NOW(),
    "updated_at" timestamptz,
    "deleted_at" timestamptz
);

CREATE TABLE admin_units
(
    id          uuid PRIMARY KEY,
    name        text NOT NULL,
    type_id     uuid NOT NULL REFERENCES admin_unit_types (id),
    parent_id   uuid REFERENCES admin_units (id) ON DELETE CASCADE ON UPDATE CASCADE,
    code        VARCHAR(50),
    postal_code VARCHAR(50),
    "created_at" timestamptz NOT NULL DEFAULT NOW(),
    "updated_at" timestamptz,
    "deleted_at" timestamptz
);
CREATE INDEX idx_admin_units_name ON admin_units USING GIN (to_tsvector('simple', name));
CREATE INDEX idx_admin_units_code ON admin_units (code);

CREATE TABLE addresses
(
    id            uuid PRIMARY KEY,
    user_id       uuid REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
    admin_unit_id uuid NOT NULL REFERENCES admin_units (id) ON DELETE CASCADE ON UPDATE CASCADE,
    address_1     text,
    address_2     text,
    postal_code   VARCHAR(50),
    latitude      DECIMAL(9, 6),
    longitude     DECIMAL(9, 6),
    "created_at" timestamptz NOT NULL DEFAULT NOW(),
    "updated_at" timestamptz,
    "deleted_at" timestamptz
);
CREATE INDEX idx_addresses_search ON addresses USING GIN (to_tsvector('simple', address_1 || ' ' || address_2));
CREATE INDEX idx_addresses_postal_code ON addresses (postal_code);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE addresses;
DROP TABLE admin_units;
DROP TABLE admin_unit_types;
-- +goose StatementEnd
