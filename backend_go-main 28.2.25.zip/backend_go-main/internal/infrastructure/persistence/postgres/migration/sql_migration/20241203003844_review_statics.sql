-- +goose Up
-- +goose StatementBegin
CREATE TABLE review_statics (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    static_id  UUID NOT NULL,
    review_id  UUID NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT now(),
    updated_at TIMESTAMP,
    deleted_at TIMESTAMP,
    CONSTRAINT fk_review_statics_static FOREIGN KEY (static_id) REFERENCES statics (id),
    CONSTRAINT fk_review_statics_review FOREIGN KEY (review_id) REFERENCES reviews (id)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS review_statics;
-- +goose StatementEnd
