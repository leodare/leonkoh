-- +goose Up
-- +goose StatementBegin
ALTER TABLE restaurants
    ADD COLUMN overall_rating float DEFAULT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE restaurants
DROP COLUMN overall_rating;
-- +goose StatementEnd
