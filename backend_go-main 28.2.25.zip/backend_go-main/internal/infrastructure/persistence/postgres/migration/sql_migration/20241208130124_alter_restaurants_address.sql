-- +goose Up
-- +goose StatementBegin
alter table public.restaurants
drop
column address;

alter table public.restaurants
drop
column latitude;

alter table public.restaurants
drop
column longitude;

alter table public.restaurants
drop
column postal_code;

CREATE TABLE restaurant_address
(
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id uuid not null,
    address_id    uuid not null,
    branch_name   varchar,
    created_at    timestamptz      DEFAULT NOW(),
    updated_at    timestamptz      DEFAULT NOW(),
    deleted_at    timestamptz,
    CONSTRAINT fk_restaurant_addresses_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants (id),
    CONSTRAINT fk_restaurant_addresses_address FOREIGN KEY (address_id) REFERENCES addresses (id)
);

CREATE TABLE restaurant_category
(
    id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id uuid not null,
    category_id   uuid not null,
    created_at    timestamptz      DEFAULT NOW(),
    updated_at    timestamptz      DEFAULT NOW(),
    deleted_at    timestamptz,
    CONSTRAINT fk_restaurant_categories_restaurant FOREIGN KEY (restaurant_id) REFERENCES restaurants (id),
    CONSTRAINT fk_restaurant_categories_category FOREIGN KEY (category_id) REFERENCES categories (id)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
alter table public.restaurants
    add address text,
    add latitude decimal(9, 6),
    add longitude decimal(9, 6),
    add postal_code varchar(50);
drop table restaurant_address;
drop table restaurant_category;
-- +goose StatementEnd
