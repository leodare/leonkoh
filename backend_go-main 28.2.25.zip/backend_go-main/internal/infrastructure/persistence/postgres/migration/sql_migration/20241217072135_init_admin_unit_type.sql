-- +goose Up
-- +goose StatementBegin
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('a71366ea-80bc-4581-b16f-d8804955304f', 'country',
        'A sovereign state recognized internationally as an independent country.', '2024-12-08 13:10:32.807886 +00:00',
        null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('8c81ee24-1a4e-421b-b999-254f9f3837dc', 'region',
        'A large geographical area within a country, often grouping multiple states/provinces.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('990fe317-0de8-488e-a1a9-a249ce251331', 'state',
        'A primary subdivision of a country, commonly used in federal nations (e.g. USA, Australia).',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('f0eb580c-9bed-4ae0-979e-fed70ac6ad99', 'province',
        'A primary administrative division of a country, similar to a state in many systems (e.g. Canada, China).',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('06e98f06-931f-41eb-97fe-e9994d642c20', 'territory',
        'A geographical area within a country that may have a distinct administrative system or lesser autonomy.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('2d792c3e-7ca3-4345-832e-cfb0e38ea261', 'department',
        'An administrative division used in various countries (e.g. France, Colombia), generally below the national level.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('f36da35a-c517-488f-b79a-72e4bf4ac731', 'division',
        'A broad administrative level sometimes used as a grouping of provinces or districts (e.g. Bangladesh, Pakistan).',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('512ab232-adaa-43da-b661-29b409288d30', 'county',
        'A subdivision often found in English-speaking countries, typically below a state or province.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('e5090a8d-f08a-4073-89c6-39efb44b75a6', 'district',
        'A common mid-level administrative unit in many countries, below a province/state and above a city/town.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('f88705ae-9a13-4cfb-84c5-3cb97d88638f', 'municipality',
        'A general-purpose administrative subdivision, typically a town or city government.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('71aa9e14-9a2f-4624-a825-b3af1bb6fdc3', 'city',
        'A large and often densely populated urban area with its own local government.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('56e5dce0-fffb-4760-8500-beb6bbcd471a', 'town',
        'A populated urban area smaller than a city, with local governance.', '2024-12-08 13:10:32.807886 +00:00', null,
        null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('a0ed4adc-75d0-40dd-96ce-43dca92f09ad', 'commune',
        'A small administrative unit used in certain countries (e.g. France, parts of Africa) that may represent a small town or cluster of settlements.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('cf1d2299-9338-4171-9bc2-5df8cdd32792', 'ward',
        'A subdivision of a city or town, often used for administrative or electoral purposes.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('784a0bcc-8ef0-4eda-84c8-53ea49cd4ad1', 'subdistrict',
        'A subdivision of a district or other mid-level administrative unit, found in various countries.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('ee782642-de73-43a9-b9d8-263820e89839', 'village',
        'A small, clustered human settlement, usually in a rural area.', '2024-12-08 13:10:32.807886 +00:00', null,
        null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('596a6b42-6121-4717-a590-b0e5668029ec', 'hamlet',
        'A very small settlement, often a few houses in a rural area.', '2024-12-08 13:10:32.807886 +00:00', null,
        null);
INSERT INTO public.admin_unit_types (id, name, description, created_at, updated_at, deleted_at)
VALUES ('1062c8cc-e7ee-4c6c-be86-9db58254d535', 'neighborhood',
        'A localized community within a larger city or town, often defined informally but can have administrative significance.',
        '2024-12-08 13:10:32.807886 +00:00', null, null);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DELETE
FROM public.admin_unit_types
WHERE id IN ('a71366ea-80bc-4581-b16f-d8804955304f', '8c81ee24-1a4e-421b-b999-254f9f3837dc',
             '990fe317-0de8-488e-a1a9-a249ce251331', 'f0eb580c-9bed-4ae0-979e-fed70ac6ad99',
             '06e98f06-931f-41eb-97fe-e9994d642c20', '2d792c3e-7ca3-4345-832e-cfb0e38ea261',
             'f36da35a-c517-488f-b79a-72e4bf4ac731', '512ab232-adaa-43da-b661-29b409288d30',
             'e5090a8d-f08a-4073-89c6-39efb44b75a6', 'f88705ae-9a13-4cfb-84c5-3cb97d88638f',
             '71aa9e14-9a2f-4624-a825-b3af1bb6fdc3', '56e5dce0-fffb-4760-8500-beb6bbcd471a',
             'a0ed4adc-75d0-40dd-96ce-43dca92f09ad', 'cf1d2299-9338-4171-9bc2-5df8cdd32792',
             '784a0bcc-8ef0-4eda-84c8-53ea49cd4ad1', 'ee782642-de73-43a9-b9d8-263820e89839',
             '596a6b42-6121-4717-a590-b0e5668029ec', '1062c8cc-e7ee-4c6c-be86-9db58254d535');
-- +goose StatementEnd
