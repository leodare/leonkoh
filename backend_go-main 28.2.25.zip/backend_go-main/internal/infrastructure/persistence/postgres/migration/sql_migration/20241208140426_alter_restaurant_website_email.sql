-- +goose Up
-- +goose StatementBegin
alter table public.restaurants
    add website varchar(255);

alter table public.restaurants
    add email varchar(255);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
alter table public.restaurants
drop
column website;
alter table public.restaurants
drop
column phone;
-- +goose StatementEnd
