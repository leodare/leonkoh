-- +goose Up
-- +goose StatementBegin
create table public.admin_unit_additional_info
(
    id            uuid default gen_random_uuid() not null,
    type          varchar                        not null,
    value         varchar                        not null,
    admin_unit_id uuid                           not null
        constraint admin_unit_additional_info_admin_units_id_fk
            references public.admin_units
);

comment on column public.admin_unit_additional_info.type is 'Info type';

comment on column public.admin_unit_additional_info.value is 'Info value';

create index admin_unit_additional_info_admin_unit_id_index
    on public.admin_unit_additional_info (admin_unit_id);

create index admin_unit_additional_info_type_value_index
    on public.admin_unit_additional_info (type, value);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE public.admin_unit_additional_info;
-- +goose StatementEnd
