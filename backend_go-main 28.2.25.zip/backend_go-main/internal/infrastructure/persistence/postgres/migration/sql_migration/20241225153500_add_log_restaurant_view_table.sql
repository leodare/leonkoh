-- +goose Up
-- +goose StatementBegin
CREATE TABLE log_restaurant_views
(
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id  uuid NOT NULL REFERENCES restaurants (id) ON DELETE CASCADE ON UPDATE CASCADE,
    user_id        uuid NOT NULL REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
    "created_at"   timestamptz NOT NULL DEFAULT NOW(),
    "updated_at"   timestamptz,
    "deleted_at"   timestamptz
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE log_restaurant_views;
-- +goose StatementEnd