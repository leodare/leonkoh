-- +goose Up
-- +goose StatementBegin
create table statics
(
    id         uuid                     default gen_random_uuid() not null
        primary key,
    url        varchar(255)                                       not null,
    file_size  bigint                                             not null,
    meta_data  text,
    alt        text,
    created_at timestamp with time zone default now(),
    updated_at timestamp with time zone default now(),
    deleted_at timestamp with time zone
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS statics;
-- +goose StatementEnd
