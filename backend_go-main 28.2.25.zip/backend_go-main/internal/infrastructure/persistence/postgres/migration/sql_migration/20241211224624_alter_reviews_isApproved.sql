-- +goose Up
-- +goose StatementBegin
alter table public.reviews
    add is_approved bool default false not null;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
alter table public.reviews
drop column is_approved;
-- +goose StatementEnd

