package postgres

import (
	"backend/internal/infrastructure/migration"
	"backend/internal/infrastructure/persistence/postgres"
	"database/sql"
	"errors"
	"fmt"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/pressly/goose/v3"

	"github.com/spf13/viper"

	_ "github.com/lib/pq"
)

const migrationDir = "internal/infrastructure/persistence/postgres/migration/sql_migration"

type PSQLMigration struct {
	Driver   string
	DBSource string
}

func NewPSQLMigration() migration.Migration {
	var dbConfig postgres.DBConfig
	err := viper.UnmarshalKey("database", &dbConfig)
	if err != nil {
		panic(err)
	}
	return &PSQLMigration{
		DBSource: fmt.Sprintf(
			"host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
			dbConfig.Host,
			dbConfig.Port,
			dbConfig.User,
			dbConfig.Password,
			dbConfig.Schema,
		),
		Driver: dbConfig.Driver,
	}
}

func (m *PSQLMigration) setupDB() (*sql.DB, error) {
	db, err := sql.Open(m.Driver, m.DBSource)
	if err != nil {
		return nil, fmt.Errorf("failed to open database: %w", err)
	}

	if err = goose.SetDialect(m.Driver); err != nil {
		return nil, fmt.Errorf("failed to set dialect: %w", err)
	}

	return db, nil
}

func (m *PSQLMigration) MigrateUp() {
	log.Info("Starting database migration up")

	db, err := m.setupDB()
	if err != nil {
		panic(err)
	}
	defer db.Close()

	if err = goose.Up(db, migrationDir); err != nil {
		if errors.Is(err, goose.ErrNoMigrationFiles) {
			log.Warnf("Migration not found: %s", err)
			return
		}
		panic(err)
	}

	log.Info("Migration up completed successfully")
}

func (m *PSQLMigration) MigrateDown() {
	log.Info("Starting database migration down")

	db, err := m.setupDB()
	if err != nil {
		panic(err)
	}
	defer db.Close()

	if err = goose.Down(db, migrationDir); err != nil {
		if errors.Is(err, goose.ErrNoMigrationFiles) {
			log.Warnf("Migration not found: %s", err)
			return
		}
		panic(err)
	}

	log.Info("Migration down completed successfully")
}
