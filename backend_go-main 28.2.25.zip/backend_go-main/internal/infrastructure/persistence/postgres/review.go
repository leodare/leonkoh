package postgres

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
)

type review struct {
	repositories.Base[entities.Review]
}

func NewReviewRepository(db *gorm.DB) repositories.Review {
	return &review{
		Base: NewBaseRepository[entities.Review](db),
	}
}

func (r *review) GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.ReviewCondition) (*pagination.Pagination[entities.Review], error) {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx)
	db = conditions.AddReviewCondition(db, condition)
	result, err := pagination.Paginate[entities.Review](db, paging)
	if err != nil {
		ctxLogger.Errorf("GetPaginatedByCondition err: %v", err)
		return nil, err
	}
	return result, nil
}

func (r *review) GetByRestaurantID(ctx context.Context, restaurantID string) ([]entities.Review, error) {
	ctxLogger := logger.NewLogger(ctx)

	var reviews []entities.Review
	err := r.GetDb(ctx).Where("restaurant_id = ?", restaurantID).Find(&reviews).Error
	if err != nil {
		ctxLogger.Errorf("Failed to get reviews by restaurant ID: %v", err)
		return nil, err
	}

	return reviews, nil
}
func (r *review) GetByExecutorIdAndRestaurantId(ctx context.Context, executorId string, restaurantId string) (*entities.Review, error) {
	ctxLogger := logger.NewLogger(ctx)

	var reviews entities.Review
	err := r.GetDb(ctx).Where("created_by = ?", executorId).Where("restaurant_id = ?", restaurantId).First(&reviews).Error
	if err != nil {
		ctxLogger.Errorf("Failed to get reviews by created by: %v", err)
		return nil, err
	}

	return &reviews, nil
}
