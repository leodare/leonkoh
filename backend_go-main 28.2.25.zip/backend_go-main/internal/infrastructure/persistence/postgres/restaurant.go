package postgres

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"errors"
	"gorm.io/gorm"
)

type restaurant struct {
	repositories.Base[entities.Restaurant]
}

func NewRestaurantRepository(db *gorm.DB) repositories.Restaurant {
	return &restaurant{
		Base: NewBaseRepository[entities.Restaurant](db),
	}
}

func (r *restaurant) UpdateOverallRating(ctx context.Context, restaurantID string, rating float64) error {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx)
	err := db.Model(&entities.Restaurant{}).Where("id = ?", restaurantID).Update("overall_rating", rating).Error
	if err != nil {
		ctxLogger.Errorf("UpdateOverallRating err: %v", err)
		return err
	}
	return nil
}

func (r *restaurant) GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.RestaurantCondition) (*pagination.Pagination[entities.Restaurant], error) {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx)
	db = conditions.AddRestaurantCondition(db, condition)
	result, err := pagination.Paginate[entities.Restaurant](db, paging)
	if err != nil {
		ctxLogger.Errorf("GetPaginatedByCondition err: %v", err)
		return nil, err
	}
	return result, nil
}
func (r *restaurant) GetWithOtherById(ctx context.Context, restaurantID string) (*entities.Restaurant, error) {
	ctxLogger := logger.NewLogger(ctx)
	var restaurantDB entities.Restaurant
	db := r.GetDb(ctx)
	err := db.Model(&entities.Restaurant{}).Where("id = ?", restaurantID).Preload("RestaurantCuisineTypes").First(&restaurantDB).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, xerror.NewError(xerror.CodeDataNotFound)
		}
		ctxLogger.Errorf("Failed while get restaurant with other by id err: %v", err)
		return nil, err
	}
	return &restaurantDB, nil
}

func (r *restaurant) GetBatch(ctx context.Context, offset, limit int, preloads ...string) ([]entities.Restaurant, error) {
	ctxLogger := logger.NewLogger(ctx)
	var restaurants []entities.Restaurant
	db := r.GetDb(ctx)
	db = db.Offset(offset).Limit(limit)
	for _, preload := range preloads {
		db = db.Preload(preload)
	}
	err := db.Find(&restaurants).Error
	if err != nil {
		ctxLogger.Errorf("GetBatch err: %v", err)
		return nil, err
	}
	return restaurants, nil
}
