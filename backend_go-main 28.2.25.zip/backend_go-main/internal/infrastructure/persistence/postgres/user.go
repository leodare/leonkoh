package postgres

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
)

type user struct {
	repositories.Base[entities.User]
}

func (u *user) GetByCondition(ctx context.Context, condition conditions.UserConditions) ([]*entities.User, error) {
	ctxLogger := logger.NewLogger(ctx)
	db := u.GetDb(ctx)
	db = conditions.AddUserConditions(db, condition)
	var users []*entities.User
	if err := db.Find(&users).Error; err != nil {
		ctxLogger.Errorf("Failed to get blood products: %v", err)
		return nil, err
	}
	return users, nil
}

func (u *user) GetByConditionWithPaging(ctx context.Context, input pagination.Input, condition conditions.UserConditions) (*pagination.Pagination[entities.User], error) {
	ctxLogger := logger.NewLogger(ctx)
	db := u.GetDb(ctx)
	db = conditions.AddUserConditions(db, condition)
	paginatedData, err := pagination.Paginate[entities.User](db, input)
	if err != nil {
		ctxLogger.Errorf("Failed to get blood products with paging: %v", err)
		return nil, err
	}
	return paginatedData, nil
}

func (u *user) SetNeedVerify(ctx context.Context, userId string, needVerify bool) error {
	ctxLogger := logger.NewLogger(ctx)
	db := u.GetDb(ctx)
	if err := db.Model(&entities.User{}).Where("id = ?", userId).Update("need_verify", needVerify).Error; err != nil {
		ctxLogger.Errorf("Failed to set need verify: %v", err)
		return err
	}
	return nil
}

func NewUserRepository(db *gorm.DB) repositories.User {
	return &user{
		Base: NewBaseRepository[entities.User](db),
	}
}
