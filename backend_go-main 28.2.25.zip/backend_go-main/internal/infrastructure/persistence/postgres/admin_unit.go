package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
)

type adminUnit struct {
	repositories.Base[entities.AdminUnit]
}

func NewAdminUnitRepository(db *gorm.DB) repositories.AdminUnit {
	return &adminUnit{
		Base: NewBaseRepository[entities.AdminUnit](db),
	}
}

func (a *adminUnit) GetAll(ctx context.Context) ([]entities.AdminUnit, error) {
	var adminUnits []entities.AdminUnit
	db := a.GetDb(ctx)
	err := db.Find(&adminUnits).Error
	if err != nil {
		return nil, err
	}
	return adminUnits, nil
}

func (a *adminUnit) GetBatch(ctx context.Context, offset, limit int) ([]entities.AdminUnit, error) {
	var adminUnits []entities.AdminUnit
	db := a.GetDb(ctx)
	err := db.Offset(offset).Limit(limit).Find(&adminUnits).Error
	if err != nil {
		return nil, err
	}
	return adminUnits, nil
}

func (a *adminUnit) GetHierarchy(ctx context.Context, id string) ([]entities.AdminUnit, error) {
	ctxLogger := logger.NewLogger(ctx)
	var adminUnits []entities.AdminUnit
	db := a.GetDb(ctx)
	err := db.Raw(
		"WITH RECURSIVE AdminUnitHierarchy AS (\n"+
			"SELECT *\n"+
			"FROM admin_units\n"+
			"WHERE id = ?\n"+
			"UNION ALL\n"+
			"SELECT au.*\n"+
			"FROM admin_units au\n"+
			"INNER JOIN AdminUnitHierarchy ah ON au.id = ah.parent_id\n"+
			")\n"+
			"SELECT * FROM AdminUnitHierarchy", id).Scan(&adminUnits).Error
	if err != nil {
		ctxLogger.Errorf("GetHierarchy failed: %v", err)
		return nil, err
	}
	return adminUnits, nil
}

func (a *adminUnit) GetHierarchyByAddressId(ctx context.Context, addressId string) ([]entities.AdminUnit, error) {
	ctxLogger := logger.NewLogger(ctx)
	var adminUnits []entities.AdminUnit
	db := a.GetDb(ctx)
	err := db.Raw(
		"WITH RECURSIVE AdminUnitHierarchy AS (\n"+
			"SELECT *\n"+
			"FROM admin_units\n"+
			"WHERE id = (SELECT admin_unit_id FROM addresses WHERE id = ?)\n"+
			"UNION ALL\n"+
			"SELECT au.*\n"+
			"FROM admin_units au\n"+
			"INNER JOIN AdminUnitHierarchy ah ON au.id = ah.parent_id\n"+
			")\n"+
			"SELECT * FROM AdminUnitHierarchy", addressId).Scan(&adminUnits).Error
	if err != nil {
		ctxLogger.Errorf("GetHierarchyByAddressId failed: %v", err)
		return nil, err
	}
	return adminUnits, nil
}
