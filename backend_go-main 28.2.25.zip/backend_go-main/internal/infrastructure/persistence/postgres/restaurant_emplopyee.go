package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"gorm.io/gorm"
)

type restaurantEmployee struct {
	repositories.Base[entities.RestaurantEmployee]
}

func NewRestaurantEmployeeRepository(db *gorm.DB) repositories.RestaurantEmployee {
	return &restaurantEmployee{
		Base: NewBaseRepository[entities.RestaurantEmployee](db),
	}
}
