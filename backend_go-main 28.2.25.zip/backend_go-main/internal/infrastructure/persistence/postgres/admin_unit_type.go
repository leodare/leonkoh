package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"gorm.io/gorm"
)

type adminUnitType struct {
	repositories.Base[entities.AdminUnitType]
}

func NewAdminUnitTypeRepository(db *gorm.DB) repositories.AdminUnitType {
	return &adminUnitType{
		Base: NewBaseRepository[entities.AdminUnitType](db),
	}
}
