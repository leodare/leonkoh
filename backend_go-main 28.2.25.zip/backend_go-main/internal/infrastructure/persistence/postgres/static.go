package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"errors"
	"gorm.io/gorm"
)

type static struct {
	repositories.Base[entities.Static]
}

func NewStaticRepository(db *gorm.DB) repositories.Static {
	return &static{
		Base: NewBaseRepository[entities.Static](db),
	}
}
func (s *static) GetImageByUrl(ctx context.Context, url string) (*entities.Static, error) {
	ctxLogger := logger.NewLogger(ctx)
	var entity entities.Static

	db := s.GetDb(ctx).Where("url = ?", url)
	if err := db.First(&entity).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, xerror.NewError(xerror.CodeDataNotFound)
		}
		ctxLogger.Errorf("Failed to get entity by url: %v", err)
		return nil, err
	}
	return &entity, nil
}
