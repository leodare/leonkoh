package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"gorm.io/gorm"
)

type logRestaurantView struct {
	repositories.Base[entities.LogRestaurantView]
}

func NewLogRestaurantViewRepository(db *gorm.DB) repositories.LogRestaurantView {
	return &logRestaurantView{
		Base: NewBaseRepository[entities.LogRestaurantView](db),
	}
}
