package postgres

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
)

type smsTemplate struct {
	repositories.Base[entities.SMSTemplate]
}

func NewSMSTemplateRepository(db *gorm.DB) repositories.SmsTemplate {
	return &smsTemplate{
		Base: NewBaseRepository[entities.SMSTemplate](db),
	}
}

func (r *smsTemplate) GetByCondition(ctx context.Context, condition conditions.SMSTemplateConditions) ([]entities.SMSTemplate, error) {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx)
	db = conditions.AddSMSTemplateConditions(db, condition)
	var smsTemplates []entities.SMSTemplate
	if err := db.Find(&smsTemplates).Error; err != nil {
		ctxLogger.Errorf("Failed to get sms templates: %v", err)
		return nil, err
	}
	return smsTemplates, nil
}
