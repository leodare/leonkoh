package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
)

type restaurantAddress struct {
	repositories.Base[entities.RestaurantAddress]
}

func (r *restaurantAddress) DeleteByRestaurantID(ctx context.Context, restaurantID string) error {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx)
	err := db.Where("restaurant_id = ?", restaurantID).Delete(&entities.RestaurantAddress{}).Error
	if err != nil {
		ctxLogger.Errorf("DeleteByRestaurantID err: %v", err)
		return err
	}
	return nil
}

func NewRestaurantAddressRepository(db *gorm.DB) repositories.RestaurantAddress {
	return &restaurantAddress{
		Base: NewBaseRepository[entities.RestaurantAddress](db),
	}
}
