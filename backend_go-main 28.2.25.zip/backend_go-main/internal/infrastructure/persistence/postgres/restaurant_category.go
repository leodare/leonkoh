package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
)

type restaurantCategory struct {
	repositories.Base[entities.RestaurantCategory]
}

func (r *restaurantCategory) DeleteByRestaurantID(ctx context.Context, restaurantID string) error {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx)
	err := db.Where("restaurant_id = ?", restaurantID).Delete(&entities.RestaurantCategory{}).Error
	if err != nil {
		ctxLogger.Errorf("DeleteByRestaurantID err: %v", err)
		return err
	}
	return nil
}

func NewRestaurantCategoryRepository(db *gorm.DB) repositories.RestaurantCategory {
	return &restaurantCategory{
		Base: NewBaseRepository[entities.RestaurantCategory](db),
	}
}
