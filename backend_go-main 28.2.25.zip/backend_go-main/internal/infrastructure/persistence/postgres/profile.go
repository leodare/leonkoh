package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/logger"
	x_error "backend/pkg/x-error"
	"context"
	"errors"
	"gorm.io/gorm"
)

type profile struct {
	repositories.Base[entities.Profile]
}

func NewProfileRepository(db *gorm.DB) repositories.Profile {
	return &profile{
		Base: NewBaseRepository[entities.Profile](db),
	}
}

func (p *profile) GetByUserId(ctx context.Context, userId string) (*entities.Profile, error) {
	ctxLogger := logger.NewLogger(ctx)

	var profileInDB entities.Profile
	err := p.GetDb(ctx).Where("user_id = ?", userId).First(&profileInDB).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, x_error.NewError(x_error.CodeDataNotFound)
		}
		ctxLogger.Errorf("Failed to get profile by user ID: %v", err)
		return nil, err
	}
	if profileInDB.ID == "" {
		return nil, x_error.NewError(x_error.CodeDataNotFound)
	}
	return &profileInDB, nil
}
func (p *profile) GetByUserIds(ctx context.Context, userIds []string) ([]entities.Profile, error) {
	ctxLogger := logger.NewLogger(ctx)

	var profileInDB []entities.Profile
	err := p.GetDb(ctx).Where("user_id in (?)", userIds).Find(&profileInDB).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, x_error.NewError(x_error.CodeDataNotFound)
		}
		ctxLogger.Errorf("Failed to get profile by user ID: %v", err)
		return nil, err
	}
	if len(profileInDB) == 0 {
		return nil, x_error.NewError(x_error.CodeDataNotFound)
	}
	return profileInDB, nil
}
