package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
	"time"
)

type reviewStatic struct {
	repositories.Base[entities.ReviewStatic]
}

func NewReviewStaticRepository(db *gorm.DB) repositories.ReviewStatic {
	return &reviewStatic{
		Base: NewBaseRepository[entities.ReviewStatic](db),
	}
}

func (r reviewStatic) GetRecordsByReviewID(ctx context.Context, reviewID string) ([]entities.ReviewStatic, error) {
	ctxLogger := logger.NewLogger(ctx)

	var records []entities.ReviewStatic
	if err := r.GetDb(ctx).Where("review_id = ?", reviewID).Find(&records).Error; err != nil {
		ctxLogger.Errorf("Failed to get records by review ID: %v", err)
		return nil, err
	}

	return records, nil
}
func (r reviewStatic) DeleteByReviewID(ctx context.Context, reviewID string) error {
	ctxLogger := logger.NewLogger(ctx)
	var entity entities.ReviewStatic

	db := r.GetDb(ctx).Model(&entity).Where("review_id = ?", reviewID)
	now := time.Now()

	err := db.Update("deleted_at", &now).Error
	if err != nil {
		ctxLogger.Errorf("Failed to delete review static by review id: %v", err)
		return err
	}
	return nil
}
