package pagination

import (
	"backend/pkg/utils"
	"fmt"
	"gorm.io/gorm"
	"math"
)

// Paginate function for GORM that returns paginated results.
func Paginate[T any](db *gorm.DB, input Input) (*Pagination[T], error) {
	var totalItems int64
	var result []T
	var model T

	// Calculate offset for pagination

	// Get total count of items
	if err := db.Model(&model).Count(&totalItems).Error; err != nil {
		return nil, err
	}

	page, limit := utils.GetDefaultPagination(input.Page, input.Limit)
	offset := (page - 1) * input.Limit

	// Query data with limit and offset
	if limit == 0 {
		limit = int(totalItems)
	}

	if err := db.Limit(limit).Offset(offset).Find(&result).Error; err != nil {
		return nil, err
	}

	// Calculate total pages
	totalPages := int(math.Ceil(float64(totalItems) / float64(limit)))

	// Prepare paginated response
	paginatedResult := &Pagination[T]{
		Data: result,
		Meta: Meta{
			ItemsPerPage: limit,
			TotalItems:   totalItems,
			CurrentPage:  page,
			TotalPages:   totalPages,
		},
	}

	return paginatedResult, nil
}

func PaginateWithDistinct[T any](db *gorm.DB, input Input, distinctColumn string) (*Pagination[T], error) {
	var (
		totalItems int64
		result     []T
		model      T
	)

	page, limit := utils.GetDefaultPagination(input.Page, input.Limit)
	offset := (page - 1) * input.Limit

	dbCount := db.Model(&model).Session(&gorm.Session{})

	if err := dbCount.
		Select(fmt.Sprintf("COUNT(DISTINCT %s)", distinctColumn)).
		Count(&totalItems).Error; err != nil {
		return nil, err
	}

	if limit == 0 {
		limit = int(totalItems)
	}

	if err := db.Limit(limit).Offset(offset).Find(&result).Error; err != nil {
		return nil, err
	}

	totalPages := int(math.Ceil(float64(totalItems) / float64(limit)))

	paginatedResult := &Pagination[T]{
		Data: result,
		Meta: Meta{
			ItemsPerPage: limit,
			TotalItems:   totalItems,
			CurrentPage:  page,
			TotalPages:   totalPages,
		},
	}

	return paginatedResult, nil
}
