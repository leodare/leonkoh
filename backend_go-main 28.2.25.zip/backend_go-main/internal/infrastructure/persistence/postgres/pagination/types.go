package pagination

const (
	DefaultPage  = 1
	DefaultLimit = 1000000000
)

type Input struct {
	Page  int `json:"page" form:"page"`
	Limit int `json:"limit" form:"limit"`
}

type Pagination[T any] struct {
	Data []T  `json:"data"`
	Meta Meta `json:"meta"`
}

type Meta struct {
	ItemsPerPage int   `json:"items_per_page"`
	TotalItems   int64 `json:"total_items"`
	CurrentPage  int   `json:"current_page"`
	TotalPages   int   `json:"total_pages"`
}
