package postgres

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"gorm.io/gorm"
)

type userFollow struct {
	repositories.Base[entities.UserFollow]
}

func NewUserFollowRepository(db *gorm.DB) repositories.UserFollow {
	return &userFollow{
		Base: NewBaseRepository[entities.UserFollow](db),
	}
}
func (r *userFollow) GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.UserFollowCondition) (*pagination.Pagination[entities.UserFollow], error) {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx)
	db = conditions.AddUserFollowCondition(db, condition)
	result, err := pagination.Paginate[entities.UserFollow](db, paging)
	if err != nil {
		ctxLogger.Errorf("GetPaginatedByCondition err: %v", err)
		return nil, err
	}
	return result, nil
}
