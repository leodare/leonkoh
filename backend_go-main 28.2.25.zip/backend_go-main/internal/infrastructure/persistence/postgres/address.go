package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"context"
	"gorm.io/gorm"
)

type address struct {
	repositories.Base[entities.Address]
}

func NewAddressRepository(db *gorm.DB) repositories.Address {
	return &address{
		Base: NewBaseRepository[entities.Address](db),
	}
}

func (a *address) GetAll(ctx context.Context) ([]entities.Address, error) {
	var addresses []entities.Address
	db := a.GetDb(ctx)
	err := db.Find(&addresses).Error
	if err != nil {
		return nil, err
	}
	return addresses, nil
}

func (a *address) GetBatch(ctx context.Context, offset, limit int) ([]entities.Address, error) {
	var addresses []entities.Address
	db := a.GetDb(ctx)
	err := db.Offset(offset).Limit(limit).Find(&addresses).Error
	if err != nil {
		return nil, err
	}
	return addresses, nil
}
