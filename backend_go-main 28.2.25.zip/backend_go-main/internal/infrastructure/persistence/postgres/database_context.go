package postgres

import (
	"fmt"
	"github.com/spf13/viper"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"sync"
)

var lock sync.Mutex

type DBConfig struct {
	Driver   string `json:"driver,omitempty" yaml:"driver"`
	User     string `json:"user,omitempty" yaml:"user"`
	Password string `json:"password,omitempty" yaml:"password"`
	Protocol string `json:"protocol,omitempty" yaml:"protocol"`
	Host     string `json:"host,omitempty" yaml:"host"`
	Port     string `json:"port,omitempty" yaml:"port"`
	Schema   string `json:"schema,omitempty" yaml:"schema"`
}

var instance *gorm.DB

func getDbConfig() *DBConfig {
	dbConfig := &DBConfig{}
	if err := viper.UnmarshalKey("database", dbConfig); err != nil {
		panic(err)
	}
	return dbConfig
}

func GetDBContext() *gorm.DB {
	if instance == nil {
		lock.Lock()
		defer lock.Unlock()
		if instance == nil {
			dbConfig := getDbConfig()
			dbSource := fmt.Sprintf(
				"user=%s password=%s host=%s port=%s dbname=%s sslmode=disable",
				dbConfig.User,
				dbConfig.Password,
				dbConfig.Host,
				dbConfig.Port,
				dbConfig.Schema,
			)
			gormConfig := &gorm.Config{
				Logger: logger.Default.LogMode(logger.Info),
			}
			db, err := gorm.Open(postgres.Open(dbSource), gormConfig)

			if err != nil {
				panic(err)
			}
			isDebug := viper.GetBool("is_debug")
			if isDebug {
				db = db.Debug()
			}

			sqlDB, err := db.DB()
			if err != nil {
				panic(err)
			}
			sqlDB.SetMaxIdleConns(10)
			sqlDB.SetMaxOpenConns(20)
			stats := sqlDB.Stats()
			_ = stats
			instance = db
		}
	}
	return instance
}
