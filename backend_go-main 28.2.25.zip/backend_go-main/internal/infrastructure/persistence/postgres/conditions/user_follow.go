package conditions

import (
	"backend/internal/entities"
	"gorm.io/gorm"
)

type UserFollowCondition struct {
	UserFollow entities.UserFollow
	Options    AdditionalUserFollowCondition
	Sorting    []Sorting
	Preloads   []Preload
}

type AdditionalUserFollowCondition struct {
	Latest bool
}

func AddUserFollowCondition(db *gorm.DB, c UserFollowCondition) *gorm.DB {
	if c.UserFollow.FollowerID != "" {
		db = db.Where("follower_id = ?", c.UserFollow.FollowerID)
	}
	if c.UserFollow.FollowedID != "" {
		db = db.Where("followed_id = ?", c.UserFollow.FollowedID)
	}
	if len(c.Preloads) > 0 {
		db = addPreload(db, c.Preloads)
	}
	if len(c.Sorting) > 0 {
		db = addSorting(db, c.Sorting)
	}
	if c.Options.Latest {
		db = db.Order("created_at DESC")
	} else {
		db = db.Order("created_at ASC")
	}

	return db
}
