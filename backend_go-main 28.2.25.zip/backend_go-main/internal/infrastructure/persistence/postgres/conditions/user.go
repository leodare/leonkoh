package conditions

import (
	"backend/internal/entities"
	"gorm.io/gorm"
)

type UserOptions struct {
	ExceptIDs []string
	OrEqPhone *string
	OrEqEmail *string
}

type UserConditions struct {
	User    entities.User
	Options UserOptions
}

func NewUserConditions() *UserConditions {
	return &UserConditions{}
}

func (u *UserConditions) WithID(id string) *UserConditions {
	u.User.ID = id
	return u
}

func (u *UserConditions) WithUsername(username string) *UserConditions {
	u.User.Username = username
	return u
}

func (u *UserConditions) WithEmail(email string) *UserConditions {
	u.User.Email = &email
	return u
}

func (u *UserConditions) WithPhone(phone string) *UserConditions {
	u.User.Phone = phone
	return u
}

func (u *UserConditions) WithExceptIDs(ids []string) *UserConditions {
	u.Options.ExceptIDs = ids
	return u
}

func (u *UserConditions) WithOrEqPhone(phone *string) *UserConditions {
	u.Options.OrEqPhone = phone
	return u
}

func (u *UserConditions) WithOrEqEmail(email *string) *UserConditions {
	u.Options.OrEqEmail = email
	return u
}

func AddUserConditions(db *gorm.DB, conditions UserConditions) *gorm.DB {
	if conditions.User.ID != "" {
		db = db.Where("id = ?", conditions.User.ID)
	}

	if conditions.User.Username != "" {
		db = db.Where("username = ?", conditions.User.Username)
	}

	if conditions.User.Email != nil && *conditions.User.Email != "" {
		db = db.Where("email = ?", *conditions.User.Email)
	}

	if conditions.User.Phone != "" {
		db = db.Where("phone = ?", conditions.User.Phone)
	}

	if conditions.Options.ExceptIDs != nil {
		db = db.Where("id NOT IN ?", conditions.Options.ExceptIDs)
	}

	if conditions.Options.OrEqPhone != nil {
		db = db.Or("phone = ?", *conditions.Options.OrEqPhone)
	}

	if conditions.Options.OrEqEmail != nil {
		db = db.Or("email = ?", *conditions.Options.OrEqEmail)
	}

	return db
}
