package conditions

import (
	"backend/internal/entities"
	"gorm.io/gorm"
)

type CuisineTypeCondition struct {
	CuisineType entities.CuisineType
	Options     AdditionalCuisineTypeCondition
}

type AdditionalCuisineTypeCondition struct {
}

func AddCuisineTypeCondition(db *gorm.DB, c CuisineTypeCondition) *gorm.DB {
	if c.CuisineType.Name != "" {
		db = db.Where("name like ?", "%"+c.CuisineType.Name+"%")
	}
	return db
}
