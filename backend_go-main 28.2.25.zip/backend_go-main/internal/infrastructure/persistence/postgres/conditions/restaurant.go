package conditions

import (
	"backend/internal/entities"
	"gorm.io/gorm"
)

type RestaurantCondition struct {
	Restaurant entities.Restaurant
	Options    AdditionalRestaurantCondition
}
type AdditionalRestaurantCondition struct {
	Ids      []string
	Preloads []PreloadOption
}

func (c *RestaurantCondition) WithPreload(preload ...string) *RestaurantCondition {
	for _, p := range preload {
		c.Options.Preloads = append(c.Options.Preloads, PreloadOption{Preload: p})
	}
	return c
}
func (c *RestaurantCondition) WithIds(ids ...string) *RestaurantCondition {
	c.Options.Ids = ids
	return c
}

func AddRestaurantCondition(db *gorm.DB, c RestaurantCondition) *gorm.DB {
	if c.Restaurant.Name != "" {
		db = db.Where("name like ?", "%"+c.Restaurant.Name+"%")
	}
	if len(c.Options.Ids) > 0 {
		db = db.Where("id in (?)", c.Options.Ids)
	}
	if len(c.Options.Preloads) > 0 {
		for _, preload := range c.Options.Preloads {
			db = db.Preload(preload.Preload, preload.Args...)
		}
	}
	return db
}
