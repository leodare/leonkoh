package conditions

import (
	"fmt"
	"gorm.io/gorm"
	"strings"
)

type PreloadOption struct {
	Preload string
	Args    []interface{}
}

func stringToILikeQuery(query string) string {
	return fmt.Sprintf("%%%s%%", strings.ToLower(query))
}

type OrderDirection string

const (
	OrderASC  OrderDirection = "ASC"
	OrderDESC OrderDirection = "DESC"
)

type Sorting struct {
	Field string
	Order OrderDirection
}

type Preload struct {
	Field string
	Args  []interface{}
}

func addSorting(db *gorm.DB, sorting []Sorting) *gorm.DB {
	for _, s := range sorting {
		db = db.Order(fmt.Sprintf("%s %s", s.Field, s.Order))
	}
	return db
}

func addPreload(db *gorm.DB, preloads []Preload) *gorm.DB {
	for _, preload := range preloads {
		db = db.Preload(preload.Field)
	}
	return db
}
