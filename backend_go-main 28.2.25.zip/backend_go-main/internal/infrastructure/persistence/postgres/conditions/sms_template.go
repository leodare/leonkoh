package conditions

import (
	"backend/internal/entities"
	"gorm.io/gorm"
)

type SMSTemplateOptions struct {
	ExceptIDs []string
}

type SMSTemplateConditions struct {
	SMSTemplate entities.SMSTemplate
	Options     SMSTemplateOptions
}

func NewSMSTemplateConditions() *SMSTemplateConditions {
	return &SMSTemplateConditions{}
}

func (s *SMSTemplateConditions) WithCode(code string) *SMSTemplateConditions {
	s.SMSTemplate.Code = code
	return s
}

func (s *SMSTemplateConditions) WithName(name string) *SMSTemplateConditions {
	s.SMSTemplate.Name = name
	return s
}

func (s *SMSTemplateConditions) WithExceptIDs(ids []string) *SMSTemplateConditions {
	s.Options.ExceptIDs = ids
	return s
}

func AddSMSTemplateConditions(db *gorm.DB, conditions SMSTemplateConditions) *gorm.DB {
	if conditions.SMSTemplate.Code != "" {
		db = db.Where("code = ?", conditions.SMSTemplate.Code)
	}
	if conditions.SMSTemplate.Name != "" {
		db = db.Where("name = ?", conditions.SMSTemplate.Name)
	}
	if len(conditions.Options.ExceptIDs) > 0 {
		db = db.Not("id IN (?)", conditions.Options.ExceptIDs)
	}
	return db
}
