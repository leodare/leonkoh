package conditions

import (
	"backend/internal/entities"
	"gorm.io/gorm"
)

type ReviewCondition struct {
	Review  entities.Review
	Options AdditionalReviewCondition
	Sorting []Sorting
}

type AdditionalReviewCondition struct {
	Latest bool
}

func AddReviewCondition(db *gorm.DB, c ReviewCondition) *gorm.DB {
	if c.Review.RestaurantID != "" {
		db = db.Where("restaurant_id = ?", c.Review.RestaurantID)
	}
	db = db.Preload("ReviewStatics")
	if len(c.Sorting) > 0 {
		for _, s := range c.Sorting {
			db = db.Order(s.Field + " " + string(s.Order))
		}
	}
	//db = addSorting(db, c.Sorting)

	return db
}
