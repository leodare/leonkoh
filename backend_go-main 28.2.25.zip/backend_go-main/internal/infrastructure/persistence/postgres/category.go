package postgres

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"errors"
	"gorm.io/gorm"
	"strings"
)

type category struct {
	repositories.Base[entities.Category]
}

func NewCategoryRepository(db *gorm.DB) repositories.Category {
	return &category{
		Base: NewBaseRepository[entities.Category](db),
	}
}

func (c category) GetByName(ctx context.Context, name string) (*entities.Category, error) {
	ctxLogger := logger.NewLogger(ctx)

	var result entities.Category
	err := c.GetDb(ctx).Where("LOWER(name) = ?", strings.ToLower(name)).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		ctxLogger.Errorf("Failed to get category by name: %v", err)
		return nil, err
	}

	return &result, nil
}

func (c category) GetList(ctx context.Context, paging pagination.Input) (*pagination.Pagination[entities.Category], error) {
	ctxLogger := logger.NewLogger(ctx)

	db := c.GetDb(ctx)

	result, err := pagination.Paginate[entities.Category](db, paging)
	if err != nil {
		ctxLogger.Errorf("GetList categories err: %v", err)
		return nil, err
	}

	return result, nil
}
