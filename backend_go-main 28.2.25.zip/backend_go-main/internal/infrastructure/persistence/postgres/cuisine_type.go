package postgres

import (
	"backend/internal/entities"
	"backend/internal/infrastructure/persistence/postgres/conditions"
	"backend/internal/infrastructure/persistence/postgres/pagination"
	"backend/internal/repositories"
	"backend/pkg/logger"
	"context"
	"errors"
	"gorm.io/gorm"
)

type cuisineType struct {
	repositories.Base[entities.CuisineType]
}

func NewCuisineTypeRepository(db *gorm.DB) repositories.CuisineType {
	return &cuisineType{
		Base: NewBaseRepository[entities.CuisineType](db),
	}
}

func (c *cuisineType) GetPaginatedByCondition(ctx context.Context, paging pagination.Input, condition conditions.CuisineTypeCondition) (*pagination.Pagination[entities.CuisineType], error) {
	ctxLogger := logger.NewLogger(ctx)

	db := conditions.AddCuisineTypeCondition(c.GetDb(ctx), condition)
	result, err := pagination.Paginate[entities.CuisineType](db, paging)
	if err != nil {
		ctxLogger.Errorf("GetPaginatedByCondition err: %v", err)
		return nil, err
	}
	return result, nil
}

func (c *cuisineType) GetByName(ctx context.Context, name string) (*entities.CuisineType, error) {
	ctxLogger := logger.NewLogger(ctx)

	var result entities.CuisineType
	err := c.GetDb(ctx).Where("name = ?", name).First(&result).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		ctxLogger.Errorf("Failed to get cuisine type by name: %v", err)
		return nil, err
	}

	return &result, nil
}
