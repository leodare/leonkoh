package postgres

import (
	"backend/internal/entities"
	"backend/internal/repositories"
	"gorm.io/gorm"
)

type smsLog struct {
	repositories.Base[entities.SMSLog]
}

func NewSMSLogRepository(db *gorm.DB) repositories.SmsLog {
	return &smsLog{
		Base: NewBaseRepository[entities.SMSLog](db),
	}
}
