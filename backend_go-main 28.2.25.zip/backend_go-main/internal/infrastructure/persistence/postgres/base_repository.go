package postgres

import (
	"backend/internal/repositories"
	"backend/pkg/logger"
	psqlhelper "backend/pkg/psql-helpler"
	xerror "backend/pkg/x-error"
	"context"
	"errors"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"time"
)

// baseRepository is a generic struct that implements Base.
type baseRepository[T any] struct {
	db *gorm.DB
}

// NewBaseRepository creates a new instance of baseRepository.
func NewBaseRepository[T any](db *gorm.DB) repositories.Base[T] {
	return &baseRepository[T]{db: db}
}

// GetDb get gorm database.
func (r *baseRepository[T]) GetDb(ctx context.Context) *gorm.DB {
	return psqlhelper.GetTransactionDB(ctx, r.db)
}

// Create inserts a new entity into the database.
func (r *baseRepository[T]) Create(ctx context.Context, entity *T) (*string, error) {
	ctxLogger := logger.NewLogger(ctx)
	id, err := psqlhelper.Insert(ctx, r.GetDb(ctx), entity)
	if err != nil {
		ctxLogger.Errorf("Failed to create entity: %v", err)
		return nil, err
	}
	return id, nil
}

// CreateMany inserts new entities into the database.
func (r *baseRepository[T]) CreateMany(ctx context.Context, entities []*T) ([]string, error) {
	ctxLogger := logger.NewLogger(ctx)

	ids, err := psqlhelper.InsertMultiple(ctx, r.GetDb(ctx), entities)
	if err != nil {
		ctxLogger.Errorf("Failed to create entities: %v", err)
		return nil, err
	}
	return ids, nil
}

// Update updates an existing entity in the database.
func (r *baseRepository[T]) Update(ctx context.Context, entity *T) error {
	ctxLogger := logger.NewLogger(ctx)
	err := r.GetDb(ctx).Updates(entity).Error

	if err != nil {
		ctxLogger.Errorf("Failed to update entity: %v", err)
		return err
	}
	return nil
}

// UpdateMany updates an existing entity in the database.
func (r *baseRepository[T]) UpdateMany(ctx context.Context, ids []string, entity T) error {
	ctxLogger := logger.NewLogger(ctx)
	db := r.GetDb(ctx).Model(&entity).Where("id IN ?", ids)
	err := db.Updates(entity).Error
	if err != nil {
		ctxLogger.Errorf("Failed to update entity: %v", err)
		return err
	}
	return nil
}

// GetByID fetches an entity by its ID.
func (r *baseRepository[T]) GetByID(ctx context.Context, id string) (*T, error) {
	ctxLogger := logger.NewLogger(ctx)
	var entity T

	db := r.GetDb(ctx).Where("id = ?", id)
	if err := db.First(&entity).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, xerror.NewError(xerror.CodeDataNotFound)
		}
		ctxLogger.Errorf("Failed to get entity by ID: %v", err)
		return nil, err
	}
	return &entity, nil
}

// GetByIDs fetches entities by its IDs.
func (r *baseRepository[T]) GetByIDs(ctx context.Context, id []string) ([]T, error) {
	ctxLogger := logger.NewLogger(ctx)
	var entities []T
	db := r.GetDb(ctx).Where("id IN ?", id)
	if err := db.Find(&entities).Error; err != nil {
		ctxLogger.Errorf("Failed to get entities by IDs: %v", err)
		return nil, err
	}
	return entities, nil
}

// Delete performs a soft delete by setting the "deleted_at" field to the current time.
func (r *baseRepository[T]) Delete(ctx context.Context, id string) error {
	ctxLogger := logger.NewLogger(ctx)
	var entity T

	db := r.GetDb(ctx).Model(&entity).Where("id = ?", id)
	now := time.Now()

	err := db.Update("deleted_at", &now).Error
	if err != nil {
		ctxLogger.Errorf("Failed to delete entity: %v", err)
		return err
	}
	return nil
}

// DeleteMany performs a soft delete by setting the "deleted_at" field to the current time.
func (r *baseRepository[T]) DeleteMany(ctx context.Context, id []string) error {
	ctxLogger := logger.NewLogger(ctx)
	var entity T
	db := r.GetDb(ctx).Model(&entity).Where("id IN ?", id)
	now := time.Now()

	err := db.Update("deleted_at", &now).Error
	if err != nil {
		ctxLogger.Errorf("Failed to delete entities: %v", err)
		return err
	}
	return nil
}

// Upsert inserts or updates an entity in the database.
func (r *baseRepository[T]) Upsert(ctx context.Context, entity *T, conflictColumns []string, updateColumns []string) error {
	ctxLogger := logger.NewLogger(ctx) // Khởi tạo logger
	db := r.GetDb(ctx)

	var columns []clause.Column
	for _, col := range conflictColumns {
		columns = append(columns, clause.Column{Name: col})
	}

	err := db.Model(&entity).Clauses(clause.OnConflict{
		Columns:   columns,                                 // Danh sách các cột xung đột
		DoUpdates: clause.AssignmentColumns(updateColumns), // Danh sách cột cần cập nhật
	}).Create(entity).Error

	if err != nil {
		ctxLogger.Errorw("msg", "Failed to upsert entity", "error", err)
		return err
	}

	return nil
}
