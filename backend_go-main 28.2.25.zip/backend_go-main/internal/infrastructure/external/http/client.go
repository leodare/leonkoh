package http

import (
	"backend/pkg/logger"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type client struct {
	client  *http.Client
	baseURL string
}

func NewHttpClient(baseURL string, timeout time.Duration) Client {
	return &client{
		client: &http.Client{
			Timeout: timeout,
		},
		baseURL: baseURL,
	}
}

func (c *client) buildURL(endpoint string, params map[string]string) (string, error) {
	fullURL := c.baseURL + endpoint
	if params != nil && len(params) > 0 {
		urlObj, err := url.Parse(fullURL)
		if err != nil {
			return "", fmt.Errorf("failed to parse URL: %v", err)
		}
		query := urlObj.Query()
		for key, value := range params {
			query.Add(key, value)
		}
		urlObj.RawQuery = query.Encode()
		fullURL = urlObj.String()
	}
	return fullURL, nil
}

func (c *client) Get(ctx context.Context, endpoint string, params map[string]string, headers map[string]string) (*http.Response, error) {
	ctxLogger := logger.NewLogger(ctx)
	fullURL, err := c.buildURL(endpoint, params)
	if err != nil {
		ctxLogger.Errorf("failed to build URL: %v", err)
		return nil, err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, fullURL, nil)
	if err != nil {
		ctxLogger.Errorf("failed to create GET request: %v", err)
		return nil, err
	}

	// Set headers
	for key, value := range headers {
		req.Header.Set(key, value)
	}

	resp, err := c.client.Do(req)
	if err != nil {
		ctxLogger.Errorf("failed to send GET request: %v", err)
		return nil, err
	}
	return resp, nil
}

func (c *client) Post(ctx context.Context, endpoint string, body interface{}, headers map[string]string) (*http.Response, error) {
	return c.sendWithBody(ctx, http.MethodPost, endpoint, body, headers)
}

func (c *client) Put(ctx context.Context, endpoint string, body interface{}, headers map[string]string) (*http.Response, error) {
	return c.sendWithBody(ctx, http.MethodPut, endpoint, body, headers)
}

func (c *client) Delete(ctx context.Context, endpoint string, params map[string]string, headers map[string]string) (*http.Response, error) {
	fullURL, err := c.buildURL(endpoint, params)
	if err != nil {
		return nil, fmt.Errorf("failed to build URL: %v", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodDelete, fullURL, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create DELETE request: %v", err)
	}

	// Set headers
	for key, value := range headers {
		req.Header.Set(key, value)
	}

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to send DELETE request: %v", err)
	}
	return resp, nil
}

func (c *client) sendWithBody(ctx context.Context, method string, endpoint string, body interface{}, headers map[string]string) (*http.Response, error) {
	ctxLogger := logger.NewLogger(ctx)
	var bodyReader io.Reader

	if body != nil {
		jsonBody, err := json.Marshal(body)
		if err != nil {
			ctxLogger.Errorf("failed to marshal body: %v", err)
			return nil, err
		}
		bodyReader = bytes.NewBuffer(jsonBody)
	}

	req, err := http.NewRequestWithContext(ctx, method, c.baseURL+endpoint, bodyReader)
	if err != nil {
		ctxLogger.Errorf("failed to create %s request: %v", strings.ToUpper(method), err)
		return nil, err
	}

	// Set headers
	for key, value := range headers {
		req.Header.Set(key, value)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		ctxLogger.Errorf("failed to send %s request: %v", strings.ToUpper(method), err)
		return nil, err
	}
	return resp, nil
}

// Helper function để parse JSON response
func ParseJSONResponse(ctx context.Context, resp *http.Response, out interface{}) error {
	ctxLogger := logger.NewLogger(ctx)
	defer resp.Body.Close()

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		ctxLogger.Errorf("failed to read response body: %v", err)
		return err
	}

	if err := json.Unmarshal(bodyBytes, out); err != nil {
		ctxLogger.Errorf("failed to unmarshal response body: %v", err)
		return err
	}

	return nil
}
