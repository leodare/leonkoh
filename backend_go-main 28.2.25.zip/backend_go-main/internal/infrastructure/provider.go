package infrastructure

import (
	"backend/internal/infrastructure/caching"
	"backend/internal/infrastructure/external/http"
	"backend/internal/infrastructure/persistence/postgres"
	postgres2 "backend/internal/infrastructure/persistence/postgres/migration"
	"backend/internal/infrastructure/searching"
	"backend/internal/infrastructure/sms/twilio"
	"backend/internal/infrastructure/storage"
	"github.com/google/wire"
)

var DBProvider = wire.NewSet(
	postgres.NewReviewStaticRepository,
	postgres.NewReviewRepository,
	postgres.NewCuisineTypeRepository,
	postgres.NewStaticRepository,
	postgres.NewRestaurantRepository,
	postgres.GetDBContext,
	postgres2.NewPSQLMigration,
	postgres.NewUserRepository,
	postgres.NewSMSTemplateRepository,
	postgres.NewSMSLogRepository,
	postgres.NewAddressRepository,
	postgres.NewCategoryRepository,
	postgres.NewAdminUnitRepository,
	postgres.NewAdminUnitTypeRepository,
	postgres.NewRestaurantCategoryRepository,
	postgres.NewRestaurantEmployeeRepository,
	postgres.NewRestaurantAddressRepository,
	postgres.NewProfileRepository,
	postgres.NewUserFollowRepository,
	postgres.NewLogRestaurantViewRepository,
)

var ExternalProvider = wire.NewSet(
	http.NewHttpClient,
	storage.NewService,
)

var CacheProvider = wire.NewSet(
	caching.CreateMemoryStore,
)

var SMSProvider = wire.NewSet(
	twilio.NewTwilio,
)

var SearchEngineProvider = wire.NewSet(
	searching.NewSearchEngine,
)
