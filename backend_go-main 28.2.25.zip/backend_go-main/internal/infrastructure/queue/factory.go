package queue

import (
	"backend/internal/infrastructure/queue/interface"
	"backend/internal/infrastructure/queue/kafka"
	"backend/internal/infrastructure/queue/rabbitmq"
)

type Type string

const (
	RabbitMQ Type = "rabbitmq"
	Kafka    Type = "kafka"
)

type Config struct {
	Type           Type
	RabbitMQConfig *_interface.RabbitMQConfig
	KafkaConfig    *_interface.KafkaConfig
}

func New(config *Config) (_interface.Queue, error) {
	switch config.Type {
	case RabbitMQ:
		return rabbitmq.New(config.RabbitMQConfig)
	case Kafka:
		return kafka.New(config.KafkaConfig)
	default:
		panic("invalid queue type")
	}
}
