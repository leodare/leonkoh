package _interface

import (
	"context"
	"time"
)

type Message struct {
	Id   *string
	Key  interface{}
	Data interface{}
	Meta map[string]interface{}
}

type Handler func(ctx context.Context, message *Message) (Response, error)

type Response int

const (
	Success Response = 0
	Failed  Response = 1
	Retry   Response = 2
)

type RabbitMQConfig struct {
	URL                string
	MaxTryTimes        int32
	DeadLetterExchange string
	PrefetchCount      int
	RetryDelay         *time.Duration
}

type ExchangeKind string

const (
	Fanout ExchangeKind = "fanout"
	Direct ExchangeKind = "direct"
	Topic  ExchangeKind = "topic"
)

type RabbitTopicOption struct {
	ExchangeName string
	QueueName    string
	RoutingKey   string
	Kind         *ExchangeKind
}

type KafkaConfig struct {
	Brokers         []string
	GroupID         string
	MaxRetry        int
	RetryDelay      *time.Duration
	DeadLetterTopic string
	RetryTopic      *string
	CommitInterval  time.Duration
}

type KafkaTopicOption struct {
	TopicName         string
	NumPartitions     int
	ReplicationFactor int
}

type TopicOption struct {
	RabbitTopicOption *RabbitTopicOption
	KafkaTopicOption  *KafkaTopicOption
}
