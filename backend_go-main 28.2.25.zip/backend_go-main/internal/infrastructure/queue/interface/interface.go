package _interface

import (
	"context"
)

type Queue interface {
	CreateTopic(ctx context.Context, topicOption TopicOption) error
	Publish(ctx context.Context, topic string, message *Message) error
	Consume(ctx context.Context, topic string, handler Handler) error
	Close(ctx context.Context) error
}
