package kafka

import (
	"backend/internal/infrastructure/queue/interface"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/google/uuid"
	"github.com/segmentio/kafka-go"
	"strconv"
	"sync"
	"time"
)

type kafkaQueue struct {
	config      *_interface.KafkaConfig
	writer      *kafka.Writer
	readers     map[string]*kafka.Reader
	cancelFuncs map[string]context.CancelFunc
	mu          sync.Mutex
}

func New(config *_interface.KafkaConfig) (_interface.Queue, error) {
	if len(config.Brokers) == 0 {
		return nil, xerror.NewError(xerror.KafkaBrokersRequired)
	}

	writer := &kafka.Writer{
		Addr:         kafka.TCP(config.Brokers...),
		Balancer:     &kafka.Hash{},
		Async:        false,
		RequiredAcks: kafka.RequireAll,
	}

	return &kafkaQueue{
		config:      config,
		writer:      writer,
		readers:     make(map[string]*kafka.Reader),
		cancelFuncs: make(map[string]context.CancelFunc),
	}, nil
}

func (q *kafkaQueue) CreateTopic(ctx context.Context, topicOption _interface.TopicOption) error {
	ctxLogger := logger.NewLogger(ctx)
	if topicOption.KafkaTopicOption == nil {
		return xerror.NewError(xerror.KafkaTopicOptionRequired)
	}
	if topicOption.KafkaTopicOption.TopicName == "" {
		return xerror.NewError(xerror.KafkaTopicNameRequired)
	}
	if topicOption.KafkaTopicOption.NumPartitions <= 0 {
		return xerror.NewError(xerror.KafkaTopicNumPartitionsInvalid)
	}
	if topicOption.KafkaTopicOption.ReplicationFactor <= 0 {
		return xerror.NewError(xerror.KafkaTopicReplicationFactorInvalid)
	}
	client := &kafka.Client{
		Addr:    kafka.TCP(q.config.Brokers...),
		Timeout: 10 * time.Second,
	}
	topicConfigs := []kafka.TopicConfig{
		{
			Topic:             topicOption.KafkaTopicOption.TopicName,
			NumPartitions:     topicOption.KafkaTopicOption.NumPartitions,
			ReplicationFactor: topicOption.KafkaTopicOption.ReplicationFactor,
		},
	}
	resp, err := client.CreateTopics(ctx, &kafka.CreateTopicsRequest{
		Topics: topicConfigs,
	})
	if err != nil {
		ctxLogger.Errorf("[Kafka] Error creating topic: %v", err)
		return xerror.NewError(xerror.KafkaTopicCreateFailed)
	}
	failedTopics := make([]string, 0)
	for failedTopic, rErr := range resp.Errors {
		failedTopics = append(failedTopics, failedTopic)
		ctxLogger.Errorf("[Kafka] Failed to create topic '%s': %v", failedTopic, rErr)
	}
	if len(failedTopics) > 0 {
		return xerror.NewError(xerror.KafkaTopicCreateFailed)
	}
	ctxLogger.Infof(
		"[Kafka] Topic '%s' created successfully with %d partitions and replication factor %d",
		topicOption.KafkaTopicOption.TopicName,
		topicOption.KafkaTopicOption.NumPartitions,
		topicOption.KafkaTopicOption.ReplicationFactor,
	)
	return nil
}

func (q *kafkaQueue) Publish(ctx context.Context, topic string, message *_interface.Message) error {
	ctxLogger := logger.NewLogger(ctx)
	var headers []kafka.Header
	for k, v := range message.Meta {
		headers = append(headers, kafka.Header{
			Key:   k,
			Value: []byte(fmt.Sprintf("%v", v)),
		})
	}
	msgId := uuid.NewString()
	if message.Id != nil {
		msgId = *message.Id
	}
	headers = append(headers, kafka.Header{
		Key:   "MessageId",
		Value: []byte(msgId),
	})
	key, err := json.Marshal(message.Key)
	if err != nil {
		ctxLogger.Errorf("[Kafka] Error marshalling message key: %v", err)
		return xerror.NewError(xerror.KafkaPublishFailed)
	}
	value, err := json.Marshal(message.Data)
	if err != nil {
		ctxLogger.Errorf("[Kafka] Error marshalling message data: %v", err)
		return xerror.NewError(xerror.KafkaPublishFailed)
	}
	msg := &kafka.Message{
		Topic:      topic,
		Key:        key,
		Value:      value,
		Headers:    headers,
		WriterData: nil,
		Time:       time.Time{},
	}
	err = q.writer.WriteMessages(ctx, *msg)
	if err != nil {
		ctxLogger.Errorf("[Kafka] Error publishing message: %v", err)
		return xerror.NewError(xerror.KafkaPublishFailed)
	}
	ctxLogger.Infof("[Kafka] Message published to topic %s - id: %s", topic, msgId)
	return nil
}

func (q *kafkaQueue) Consume(ctx context.Context, topic string, handler _interface.Handler) error {
	ctxLogger := logger.NewLogger(ctx)
	q.mu.Lock()
	if _, exists := q.readers[topic]; exists {
		q.mu.Unlock()
		return xerror.NewError(xerror.KafkaTopicAlreadyConsumed)
	}

	readerConfig := kafka.ReaderConfig{
		Brokers:        q.config.Brokers,
		GroupID:        q.config.GroupID,
		Topic:          topic,
		CommitInterval: q.config.CommitInterval,
	}

	reader := kafka.NewReader(readerConfig)
	ctx, cancel := context.WithCancel(ctx)
	q.readers[topic] = reader
	q.cancelFuncs[topic] = cancel
	q.mu.Unlock()
	ctxLogger.Infof("[Kafka] Starting consumer for topic: %s", topic)

	go func() {
		defer reader.Close()

		for {
			m, err := reader.FetchMessage(ctx)
			if err != nil {
				if errors.Is(err, context.Canceled) {
					ctxLogger.Warnf("[Kafka] Stopping consumer for topic: %s", topic)
					return
				}
				ctxLogger.Errorf("[Kafka] Error fetching message from topic %s: %v", topic, err)
				continue
			}
			msgId := getMessageId(extractHeaders(m.Headers))
			message := &_interface.Message{
				Key:  m.Key,
				Data: m.Value,
				Meta: extractHeaders(m.Headers),
			}

			status, err := handler(ctx, message)
			if err != nil {
				ctxLogger.Errorf("[Kafka] Error handling message from topic %s - id: %s: %v", topic, msgId, err)
			}

			switch status {
			case _interface.Success:
				if err := reader.CommitMessages(ctx, m); err != nil {
					ctxLogger.Errorf("[Kafka] Error committing message from topic %s - id: %s: %v", topic, msgId, err)
				}
			case _interface.Retry:
				retryCount := getRetryCount(message.Meta)
				if retryCount >= q.config.MaxRetry {
					ctxLogger.Warnf("[Kafka] Max retry reached, sending message to DLQ for topic %s - id: %s", topic, msgId)
					q.sendToDeadLetterTopic(ctx, m)
					if err := reader.CommitMessages(ctx, m); err != nil {
						ctxLogger.Errorf("[Kafka] Error committing message from topic %s - id: %s: %v", topic, msgId, err)
					}
				} else {
					message.Meta["RetryCount"] = retryCount + 1
					// Gửi message vào retry topic hoặc cơ chế retry khác
					if err := q.publishRetryMessage(ctx, message); err != nil {
						ctxLogger.Errorf("[Kafka] Error republishing message from topic %s - id: %s: %v", topic, msgId, err)
					}
					if err := reader.CommitMessages(ctx, m); err != nil {
						ctxLogger.Errorf("[Kafka] Error committing message from topic %s - id: %s: %v", topic, msgId, err)
					}
				}
			case _interface.Failed:
				ctxLogger.Warnf("[Kafka] Message rejected, sending to DLQ for topic %s - id: %s", topic, msgId)
				q.sendToDeadLetterTopic(ctx, m)
				if err := reader.CommitMessages(ctx, m); err != nil {
					ctxLogger.Errorf("[Kafka] Error committing message from topic %s - id: %s: %v", topic, msgId, err)
				}
			default:
				if err := reader.CommitMessages(ctx, m); err != nil {
					ctxLogger.Errorf("[Kafka] Error committing message from topic %s - id: %s: %v", topic, msgId, err)
				}
			}
		}
	}()

	return nil
}

func (q *kafkaQueue) sendToDeadLetterTopic(ctx context.Context, msg kafka.Message) {
	ctxLogger := logger.NewLogger(ctx)
	msgId := getMessageId(extractHeaders(msg.Headers))
	if q.config.DeadLetterTopic == "" {
		ctxLogger.Warnf("[Kafka] Dead-letter topic not configured, message lost for topic %s - id: %s: %v", msg.Topic, msgId)
		return
	}
	var headers []kafka.Header
	for _, h := range msg.Headers {
		headers = append(headers, h)
	}
	dlqMessage := kafka.Message{
		Topic:   q.config.DeadLetterTopic,
		Key:     msg.Key,
		Value:   msg.Value,
		Headers: headers,
		Time:    time.Now(),
	}
	err := q.writer.WriteMessages(ctx, dlqMessage)
	if err != nil {
		ctxLogger.Errorf("[Kafka] Error sending message to DLQ for topic %s - id: %s: %v", msg.Topic, msgId, err)
	} else {
		ctxLogger.Warnf("[Kafka] Message sent to DLQ %s - id: %s", q.config.DeadLetterTopic, msgId)
	}
}

func (q *kafkaQueue) publishRetryMessage(ctx context.Context, message *_interface.Message) error {
	ctxLogger := logger.NewLogger(ctx)
	msgId := getMessageId(message.Meta)
	if q.config.RetryTopic == nil {
		ctxLogger.Warnf("[Kafka] Retry topic not configured, message send to DLQ for topic %s - id: %s", q.config.DeadLetterTopic, msgId)
		// Gửi message vào DLQ
		msg := convertMessageToKafkaMessage(message)
		q.sendToDeadLetterTopic(ctx, *msg)
		return nil
	}
	msg := convertMessageToKafkaMessage(message)
	msg.Topic = *q.config.RetryTopic
	err := q.writer.WriteMessages(ctx, *msg)
	if err != nil {
		ctxLogger.Errorf("[Kafka] Error publishing message to retry topic %s - id: %s", *q.config.RetryTopic, msgId)
		return xerror.NewError(xerror.KafkaPublishFailed)
	}
	ctxLogger.Warnf("[Kafka] Message sent to retry topic %s - id: %s", *q.config.RetryTopic, msgId)
	return nil
}

func (q *kafkaQueue) Close(ctx context.Context) error {
	ctxLogger := logger.NewLogger(ctx)
	var err error
	if q.writer != nil {
		if err = q.writer.Close(); err != nil {
			ctxLogger.Errorf("[Kafka] Error closing writer, %v", err)
		}
	}

	q.mu.Lock()
	for topic, reader := range q.readers {
		cancel := q.cancelFuncs[topic]
		cancel()
		if readerErr := reader.Close(); readerErr != nil && err == nil {
			ctxLogger.Errorf("[Kafka] Error closing reader, %v", readerErr)
			err = readerErr
		}
		delete(q.readers, topic)
		delete(q.cancelFuncs, topic)
	}
	q.mu.Unlock()
	return err
}

func extractHeaders(kafkaHeaders []kafka.Header) map[string]interface{} {
	headers := make(map[string]interface{})
	for _, h := range kafkaHeaders {
		headers[h.Key] = string(h.Value)
	}
	return headers
}

func getRetryCount(headers map[string]interface{}) int {
	if val, ok := headers["RetryCount"]; ok {
		if count, err := strconv.Atoi(fmt.Sprintf("%v", val)); err == nil {
			return count
		}
	}
	return 0
}

func getMessageId(headers map[string]interface{}) string {
	if val, ok := headers["MessageId"]; ok {
		return fmt.Sprintf("%v", val)
	}
	return ""
}

func convertMessageToKafkaMessage(message *_interface.Message) *kafka.Message {
	var headers []kafka.Header
	for k, v := range message.Meta {
		headers = append(headers, kafka.Header{
			Key:   k,
			Value: []byte(fmt.Sprintf("%v", v)),
		})
	}

	msg := &kafka.Message{
		Key:     []byte(fmt.Sprintf("%s", message.Key)),
		Value:   []byte(fmt.Sprintf("%s", message.Data)),
		Headers: headers,
		Time:    time.Now(),
	}
	return msg
}
