package gin

import (
	"backend/internal/services/auth"
	"backend/pkg/constants"
	"backend/pkg/http"
	"backend/pkg/logger"
	xerror "backend/pkg/x-error"
	"context"
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
)

type Authentication struct {
	authService auth.Service
}

func NewAuthentication(authService auth.Service) *Authentication {
	return &Authentication{
		authService: authService,
	}
}

func (m *Authentication) Middleware(c *gin.Context) {
	ctx := logger.NewContextWithTraceID(c.Request.Context(), "authentication-middleware")
	ctxLogger := logger.NewLogger(ctx)

	// Get access token from header bearer
	accessTokenRaw := c.GetHeader(constants.HeaderKeyAuthorization)
	if accessTokenRaw == "" {
		http.HandleError(c, xerror.NewError(xerror.CodeUnauthorized))
		return
	}
	// Remove Bearer prefix
	accessToken := accessTokenRaw[len(constants.AuthHeaderPrefix):]
	deviceId := c.GetHeader(constants.HeaderKeyDeviceID)
	claims, err := m.processAccessToken(ctx, accessToken, deviceId)
	if err != nil {
		ctxLogger.Errorf("Failed to process access token: %v", err)
		http.HandleError(c, err)
		return
	}
	c.Set(constants.ContextKeyUserId, claims.UserID)
	c.Next()
	return
}

func (m *Authentication) processAccessToken(ctx context.Context, accessToken, deviceId string) (*auth.Claims, error) {
	claims, err := m.authService.ParseToken(ctx, accessToken)
	if err != nil {
		if errors.Is(err, jwt.ErrTokenExpired) {
			return nil, xerror.NewError(xerror.CodeAccessTokenExpired)
		}
		return nil, err
	}
	err = m.authService.CheckValidClaims(ctx, auth.AccessToken, deviceId, claims)
	if err != nil {
		return nil, err
	}
	return claims, nil
}
