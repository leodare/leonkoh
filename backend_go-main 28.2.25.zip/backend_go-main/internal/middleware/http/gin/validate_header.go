package gin

import (
	"backend/pkg/constants"
	"backend/pkg/http"
	xerror "backend/pkg/x-error"
	"github.com/gin-gonic/gin"
	"strings"
)

func ValidateHeader(c *gin.Context) {
	if c.Request.RequestURI == "/ping" || strings.HasPrefix(c.Request.RequestURI, "/api/v1/swagger/") {
		c.Next()
		return
	}
	os := c.GetHeader(constants.HeaderKeyOs)
	if os == "" {
		http.HandleError(c, xerror.NewError(xerror.OSRequired))
		return
	}
	deviceID := c.GetHeader(constants.HeaderKeyDeviceID)
	if deviceID == "" {
		http.HandleError(c, xerror.NewError(xerror.DeviceIDRequired))
		return
	}
	osVer := c.GetHeader(constants.HeaderKeyOsVersion)
	if osVer == "" {
		http.HandleError(c, xerror.NewError(xerror.OSVersionRequired))
		return
	}
	appVersion := c.GetHeader(constants.HeaderKeyAppVersion)
	if appVersion == "" {
		http.HandleError(c, xerror.NewError(xerror.AppVersionRequired))
		return
	}
	deviceModel := c.GetHeader(constants.HeaderKeyDeviceModel)
	if deviceModel == "" {
		http.HandleError(c, xerror.NewError(xerror.DeviceModelRequired))
		return
	}
	c.Set(constants.ContextKeyOs, os)
	c.Set(constants.ContextKeyDeviceID, deviceID)
	c.Set(constants.ContextKeyOsVersion, osVer)
	c.Set(constants.ContextKeyAppVersion, appVersion)
	c.Set(constants.ContextKeyDeviceModel, deviceModel)
	c.Next()
}
