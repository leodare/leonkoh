package gin

import (
	"backend/pkg/constants"
	"backend/pkg/logger"
	"github.com/gin-gonic/gin"
)

func Trace(c *gin.Context) {
	traceID := logger.GenerateTraceID("bestfoody-api")
	c.Set(logger.TraceKey, traceID)
	c.Request.Header.Set(constants.HeaderKeyTraceID, traceID)
	c.Next()
}
