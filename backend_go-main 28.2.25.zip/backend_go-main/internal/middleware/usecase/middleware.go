package middleware

import "context"

type Middleware func(ExecuteFunc) ExecuteFunc

type ExecuteFunc func(ctx context.Context, input interface{}) (interface{}, error)

// WrapMiddlewares wraps the given middlewares around an ExecuteFunc
func WrapMiddlewares(execute ExecuteFunc, middlewares ...Middleware) ExecuteFunc {
	for _, m := range middlewares {
		execute = m(execute)
	}
	return execute
}

type UseCaseWithMiddleware struct {
	ExecuteFunc ExecuteFunc
}

func (u *UseCaseWithMiddleware) Execute(ctx context.Context, input interface{}) (interface{}, error) {
	return u.ExecuteFunc(ctx, input)
}

func NewUseCaseWithMiddleware(execute ExecuteFunc, middlewares ...Middleware) *UseCaseWithMiddleware {
	return &UseCaseWithMiddleware{
		ExecuteFunc: WrapMiddlewares(execute, middlewares...),
	}
}
