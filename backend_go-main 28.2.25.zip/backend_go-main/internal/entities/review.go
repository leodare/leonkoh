package entities

type Review struct {
	Base
	CreatedBy          string  `gorm:"type:uuid;not null" json:"created_by"`
	Title              string  `gorm:"type:varchar(255)" json:"title"`
	Content            string  `gorm:"type:text" json:"content"`
	RestaurantID       string  `gorm:"type:uuid;not null" json:"restaurant_id"`
	VisitDate          *string `gorm:"type:date" json:"visit_date"`
	OverallRating      float64 `gorm:"type:decimal(3,2)" json:"overall_rating"`
	TasteRating        int     `gorm:"type:integer" json:"taste_rating"`
	AromaRating        int     `gorm:"type:integer" json:"aroma_rating"`
	AtmosphereRating   int     `gorm:"type:integer" json:"atmosphere_rating"`
	PresentationRating int     `gorm:"type:integer" json:"presentation_rating"`
	ServiceRating      int     `gorm:"type:integer" json:"service_rating"`
	IsApproved         bool    `gorm:"type:boolean;default:false" json:"is_approved"`

	// Relationships
	User          User           `gorm:"foreignKey:CreatedBy" json:"user"`
	Restaurant    Restaurant     `gorm:"foreignKey:RestaurantID" json:"restaurant"`
	ReviewStatics []ReviewStatic `gorm:"foreignKey:ReviewID" json:"review_statics"`
}

func (Review) TableName() string {
	return "reviews"
}
