package entities

type RestaurantCuisineType struct {
	ID            string `gorm:"type:uuid;primaryKey;default:gen_random_uuid()" json:"id"`
	RestaurantID  string `gorm:"type:uuid;not null;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;" json:"restaurant_id"`
	CuisineTypeID string `gorm:"type:uuid;not null;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;" json:"cuisine_type_id"`

	// Relations
	Restaurant  Restaurant  `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant"`
	CuisineType CuisineType `gorm:"foreignKey:CuisineTypeID;references:ID" json:"cuisine_type"`
}

// TableName specifies the table name for GORM
func (RestaurantCuisineType) TableName() string {
	return "restaurants_cuisine_types"
}
