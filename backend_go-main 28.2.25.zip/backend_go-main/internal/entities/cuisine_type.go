package entities

type CuisineType struct {
	Base
	Name string `json:"name" gorm:"type:varchar(255);not null"`
}

func (CuisineType) TableName() string {
	return "cuisine_types"
}
