package entities

type Category struct {
	Name        *string `gorm:"type:varchar;unique" json:"name"`
	Description *string `gorm:"type:text" json:"description"`
	Base
}

// TableName sets the table name for the Category model
func (*Category) TableName() string {
	return "categories"
}
