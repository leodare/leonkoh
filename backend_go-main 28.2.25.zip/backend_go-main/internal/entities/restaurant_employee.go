package entities

type RestaurantEmployee struct {
	RestaurantID string `gorm:"type:uuid;not null" json:"restaurant_id"`
	EmployeeID   string `gorm:"type:uuid;not null" json:"employee_id"`
	IsOwner      *bool  `gorm:"type:boolean" json:"is_owner"`
	Base

	// Relationships
	Restaurant Restaurant `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant"`
	Employee   User       `gorm:"foreignKey:EmployeeID;references:ID" json:"employee"`
}

// TableName sets the table name for the RestaurantEmployee model
func (*RestaurantEmployee) TableName() string {
	return "restaurant_employee"
}
