package entities

const (
	GenderMale   = "male"
	GenderFemale = "female"
	GenderOther  = "other"
)

type Profile struct {
	Base
	UserID      string  `json:"user_id" gorm:"type:uuid;not null"`
	AddressID   *string `json:"address_id" gorm:"type:uuid"`
	FirstName   string  `json:"first_name" gorm:"type:varchar(255);not null"`
	LastName    string  `json:"last_name" gorm:"type:varchar(255);not null"`
	Avatar      *string `json:"avatar" gorm:"type:varchar(255)"`
	Bio         *string `json:"bio" gorm:"type:text"`
	DateOfBirth *string `json:"date_of_birth" gorm:"type:date"`
	Gender      string  `json:"gender" gorm:"type:varchar(255);not null"`
	User        User    ` json:"user" gorm:"foreignKey:UserID"`
	Address     Address `json:"address" gorm:"foreignKey:AddressID"`
}
