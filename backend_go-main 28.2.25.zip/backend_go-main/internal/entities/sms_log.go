package entities

type SMSStatus string

const (
	SMSStatusPending SMSStatus = "pending"
	SMSStatusSent    SMSStatus = "sent"
	SMSStatusFailed  SMSStatus = "failed"
)

type SMSLog struct {
	Phone   string    `gorm:"type:varchar;not null" json:"phone"`
	Content string    `gorm:"type:text;not null" json:"content"`
	Status  SMSStatus `gorm:"type:sms_status;not null;default:'pending'" json:"status"`
	Message *string   `gorm:"type:text" json:"message"`
	Base
}

// TableName specifies the table name for GORM
func (*SMSLog) TableName() string {
	return "sms_log"
}
