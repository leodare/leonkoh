package entities

type RestaurantAddress struct {
	RestaurantID string  `gorm:"type:uuid;not null" json:"restaurant_id"`
	AddressID    string  `gorm:"type:uuid;not null" json:"address_id"`
	BranchName   *string `gorm:"type:varchar" json:"branch_name"`
	Base

	// Relationships
	Address    Address    `gorm:"foreignKey:AddressID;references:ID" json:"address"`
	Restaurant Restaurant `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant"`
}

// TableName sets the table name for the RestaurantAddress model
func (*RestaurantAddress) TableName() string {
	return "restaurant_address"
}
