package entities

type RestaurantStatic struct {
	RestaurantID string `gorm:"type:uuid;not null;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;" json:"restaurant_id"`
	StaticID     string `gorm:"type:uuid;not null;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;" json:"static_id"`
	Base

	// Relations
	Restaurant Restaurant `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant"`
	Static     Static     `gorm:"foreignKey:StaticID;references:ID" json:"static"`
}

func (*RestaurantStatic) TableName() string {
	return "restaurant_statics"
}
