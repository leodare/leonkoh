package entities

import (
	"gorm.io/gorm"
	"time"
)

// Base defines common fields for all entities.
type Base struct {
	ID        string          `gorm:"type:uuid;primaryKey;default:gen_random_uuid()" json:"id"`
	CreatedAt time.Time       `gorm:"type:timestamp;not null;default:now()" json:"created_at"`
	UpdatedAt *time.Time      `gorm:"type:timestamp;null;" json:"updated_at"`
	DeletedAt *gorm.DeletedAt `gorm:"type:timestamp;index" json:"deleted_at"`
}

// BeforeCreate is a GORM hook that sets CreatedAt before a record is created.
func (base *Base) BeforeCreate(tx *gorm.DB) (err error) {
	if base.CreatedAt.IsZero() {
		base.CreatedAt = time.Now().UTC()
	}
	return nil
}

// BeforeUpdate is a GORM hook that sets UpdatedAt before a record is updated.
func (base *Base) BeforeUpdate(tx *gorm.DB) (err error) {
	updatedAt := time.Now().UTC()
	base.UpdatedAt = &updatedAt
	return nil
}

func (base *Base) GetID() string {
	return base.ID
}
