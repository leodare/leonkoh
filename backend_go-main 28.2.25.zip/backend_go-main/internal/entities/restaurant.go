package entities

type Restaurant struct {
	Name          string   `gorm:"type:varchar" json:"name"`
	UnitNumber    *string  `gorm:"type:varchar" json:"unit_number"`
	Area          *string  `gorm:"type:varchar" json:"area"`
	Phone         *string  `gorm:"type:varchar" json:"phone"`
	OpeningTime   *string  `gorm:"type:time" json:"opening_time"`
	ClosingTime   *string  `gorm:"type:time" json:"closing_time"`
	OverallRating *float64 `gorm:"type:float" json:"overall_rating"`
	PriceFrom     *float64 `gorm:"type:float" json:"price_from"`
	PriceTo       *float64 `gorm:"type:float" json:"price_to"`
	Website       *string  `gorm:"type:varchar(255)" json:"website"`
	Email         *string  `gorm:"type:varchar(255)" json:"email"`
	Base

	// Relationships
	RestaurantStatics      []RestaurantStatic      `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant_statics"`
	RestaurantCuisineTypes []RestaurantCuisineType `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant_cuisine_types"`
	RestaurantAddresses    []RestaurantAddress     `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant_addresses"`
	RestaurantCategories   []RestaurantCategory    `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant_categories"`
}

func (*Restaurant) TableName() string {
	// TODO : Change the table name
	return "restaurants"
}
