package entities

type LogRestaurantView struct {
	Base
	RestaurantID string     `gorm:"type:uuid;not null" json:"restaurant_id"`
	UserID       string     `gorm:"type:uuid;not null" json:"user_id"`
	Restaurant   Restaurant `gorm:"foreignKey:RestaurantID" json:"restaurant"`
	User         User       `gorm:"foreignKey:UserID" json:"user"`
}
