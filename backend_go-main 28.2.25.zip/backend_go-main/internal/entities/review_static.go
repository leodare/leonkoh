package entities

type ReviewStatic struct {
	Base
	StaticID string `gorm:"type:uuid;not null" json:"static_id"`
	ReviewID string `gorm:"type:uuid;not null" json:"review_id"`
}

func (ReviewStatic) TableName() string {
	// TODO : Change the table name
	return "review_statics"
}
