package entities

type UserFollow struct {
	Base
	FollowerID string `gorm:"type:uuid;not null;index;constraint:OnUpdate:CASCADE,OnDelete:CASCADE;" json:"follower_id"` // User đang follow (user_1)
	FollowedID string `gorm:"type:uuid;not null;index;constraint:OnUpdate:CASCADE,OnDelete:CASCADE;" json:"followed_id"` // User được follow (user_2)"
	Follower   User   `gorm:"foreignKey:FollowerID" json:"follower"`                                                     // Quan hệ với bảng User
	Followed   User   `gorm:"foreignKey:FollowedID" json:"followed"`                                                     // Quan hệ với bảng User
}
