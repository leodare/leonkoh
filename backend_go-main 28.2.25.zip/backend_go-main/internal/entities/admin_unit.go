package entities

type AdminUnit struct {
	Name       string  `gorm:"type:uuid;not null" json:"name"`
	TypeID     string  `gorm:"type:uuid;not null;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;" json:"type_id"`
	ParentID   *string `gorm:"type:uuid;constraint:OnUpdate:CASCADE,OnDelete:SET NULL;" json:"parent_id"`
	Code       *string `gorm:"type:varchar(50)" json:"code"`
	PostalCode *string `gorm:"type:varchar(50)" json:"postal_code"`
	Base

	// Relationships
	Type     AdminUnitType `gorm:"foreignKey:TypeID" json:"type"`
	Parent   *AdminUnit    `gorm:"foreignKey:ParentID" json:"parent"`
	Children []AdminUnit   `gorm:"foreignKey:ParentID" json:"children"`
}

// TableName sets the table name
func (*AdminUnit) TableName() string {
	return "admin_units"
}
