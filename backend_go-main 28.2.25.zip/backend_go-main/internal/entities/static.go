package entities

type Static struct {
	Base
	URL      string  `gorm:"type:varchar(255);not null;"`
	FileSize int64   `gorm:"type:bigint;not null;"`
	FileType string  `gorm:"type:varchar(255);not null;"`
	Metadata *string `gorm:"type:text;null;"`
	Alt      *string `gorm:"type:text;null;"`
}

func (Static) TableName() string {
	// TODO : Change the table name
	return "statics"
}
