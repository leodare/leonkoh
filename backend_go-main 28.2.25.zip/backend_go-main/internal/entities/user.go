package entities

type User struct {
	Username   string  `gorm:"type:varchar;unique;not null" json:"username"`
	Password   string  `gorm:"type:varchar;not null" json:"password"`
	Email      *string `gorm:"type:varchar" json:"email"`
	Phone      string  `gorm:"type:varchar;not null" json:"phone"`
	NeedVerify bool    `gorm:"type:boolean;default:false" json:"need_verify"`
	Base
}

// TableName overrides the default table name for User
func (*User) TableName() string {
	return "users"
}
