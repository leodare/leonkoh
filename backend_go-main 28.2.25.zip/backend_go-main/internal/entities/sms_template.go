package entities

type SMSTemplate struct {
	Code     string `gorm:"type:varchar;unique;not null" json:"code"`
	Name     string `gorm:"type:varchar;not null" json:"name"`
	Template string `gorm:"type:text;not null" json:"template"`
	Base
}

// TableName specifies the custom table name for GORM
func (*SMSTemplate) TableName() string {
	return "sms_template"
}
