package entities

type Address struct {
	UserID      *string  `gorm:"type:uuid;index" json:"user_id"`
	AdminUnitID string   `gorm:"type:uuid;not null;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT;" json:"admin_unit_id"`
	Address1    *string  `gorm:"column:address_1;type:text" json:"address_1"`
	Address2    *string  `gorm:"column:address_2;type:text" json:"address_2"`
	PostalCode  *string  `gorm:"type:varchar(50)" json:"postal_code"`
	Latitude    *float64 `gorm:"type:decimal(9,6)" json:"latitude"`
	Longitude   *float64 `gorm:"type:decimal(9,6)" json:"longitude"`
	Base

	// Relationships
	AdminUnit AdminUnit `gorm:"foreignKey:AdminUnitID" json:"admin_unit"`
}

// TableName sets the table name
func (*Address) TableName() string {
	return "addresses"
}
