package entities

type RestaurantCategory struct {
	RestaurantID string `gorm:"type:uuid;not null" json:"restaurant_id"`
	CategoryID   string `gorm:"type:uuid;not null" json:"category_id"`
	Base

	// Relationships
	Restaurant Restaurant `gorm:"foreignKey:RestaurantID;references:ID" json:"restaurant"`
	Category   Category   `gorm:"foreignKey:CategoryID;references:ID" json:"category"`
}

// TableName sets the table name for the RestaurantCategory model
func (*RestaurantCategory) TableName() string {
	return "restaurant_category"
}
