package entities

type AdminUnitType struct {
	Name        string `gorm:"type:text;unique;not null" json:"name"`
	Description string `gorm:"type:text" json:"description"`
	Base
}

// TableName sets the table name
func (*AdminUnitType) TableName() string {
	return "admin_unit_types"
}
